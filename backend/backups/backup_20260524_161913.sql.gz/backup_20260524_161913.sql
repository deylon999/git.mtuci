--
-- PostgreSQL database dump
--

\restrict SKfPw4k22acDXix6mBmWZ4YjQdDPTRgWcF1id13ocQ8dUlxDGBp14mBHX2fGsmD

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.trusted_assistants DROP CONSTRAINT IF EXISTS fk_trusted_assistants_teacher_id_users;
ALTER TABLE IF EXISTS ONLY public.trusted_assistants DROP CONSTRAINT IF EXISTS fk_trusted_assistants_assistant_id_users;
ALTER TABLE IF EXISTS ONLY public.system_logs DROP CONSTRAINT IF EXISTS fk_system_logs_user_id_users;
ALTER TABLE IF EXISTS ONLY public.submissions DROP CONSTRAINT IF EXISTS fk_submissions_student_id_users;
ALTER TABLE IF EXISTS ONLY public.submissions DROP CONSTRAINT IF EXISTS fk_submissions_assignment_id_assignments;
ALTER TABLE IF EXISTS ONLY public.student_repositories DROP CONSTRAINT IF EXISTS fk_student_repositories_student_id_users;
ALTER TABLE IF EXISTS ONLY public.student_repositories DROP CONSTRAINT IF EXISTS fk_student_repositories_assignment_id_assignments;
ALTER TABLE IF EXISTS ONLY public.repositories DROP CONSTRAINT IF EXISTS fk_repositories_owner_id_users;
ALTER TABLE IF EXISTS ONLY public.permission_audit DROP CONSTRAINT IF EXISTS fk_permission_audit_actor_id_users;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS fk_password_reset_tokens_user_id_users;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk_notifications_user_id_users;
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS fk_courses_teacher_id_users;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS fk_course_enrollments_student_id_users;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS fk_course_enrollments_course_id_courses;
ALTER TABLE IF EXISTS ONLY public.assignments DROP CONSTRAINT IF EXISTS fk_assignments_course_id_courses;
ALTER TABLE IF EXISTS ONLY public.assignment_files DROP CONSTRAINT IF EXISTS fk_assignment_files_assignment_id_assignments;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS fk_activity_log_user_id_users;
DROP INDEX IF EXISTS public.ix_users_student_id;
DROP INDEX IF EXISTS public.ix_users_mtuci_login;
DROP INDEX IF EXISTS public.ix_users_last_login;
DROP INDEX IF EXISTS public.ix_users_group_name;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_trusted_assistants_teacher_id;
DROP INDEX IF EXISTS public.ix_trusted_assistants_assistant_id;
DROP INDEX IF EXISTS public.ix_system_logs_user_id;
DROP INDEX IF EXISTS public.ix_system_logs_source;
DROP INDEX IF EXISTS public.ix_system_logs_level;
DROP INDEX IF EXISTS public.ix_system_logs_created_at_level_source;
DROP INDEX IF EXISTS public.ix_system_logs_created_at;
DROP INDEX IF EXISTS public.ix_submissions_student_id;
DROP INDEX IF EXISTS public.ix_submissions_assignment_id;
DROP INDEX IF EXISTS public.ix_student_repositories_student_id;
DROP INDEX IF EXISTS public.ix_student_repositories_assignment_id;
DROP INDEX IF EXISTS public.ix_role_permissions_role;
DROP INDEX IF EXISTS public.ix_repositories_repo_type;
DROP INDEX IF EXISTS public.ix_repositories_owner_id;
DROP INDEX IF EXISTS public.ix_repositories_language;
DROP INDEX IF EXISTS public.ix_repositories_is_blocked;
DROP INDEX IF EXISTS public.ix_repositories_gitea_repo_id;
DROP INDEX IF EXISTS public.ix_permission_audit_target_role;
DROP INDEX IF EXISTS public.ix_permission_audit_created_at;
DROP INDEX IF EXISTS public.ix_permission_audit_actor_id;
DROP INDEX IF EXISTS public.ix_password_reset_tokens_user_id;
DROP INDEX IF EXISTS public.ix_password_reset_tokens_token_hash;
DROP INDEX IF EXISTS public.ix_notifications_user_read;
DROP INDEX IF EXISTS public.ix_notifications_user_id;
DROP INDEX IF EXISTS public.ix_courses_teacher_id;
DROP INDEX IF EXISTS public.ix_course_enrollments_student_id;
DROP INDEX IF EXISTS public.ix_course_enrollments_course_id;
DROP INDEX IF EXISTS public.ix_assignments_deadline;
DROP INDEX IF EXISTS public.ix_assignments_course_id;
DROP INDEX IF EXISTS public.ix_assignment_files_assignment_id;
DROP INDEX IF EXISTS public.ix_activity_log_user_id;
DROP INDEX IF EXISTS public.ix_activity_log_repo_name;
DROP INDEX IF EXISTS public.ix_activity_log_created_at;
DROP INDEX IF EXISTS public.ix_activity_log_activity_type;
DROP INDEX IF EXISTS public."UQE_webauthn_credential_s";
DROP INDEX IF EXISTS public."UQE_watch_watch";
DROP INDEX IF EXISTS public."UQE_user_setting_key_userid";
DROP INDEX IF EXISTS public."UQE_user_redirect_s";
DROP INDEX IF EXISTS public."UQE_user_open_id_uri";
DROP INDEX IF EXISTS public."UQE_user_name";
DROP INDEX IF EXISTS public."UQE_user_lower_name";
DROP INDEX IF EXISTS public."UQE_user_blocking_block";
DROP INDEX IF EXISTS public."UQE_upload_uuid";
DROP INDEX IF EXISTS public."UQE_two_factor_uid";
DROP INDEX IF EXISTS public."UQE_topic_name";
DROP INDEX IF EXISTS public."UQE_team_user_s";
DROP INDEX IF EXISTS public."UQE_team_unit_s";
DROP INDEX IF EXISTS public."UQE_team_repo_s";
DROP INDEX IF EXISTS public."UQE_team_invite_team_mail";
DROP INDEX IF EXISTS public."UQE_system_setting_setting_key";
DROP INDEX IF EXISTS public."UQE_star_s";
DROP INDEX IF EXISTS public."UQE_secret_owner_repo_name";
DROP INDEX IF EXISTS public."UQE_review_state_pull_commit_user";
DROP INDEX IF EXISTS public."UQE_repository_s";
DROP INDEX IF EXISTS public."UQE_repo_redirect_s";
DROP INDEX IF EXISTS public."UQE_repo_archiver_s";
DROP INDEX IF EXISTS public."UQE_release_n";
DROP INDEX IF EXISTS public."UQE_reaction_s";
DROP INDEX IF EXISTS public."UQE_pull_auto_merge_pull_id";
DROP INDEX IF EXISTS public."UQE_protected_branch_s";
DROP INDEX IF EXISTS public."UQE_package_version_s";
DROP INDEX IF EXISTS public."UQE_package_s";
DROP INDEX IF EXISTS public."UQE_package_file_s";
DROP INDEX IF EXISTS public."UQE_package_cleanup_rule_s";
DROP INDEX IF EXISTS public."UQE_package_blob_sha512";
DROP INDEX IF EXISTS public."UQE_package_blob_sha256";
DROP INDEX IF EXISTS public."UQE_package_blob_sha1";
DROP INDEX IF EXISTS public."UQE_package_blob_md5";
DROP INDEX IF EXISTS public."UQE_org_user_s";
DROP INDEX IF EXISTS public."UQE_oauth2_grant_user_application";
DROP INDEX IF EXISTS public."UQE_oauth2_authorization_code_code";
DROP INDEX IF EXISTS public."UQE_oauth2_application_client_id";
DROP INDEX IF EXISTS public."UQE_login_source_name";
DROP INDEX IF EXISTS public."UQE_lfs_meta_object_s";
DROP INDEX IF EXISTS public."UQE_language_stat_s";
DROP INDEX IF EXISTS public."UQE_issue_watch_watch";
DROP INDEX IF EXISTS public."UQE_issue_user_uid_to_issue";
DROP INDEX IF EXISTS public."UQE_issue_repo_index";
DROP INDEX IF EXISTS public."UQE_issue_label_s";
DROP INDEX IF EXISTS public."UQE_issue_dependency_issue_dependency";
DROP INDEX IF EXISTS public."UQE_hook_task_uuid";
DROP INDEX IF EXISTS public."UQE_follow_follow";
DROP INDEX IF EXISTS public."UQE_email_hash_email";
DROP INDEX IF EXISTS public."UQE_email_address_lower_email";
DROP INDEX IF EXISTS public."UQE_email_address_email";
DROP INDEX IF EXISTS public."UQE_deploy_key_s";
DROP INDEX IF EXISTS public."UQE_dbfs_meta_full_path";
DROP INDEX IF EXISTS public."UQE_commit_status_summary_repo_id_sha";
DROP INDEX IF EXISTS public."UQE_commit_status_repo_sha_index";
DROP INDEX IF EXISTS public."UQE_commit_status_index_repo_sha";
DROP INDEX IF EXISTS public."UQE_collaboration_s";
DROP INDEX IF EXISTS public."UQE_branch_s";
DROP INDEX IF EXISTS public."UQE_badge_slug";
DROP INDEX IF EXISTS public."UQE_attachment_uuid";
DROP INDEX IF EXISTS public."UQE_action_variable_owner_repo_name";
DROP INDEX IF EXISTS public."UQE_action_tasks_version_owner_repo";
DROP INDEX IF EXISTS public."UQE_action_task_token_hash";
DROP INDEX IF EXISTS public."UQE_action_task_step_task_index";
DROP INDEX IF EXISTS public."UQE_action_task_output_task_id_output_key";
DROP INDEX IF EXISTS public."UQE_action_runner_uuid";
DROP INDEX IF EXISTS public."UQE_action_runner_token_token";
DROP INDEX IF EXISTS public."UQE_action_runner_token_hash";
DROP INDEX IF EXISTS public."UQE_action_run_repo_index";
DROP INDEX IF EXISTS public."UQE_action_artifact_runid_name_path";
DROP INDEX IF EXISTS public."UQE_access_token_token_hash";
DROP INDEX IF EXISTS public."UQE_access_s";
DROP INDEX IF EXISTS public."IDX_webhook_updated_unix";
DROP INDEX IF EXISTS public."IDX_webhook_repo_id";
DROP INDEX IF EXISTS public."IDX_webhook_owner_id";
DROP INDEX IF EXISTS public."IDX_webhook_is_active";
DROP INDEX IF EXISTS public."IDX_webhook_created_unix";
DROP INDEX IF EXISTS public."IDX_webauthn_credential_user_id";
DROP INDEX IF EXISTS public."IDX_webauthn_credential_updated_unix";
DROP INDEX IF EXISTS public."IDX_webauthn_credential_credential_id";
DROP INDEX IF EXISTS public."IDX_webauthn_credential_created_unix";
DROP INDEX IF EXISTS public."IDX_watch_updated_unix";
DROP INDEX IF EXISTS public."IDX_watch_created_unix";
DROP INDEX IF EXISTS public."IDX_user_updated_unix";
DROP INDEX IF EXISTS public."IDX_user_setting_user_id";
DROP INDEX IF EXISTS public."IDX_user_setting_setting_key";
DROP INDEX IF EXISTS public."IDX_user_redirect_lower_name";
DROP INDEX IF EXISTS public."IDX_user_open_id_uid";
DROP INDEX IF EXISTS public."IDX_user_last_login_unix";
DROP INDEX IF EXISTS public."IDX_user_is_active";
DROP INDEX IF EXISTS public."IDX_user_created_unix";
DROP INDEX IF EXISTS public."IDX_user_blocking_created_unix";
DROP INDEX IF EXISTS public."IDX_user_badge_user_id";
DROP INDEX IF EXISTS public."IDX_two_factor_updated_unix";
DROP INDEX IF EXISTS public."IDX_two_factor_created_unix";
DROP INDEX IF EXISTS public."IDX_tracked_time_user_id";
DROP INDEX IF EXISTS public."IDX_tracked_time_issue_id";
DROP INDEX IF EXISTS public."IDX_topic_updated_unix";
DROP INDEX IF EXISTS public."IDX_topic_created_unix";
DROP INDEX IF EXISTS public."IDX_team_user_org_id";
DROP INDEX IF EXISTS public."IDX_team_unit_org_id";
DROP INDEX IF EXISTS public."IDX_team_repo_org_id";
DROP INDEX IF EXISTS public."IDX_team_org_id";
DROP INDEX IF EXISTS public."IDX_team_invite_updated_unix";
DROP INDEX IF EXISTS public."IDX_team_invite_token";
DROP INDEX IF EXISTS public."IDX_team_invite_team_id";
DROP INDEX IF EXISTS public."IDX_team_invite_org_id";
DROP INDEX IF EXISTS public."IDX_team_invite_created_unix";
DROP INDEX IF EXISTS public."IDX_task_status";
DROP INDEX IF EXISTS public."IDX_task_repo_id";
DROP INDEX IF EXISTS public."IDX_task_owner_id";
DROP INDEX IF EXISTS public."IDX_task_doer_id";
DROP INDEX IF EXISTS public."IDX_stopwatch_user_id";
DROP INDEX IF EXISTS public."IDX_stopwatch_issue_id";
DROP INDEX IF EXISTS public."IDX_star_created_unix";
DROP INDEX IF EXISTS public."IDX_secret_repo_id";
DROP INDEX IF EXISTS public."IDX_secret_owner_id";
DROP INDEX IF EXISTS public."IDX_review_updated_unix";
DROP INDEX IF EXISTS public."IDX_review_state_pull_id";
DROP INDEX IF EXISTS public."IDX_review_reviewer_id";
DROP INDEX IF EXISTS public."IDX_review_issue_id";
DROP INDEX IF EXISTS public."IDX_review_created_unix";
DROP INDEX IF EXISTS public."IDX_repository_updated_unix";
DROP INDEX IF EXISTS public."IDX_repository_template_id";
DROP INDEX IF EXISTS public."IDX_repository_owner_id";
DROP INDEX IF EXISTS public."IDX_repository_original_service_type";
DROP INDEX IF EXISTS public."IDX_repository_name";
DROP INDEX IF EXISTS public."IDX_repository_lower_name";
DROP INDEX IF EXISTS public."IDX_repository_is_template";
DROP INDEX IF EXISTS public."IDX_repository_is_private";
DROP INDEX IF EXISTS public."IDX_repository_is_mirror";
DROP INDEX IF EXISTS public."IDX_repository_is_fork";
DROP INDEX IF EXISTS public."IDX_repository_is_empty";
DROP INDEX IF EXISTS public."IDX_repository_is_archived";
DROP INDEX IF EXISTS public."IDX_repository_fork_id";
DROP INDEX IF EXISTS public."IDX_repository_created_unix";
DROP INDEX IF EXISTS public."IDX_repo_unit_s";
DROP INDEX IF EXISTS public."IDX_repo_unit_created_unix";
DROP INDEX IF EXISTS public."IDX_repo_transfer_updated_unix";
DROP INDEX IF EXISTS public."IDX_repo_transfer_created_unix";
DROP INDEX IF EXISTS public."IDX_repo_redirect_lower_name";
DROP INDEX IF EXISTS public."IDX_repo_indexer_status_s";
DROP INDEX IF EXISTS public."IDX_repo_archiver_repo_id";
DROP INDEX IF EXISTS public."IDX_repo_archiver_created_unix";
DROP INDEX IF EXISTS public."IDX_renamed_branch_repo_id";
DROP INDEX IF EXISTS public."IDX_release_tag_name";
DROP INDEX IF EXISTS public."IDX_release_repo_id";
DROP INDEX IF EXISTS public."IDX_release_publisher_id";
DROP INDEX IF EXISTS public."IDX_release_original_author_id";
DROP INDEX IF EXISTS public."IDX_release_created_unix";
DROP INDEX IF EXISTS public."IDX_reaction_user_id";
DROP INDEX IF EXISTS public."IDX_reaction_type";
DROP INDEX IF EXISTS public."IDX_reaction_original_author_id";
DROP INDEX IF EXISTS public."IDX_reaction_original_author";
DROP INDEX IF EXISTS public."IDX_reaction_issue_id";
DROP INDEX IF EXISTS public."IDX_reaction_created_unix";
DROP INDEX IF EXISTS public."IDX_reaction_comment_id";
DROP INDEX IF EXISTS public."IDX_push_mirror_repo_id";
DROP INDEX IF EXISTS public."IDX_push_mirror_last_update";
DROP INDEX IF EXISTS public."IDX_pull_request_merger_id";
DROP INDEX IF EXISTS public."IDX_pull_request_merged_unix";
DROP INDEX IF EXISTS public."IDX_pull_request_issue_id";
DROP INDEX IF EXISTS public."IDX_pull_request_head_repo_id";
DROP INDEX IF EXISTS public."IDX_pull_request_has_merged";
DROP INDEX IF EXISTS public."IDX_pull_request_base_repo_id";
DROP INDEX IF EXISTS public."IDX_pull_auto_merge_doer_id";
DROP INDEX IF EXISTS public."IDX_public_key_owner_id";
DROP INDEX IF EXISTS public."IDX_public_key_fingerprint";
DROP INDEX IF EXISTS public."IDX_project_updated_unix";
DROP INDEX IF EXISTS public."IDX_project_title";
DROP INDEX IF EXISTS public."IDX_project_repo_id";
DROP INDEX IF EXISTS public."IDX_project_owner_id";
DROP INDEX IF EXISTS public."IDX_project_issue_project_id";
DROP INDEX IF EXISTS public."IDX_project_issue_project_board_id";
DROP INDEX IF EXISTS public."IDX_project_issue_issue_id";
DROP INDEX IF EXISTS public."IDX_project_is_closed";
DROP INDEX IF EXISTS public."IDX_project_created_unix";
DROP INDEX IF EXISTS public."IDX_project_board_updated_unix";
DROP INDEX IF EXISTS public."IDX_project_board_project_id";
DROP INDEX IF EXISTS public."IDX_project_board_created_unix";
DROP INDEX IF EXISTS public."IDX_package_version_package_id";
DROP INDEX IF EXISTS public."IDX_package_version_lower_version";
DROP INDEX IF EXISTS public."IDX_package_version_is_internal";
DROP INDEX IF EXISTS public."IDX_package_version_created_unix";
DROP INDEX IF EXISTS public."IDX_package_type";
DROP INDEX IF EXISTS public."IDX_package_repo_id";
DROP INDEX IF EXISTS public."IDX_package_property_ref_type";
DROP INDEX IF EXISTS public."IDX_package_property_ref_id";
DROP INDEX IF EXISTS public."IDX_package_property_name";
DROP INDEX IF EXISTS public."IDX_package_owner_id";
DROP INDEX IF EXISTS public."IDX_package_lower_name";
DROP INDEX IF EXISTS public."IDX_package_file_version_id";
DROP INDEX IF EXISTS public."IDX_package_file_lower_name";
DROP INDEX IF EXISTS public."IDX_package_file_created_unix";
DROP INDEX IF EXISTS public."IDX_package_file_composite_key";
DROP INDEX IF EXISTS public."IDX_package_file_blob_id";
DROP INDEX IF EXISTS public."IDX_package_cleanup_rule_type";
DROP INDEX IF EXISTS public."IDX_package_cleanup_rule_owner_id";
DROP INDEX IF EXISTS public."IDX_package_cleanup_rule_enabled";
DROP INDEX IF EXISTS public."IDX_package_blob_upload_updated_unix";
DROP INDEX IF EXISTS public."IDX_package_blob_hash_sha512";
DROP INDEX IF EXISTS public."IDX_package_blob_hash_sha256";
DROP INDEX IF EXISTS public."IDX_package_blob_hash_sha1";
DROP INDEX IF EXISTS public."IDX_package_blob_hash_md5";
DROP INDEX IF EXISTS public."IDX_package_blob_created_unix";
DROP INDEX IF EXISTS public."IDX_org_user_uid";
DROP INDEX IF EXISTS public."IDX_org_user_org_id";
DROP INDEX IF EXISTS public."IDX_org_user_is_public";
DROP INDEX IF EXISTS public."IDX_oauth2_grant_user_id";
DROP INDEX IF EXISTS public."IDX_oauth2_grant_application_id";
DROP INDEX IF EXISTS public."IDX_oauth2_authorization_code_valid_until";
DROP INDEX IF EXISTS public."IDX_oauth2_application_updated_unix";
DROP INDEX IF EXISTS public."IDX_oauth2_application_uid";
DROP INDEX IF EXISTS public."IDX_oauth2_application_created_unix";
DROP INDEX IF EXISTS public."IDX_notification_user_id";
DROP INDEX IF EXISTS public."IDX_notification_updated_unix";
DROP INDEX IF EXISTS public."IDX_notification_updated_by";
DROP INDEX IF EXISTS public."IDX_notification_status";
DROP INDEX IF EXISTS public."IDX_notification_source";
DROP INDEX IF EXISTS public."IDX_notification_repo_id";
DROP INDEX IF EXISTS public."IDX_notification_issue_id";
DROP INDEX IF EXISTS public."IDX_notification_created_unix";
DROP INDEX IF EXISTS public."IDX_notification_commit_id";
DROP INDEX IF EXISTS public."IDX_notice_created_unix";
DROP INDEX IF EXISTS public."IDX_mirror_updated_unix";
DROP INDEX IF EXISTS public."IDX_mirror_repo_id";
DROP INDEX IF EXISTS public."IDX_mirror_next_update_unix";
DROP INDEX IF EXISTS public."IDX_milestone_updated_unix";
DROP INDEX IF EXISTS public."IDX_milestone_repo_id";
DROP INDEX IF EXISTS public."IDX_milestone_created_unix";
DROP INDEX IF EXISTS public."IDX_login_source_updated_unix";
DROP INDEX IF EXISTS public."IDX_login_source_is_sync_enabled";
DROP INDEX IF EXISTS public."IDX_login_source_is_active";
DROP INDEX IF EXISTS public."IDX_login_source_created_unix";
DROP INDEX IF EXISTS public."IDX_lfs_meta_object_updated_unix";
DROP INDEX IF EXISTS public."IDX_lfs_meta_object_repository_id";
DROP INDEX IF EXISTS public."IDX_lfs_meta_object_oid";
DROP INDEX IF EXISTS public."IDX_lfs_lock_repo_id";
DROP INDEX IF EXISTS public."IDX_lfs_lock_owner_id";
DROP INDEX IF EXISTS public."IDX_language_stat_repo_id";
DROP INDEX IF EXISTS public."IDX_language_stat_language";
DROP INDEX IF EXISTS public."IDX_language_stat_created_unix";
DROP INDEX IF EXISTS public."IDX_label_updated_unix";
DROP INDEX IF EXISTS public."IDX_label_repo_id";
DROP INDEX IF EXISTS public."IDX_label_org_id";
DROP INDEX IF EXISTS public."IDX_label_created_unix";
DROP INDEX IF EXISTS public."IDX_issue_user_uid";
DROP INDEX IF EXISTS public."IDX_issue_user_issue_id";
DROP INDEX IF EXISTS public."IDX_issue_updated_unix";
DROP INDEX IF EXISTS public."IDX_issue_repo_id";
DROP INDEX IF EXISTS public."IDX_issue_poster_id";
DROP INDEX IF EXISTS public."IDX_issue_original_author_id";
DROP INDEX IF EXISTS public."IDX_issue_milestone_id";
DROP INDEX IF EXISTS public."IDX_issue_is_pull";
DROP INDEX IF EXISTS public."IDX_issue_is_closed";
DROP INDEX IF EXISTS public."IDX_issue_index_max_index";
DROP INDEX IF EXISTS public."IDX_issue_deadline_unix";
DROP INDEX IF EXISTS public."IDX_issue_created_unix";
DROP INDEX IF EXISTS public."IDX_issue_content_history_issue_id";
DROP INDEX IF EXISTS public."IDX_issue_content_history_edited_unix";
DROP INDEX IF EXISTS public."IDX_issue_content_history_comment_id";
DROP INDEX IF EXISTS public."IDX_issue_closed_unix";
DROP INDEX IF EXISTS public."IDX_issue_assignees_issue_id";
DROP INDEX IF EXISTS public."IDX_issue_assignees_assignee_id";
DROP INDEX IF EXISTS public."IDX_hook_task_hook_id";
DROP INDEX IF EXISTS public."IDX_gpg_key_owner_id";
DROP INDEX IF EXISTS public."IDX_gpg_key_key_id";
DROP INDEX IF EXISTS public."IDX_follow_created_unix";
DROP INDEX IF EXISTS public."IDX_external_login_user_user_id";
DROP INDEX IF EXISTS public."IDX_external_login_user_provider";
DROP INDEX IF EXISTS public."IDX_email_address_uid";
DROP INDEX IF EXISTS public."IDX_deploy_key_repo_id";
DROP INDEX IF EXISTS public."IDX_deploy_key_key_id";
DROP INDEX IF EXISTS public."IDX_dbfs_data_meta_offset";
DROP INDEX IF EXISTS public."IDX_commit_status_updated_unix";
DROP INDEX IF EXISTS public."IDX_commit_status_summary_sha";
DROP INDEX IF EXISTS public."IDX_commit_status_summary_repo_id";
DROP INDEX IF EXISTS public."IDX_commit_status_sha";
DROP INDEX IF EXISTS public."IDX_commit_status_repo_id";
DROP INDEX IF EXISTS public."IDX_commit_status_index_max_index";
DROP INDEX IF EXISTS public."IDX_commit_status_index";
DROP INDEX IF EXISTS public."IDX_commit_status_created_unix";
DROP INDEX IF EXISTS public."IDX_commit_status_context_hash";
DROP INDEX IF EXISTS public."IDX_comment_updated_unix";
DROP INDEX IF EXISTS public."IDX_comment_type";
DROP INDEX IF EXISTS public."IDX_comment_review_id";
DROP INDEX IF EXISTS public."IDX_comment_ref_repo_id";
DROP INDEX IF EXISTS public."IDX_comment_ref_issue_id";
DROP INDEX IF EXISTS public."IDX_comment_ref_comment_id";
DROP INDEX IF EXISTS public."IDX_comment_poster_id";
DROP INDEX IF EXISTS public."IDX_comment_issue_id";
DROP INDEX IF EXISTS public."IDX_comment_dependent_issue_id";
DROP INDEX IF EXISTS public."IDX_comment_created_unix";
DROP INDEX IF EXISTS public."IDX_collaboration_user_id";
DROP INDEX IF EXISTS public."IDX_collaboration_updated_unix";
DROP INDEX IF EXISTS public."IDX_collaboration_repo_id";
DROP INDEX IF EXISTS public."IDX_collaboration_created_unix";
DROP INDEX IF EXISTS public."IDX_branch_is_deleted";
DROP INDEX IF EXISTS public."IDX_branch_deleted_unix";
DROP INDEX IF EXISTS public."IDX_auth_token_user_id";
DROP INDEX IF EXISTS public."IDX_auth_token_expires_unix";
DROP INDEX IF EXISTS public."IDX_attachment_uploader_id";
DROP INDEX IF EXISTS public."IDX_attachment_repo_id";
DROP INDEX IF EXISTS public."IDX_attachment_release_id";
DROP INDEX IF EXISTS public."IDX_attachment_issue_id";
DROP INDEX IF EXISTS public."IDX_attachment_comment_id";
DROP INDEX IF EXISTS public."IDX_action_variable_repo_id";
DROP INDEX IF EXISTS public."IDX_action_user_id";
DROP INDEX IF EXISTS public."IDX_action_tasks_version_repo_id";
DROP INDEX IF EXISTS public."IDX_action_task_updated";
DROP INDEX IF EXISTS public."IDX_action_task_token_last_eight";
DROP INDEX IF EXISTS public."IDX_action_task_step_task_id";
DROP INDEX IF EXISTS public."IDX_action_task_step_status";
DROP INDEX IF EXISTS public."IDX_action_task_step_repo_id";
DROP INDEX IF EXISTS public."IDX_action_task_step_index";
DROP INDEX IF EXISTS public."IDX_action_task_status";
DROP INDEX IF EXISTS public."IDX_action_task_started";
DROP INDEX IF EXISTS public."IDX_action_task_runner_id";
DROP INDEX IF EXISTS public."IDX_action_task_repo_id";
DROP INDEX IF EXISTS public."IDX_action_task_owner_id";
DROP INDEX IF EXISTS public."IDX_action_task_output_task_id";
DROP INDEX IF EXISTS public."IDX_action_task_commit_sha";
DROP INDEX IF EXISTS public."IDX_action_schedule_spec_schedule_id";
DROP INDEX IF EXISTS public."IDX_action_schedule_spec_repo_id";
DROP INDEX IF EXISTS public."IDX_action_schedule_spec_next";
DROP INDEX IF EXISTS public."IDX_action_schedule_repo_id";
DROP INDEX IF EXISTS public."IDX_action_schedule_owner_id";
DROP INDEX IF EXISTS public."IDX_action_runner_token_repo_id";
DROP INDEX IF EXISTS public."IDX_action_runner_token_owner_id";
DROP INDEX IF EXISTS public."IDX_action_runner_repo_id";
DROP INDEX IF EXISTS public."IDX_action_runner_owner_id";
DROP INDEX IF EXISTS public."IDX_action_runner_last_online";
DROP INDEX IF EXISTS public."IDX_action_runner_last_active";
DROP INDEX IF EXISTS public."IDX_action_run_workflow_id";
DROP INDEX IF EXISTS public."IDX_action_run_trigger_user_id";
DROP INDEX IF EXISTS public."IDX_action_run_status";
DROP INDEX IF EXISTS public."IDX_action_run_repo_id";
DROP INDEX IF EXISTS public."IDX_action_run_ref";
DROP INDEX IF EXISTS public."IDX_action_run_owner_id";
DROP INDEX IF EXISTS public."IDX_action_run_job_updated";
DROP INDEX IF EXISTS public."IDX_action_run_job_status";
DROP INDEX IF EXISTS public."IDX_action_run_job_run_id";
DROP INDEX IF EXISTS public."IDX_action_run_job_repo_id";
DROP INDEX IF EXISTS public."IDX_action_run_job_owner_id";
DROP INDEX IF EXISTS public."IDX_action_run_job_commit_sha";
DROP INDEX IF EXISTS public."IDX_action_run_index_max_index";
DROP INDEX IF EXISTS public."IDX_action_run_index";
DROP INDEX IF EXISTS public."IDX_action_run_approved_by";
DROP INDEX IF EXISTS public."IDX_action_r_u_d";
DROP INDEX IF EXISTS public."IDX_action_comment_id";
DROP INDEX IF EXISTS public."IDX_action_c_u_d";
DROP INDEX IF EXISTS public."IDX_action_au_r_c_u_d";
DROP INDEX IF EXISTS public."IDX_action_artifact_updated_unix";
DROP INDEX IF EXISTS public."IDX_action_artifact_status";
DROP INDEX IF EXISTS public."IDX_action_artifact_run_id";
DROP INDEX IF EXISTS public."IDX_action_artifact_repo_id";
DROP INDEX IF EXISTS public."IDX_action_artifact_expired_unix";
DROP INDEX IF EXISTS public."IDX_action_artifact_artifact_path";
DROP INDEX IF EXISTS public."IDX_action_artifact_artifact_name";
DROP INDEX IF EXISTS public."IDX_access_token_updated_unix";
DROP INDEX IF EXISTS public."IDX_access_token_uid";
DROP INDEX IF EXISTS public."IDX_access_token_token_last_eight";
DROP INDEX IF EXISTS public."IDX_access_token_created_unix";
ALTER TABLE IF EXISTS ONLY public.webhook DROP CONSTRAINT IF EXISTS webhook_pkey;
ALTER TABLE IF EXISTS ONLY public.webauthn_credential DROP CONSTRAINT IF EXISTS webauthn_credential_pkey;
ALTER TABLE IF EXISTS ONLY public.watch DROP CONSTRAINT IF EXISTS watch_pkey;
ALTER TABLE IF EXISTS ONLY public.version DROP CONSTRAINT IF EXISTS version_pkey;
ALTER TABLE IF EXISTS ONLY public.user_setting DROP CONSTRAINT IF EXISTS user_setting_pkey;
ALTER TABLE IF EXISTS ONLY public.user_redirect DROP CONSTRAINT IF EXISTS user_redirect_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_pkey;
ALTER TABLE IF EXISTS ONLY public.user_open_id DROP CONSTRAINT IF EXISTS user_open_id_pkey;
ALTER TABLE IF EXISTS ONLY public.user_blocking DROP CONSTRAINT IF EXISTS user_blocking_pkey;
ALTER TABLE IF EXISTS ONLY public.user_badge DROP CONSTRAINT IF EXISTS user_badge_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uq_users_email;
ALTER TABLE IF EXISTS ONLY public.trusted_assistants DROP CONSTRAINT IF EXISTS uq_teacher_assistant;
ALTER TABLE IF EXISTS ONLY public.submissions DROP CONSTRAINT IF EXISTS uq_submissions_assignment_id_student_id;
ALTER TABLE IF EXISTS ONLY public.student_repositories DROP CONSTRAINT IF EXISTS uq_student_repositories_repo_name;
ALTER TABLE IF EXISTS ONLY public.student_repositories DROP CONSTRAINT IF EXISTS uq_student_repositories_assignment_id_student_id;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS uq_role_permission;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS uq_notifications_user_dedupe;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS uq_course_enrollments_course_id_student_id;
ALTER TABLE IF EXISTS ONLY public.upload DROP CONSTRAINT IF EXISTS upload_pkey;
ALTER TABLE IF EXISTS ONLY public.two_factor DROP CONSTRAINT IF EXISTS two_factor_pkey;
ALTER TABLE IF EXISTS ONLY public.tracked_time DROP CONSTRAINT IF EXISTS tracked_time_pkey;
ALTER TABLE IF EXISTS ONLY public.topic DROP CONSTRAINT IF EXISTS topic_pkey;
ALTER TABLE IF EXISTS ONLY public.team_user DROP CONSTRAINT IF EXISTS team_user_pkey;
ALTER TABLE IF EXISTS ONLY public.team_unit DROP CONSTRAINT IF EXISTS team_unit_pkey;
ALTER TABLE IF EXISTS ONLY public.team_repo DROP CONSTRAINT IF EXISTS team_repo_pkey;
ALTER TABLE IF EXISTS ONLY public.team DROP CONSTRAINT IF EXISTS team_pkey;
ALTER TABLE IF EXISTS ONLY public.team_invite DROP CONSTRAINT IF EXISTS team_invite_pkey;
ALTER TABLE IF EXISTS ONLY public.task DROP CONSTRAINT IF EXISTS task_pkey;
ALTER TABLE IF EXISTS ONLY public.system_setting DROP CONSTRAINT IF EXISTS system_setting_pkey;
ALTER TABLE IF EXISTS ONLY public.stopwatch DROP CONSTRAINT IF EXISTS stopwatch_pkey;
ALTER TABLE IF EXISTS ONLY public.star DROP CONSTRAINT IF EXISTS star_pkey;
ALTER TABLE IF EXISTS ONLY public.session DROP CONSTRAINT IF EXISTS session_pkey;
ALTER TABLE IF EXISTS ONLY public.secret DROP CONSTRAINT IF EXISTS secret_pkey;
ALTER TABLE IF EXISTS ONLY public.review_state DROP CONSTRAINT IF EXISTS review_state_pkey;
ALTER TABLE IF EXISTS ONLY public.review DROP CONSTRAINT IF EXISTS review_pkey;
ALTER TABLE IF EXISTS ONLY public.repository DROP CONSTRAINT IF EXISTS repository_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_unit DROP CONSTRAINT IF EXISTS repo_unit_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_transfer DROP CONSTRAINT IF EXISTS repo_transfer_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_topic DROP CONSTRAINT IF EXISTS repo_topic_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_redirect DROP CONSTRAINT IF EXISTS repo_redirect_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_indexer_status DROP CONSTRAINT IF EXISTS repo_indexer_status_pkey;
ALTER TABLE IF EXISTS ONLY public.repo_archiver DROP CONSTRAINT IF EXISTS repo_archiver_pkey;
ALTER TABLE IF EXISTS ONLY public.renamed_branch DROP CONSTRAINT IF EXISTS renamed_branch_pkey;
ALTER TABLE IF EXISTS ONLY public.release DROP CONSTRAINT IF EXISTS release_pkey;
ALTER TABLE IF EXISTS ONLY public.reaction DROP CONSTRAINT IF EXISTS reaction_pkey;
ALTER TABLE IF EXISTS ONLY public.push_mirror DROP CONSTRAINT IF EXISTS push_mirror_pkey;
ALTER TABLE IF EXISTS ONLY public.pull_request DROP CONSTRAINT IF EXISTS pull_request_pkey;
ALTER TABLE IF EXISTS ONLY public.pull_auto_merge DROP CONSTRAINT IF EXISTS pull_auto_merge_pkey;
ALTER TABLE IF EXISTS ONLY public.public_key DROP CONSTRAINT IF EXISTS public_key_pkey;
ALTER TABLE IF EXISTS ONLY public.protected_tag DROP CONSTRAINT IF EXISTS protected_tag_pkey;
ALTER TABLE IF EXISTS ONLY public.protected_branch DROP CONSTRAINT IF EXISTS protected_branch_pkey;
ALTER TABLE IF EXISTS ONLY public.project DROP CONSTRAINT IF EXISTS project_pkey;
ALTER TABLE IF EXISTS ONLY public.project_issue DROP CONSTRAINT IF EXISTS project_issue_pkey;
ALTER TABLE IF EXISTS ONLY public.project_board DROP CONSTRAINT IF EXISTS project_board_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users;
ALTER TABLE IF EXISTS ONLY public.trusted_assistants DROP CONSTRAINT IF EXISTS pk_trusted_assistants;
ALTER TABLE IF EXISTS ONLY public.system_logs DROP CONSTRAINT IF EXISTS pk_system_logs;
ALTER TABLE IF EXISTS ONLY public.submissions DROP CONSTRAINT IF EXISTS pk_submissions;
ALTER TABLE IF EXISTS ONLY public.student_repositories DROP CONSTRAINT IF EXISTS pk_student_repositories;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS pk_role_permissions;
ALTER TABLE IF EXISTS ONLY public.repositories DROP CONSTRAINT IF EXISTS pk_repositories;
ALTER TABLE IF EXISTS ONLY public.permission_audit DROP CONSTRAINT IF EXISTS pk_permission_audit;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS pk_password_reset_tokens;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS pk_notifications;
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS pk_courses;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS pk_course_enrollments;
ALTER TABLE IF EXISTS ONLY public.assignments DROP CONSTRAINT IF EXISTS pk_assignments;
ALTER TABLE IF EXISTS ONLY public.assignment_files DROP CONSTRAINT IF EXISTS pk_assignment_files;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS pk_activity_log;
ALTER TABLE IF EXISTS ONLY public.package_version DROP CONSTRAINT IF EXISTS package_version_pkey;
ALTER TABLE IF EXISTS ONLY public.package_property DROP CONSTRAINT IF EXISTS package_property_pkey;
ALTER TABLE IF EXISTS ONLY public.package DROP CONSTRAINT IF EXISTS package_pkey;
ALTER TABLE IF EXISTS ONLY public.package_file DROP CONSTRAINT IF EXISTS package_file_pkey;
ALTER TABLE IF EXISTS ONLY public.package_cleanup_rule DROP CONSTRAINT IF EXISTS package_cleanup_rule_pkey;
ALTER TABLE IF EXISTS ONLY public.package_blob_upload DROP CONSTRAINT IF EXISTS package_blob_upload_pkey;
ALTER TABLE IF EXISTS ONLY public.package_blob DROP CONSTRAINT IF EXISTS package_blob_pkey;
ALTER TABLE IF EXISTS ONLY public.org_user DROP CONSTRAINT IF EXISTS org_user_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2_grant DROP CONSTRAINT IF EXISTS oauth2_grant_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2_authorization_code DROP CONSTRAINT IF EXISTS oauth2_authorization_code_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth2_application DROP CONSTRAINT IF EXISTS oauth2_application_pkey;
ALTER TABLE IF EXISTS ONLY public.notification DROP CONSTRAINT IF EXISTS notification_pkey;
ALTER TABLE IF EXISTS ONLY public.notice DROP CONSTRAINT IF EXISTS notice_pkey;
ALTER TABLE IF EXISTS ONLY public.mirror DROP CONSTRAINT IF EXISTS mirror_pkey;
ALTER TABLE IF EXISTS ONLY public.milestone DROP CONSTRAINT IF EXISTS milestone_pkey;
ALTER TABLE IF EXISTS ONLY public.login_source DROP CONSTRAINT IF EXISTS login_source_pkey;
ALTER TABLE IF EXISTS ONLY public.lfs_meta_object DROP CONSTRAINT IF EXISTS lfs_meta_object_pkey;
ALTER TABLE IF EXISTS ONLY public.lfs_lock DROP CONSTRAINT IF EXISTS lfs_lock_pkey;
ALTER TABLE IF EXISTS ONLY public.language_stat DROP CONSTRAINT IF EXISTS language_stat_pkey;
ALTER TABLE IF EXISTS ONLY public.label DROP CONSTRAINT IF EXISTS label_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_watch DROP CONSTRAINT IF EXISTS issue_watch_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_user DROP CONSTRAINT IF EXISTS issue_user_pkey;
ALTER TABLE IF EXISTS ONLY public.issue DROP CONSTRAINT IF EXISTS issue_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_label DROP CONSTRAINT IF EXISTS issue_label_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_index DROP CONSTRAINT IF EXISTS issue_index_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_dependency DROP CONSTRAINT IF EXISTS issue_dependency_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_content_history DROP CONSTRAINT IF EXISTS issue_content_history_pkey;
ALTER TABLE IF EXISTS ONLY public.issue_assignees DROP CONSTRAINT IF EXISTS issue_assignees_pkey;
ALTER TABLE IF EXISTS ONLY public.hook_task DROP CONSTRAINT IF EXISTS hook_task_pkey;
ALTER TABLE IF EXISTS ONLY public.gpg_key DROP CONSTRAINT IF EXISTS gpg_key_pkey;
ALTER TABLE IF EXISTS ONLY public.gpg_key_import DROP CONSTRAINT IF EXISTS gpg_key_import_pkey;
ALTER TABLE IF EXISTS ONLY public.follow DROP CONSTRAINT IF EXISTS follow_pkey;
ALTER TABLE IF EXISTS ONLY public.external_login_user DROP CONSTRAINT IF EXISTS external_login_user_pkey;
ALTER TABLE IF EXISTS ONLY public.email_hash DROP CONSTRAINT IF EXISTS email_hash_pkey;
ALTER TABLE IF EXISTS ONLY public.email_address DROP CONSTRAINT IF EXISTS email_address_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_key DROP CONSTRAINT IF EXISTS deploy_key_pkey;
ALTER TABLE IF EXISTS ONLY public.dbfs_meta DROP CONSTRAINT IF EXISTS dbfs_meta_pkey;
ALTER TABLE IF EXISTS ONLY public.dbfs_data DROP CONSTRAINT IF EXISTS dbfs_data_pkey;
ALTER TABLE IF EXISTS ONLY public.commit_status_summary DROP CONSTRAINT IF EXISTS commit_status_summary_pkey;
ALTER TABLE IF EXISTS ONLY public.commit_status DROP CONSTRAINT IF EXISTS commit_status_pkey;
ALTER TABLE IF EXISTS ONLY public.commit_status_index DROP CONSTRAINT IF EXISTS commit_status_index_pkey;
ALTER TABLE IF EXISTS ONLY public.comment DROP CONSTRAINT IF EXISTS comment_pkey;
ALTER TABLE IF EXISTS ONLY public.collaboration DROP CONSTRAINT IF EXISTS collaboration_pkey;
ALTER TABLE IF EXISTS ONLY public.branch DROP CONSTRAINT IF EXISTS branch_pkey;
ALTER TABLE IF EXISTS ONLY public.badge DROP CONSTRAINT IF EXISTS badge_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_token DROP CONSTRAINT IF EXISTS auth_token_pkey;
ALTER TABLE IF EXISTS ONLY public.attachment DROP CONSTRAINT IF EXISTS attachment_pkey;
ALTER TABLE IF EXISTS ONLY public.app_state DROP CONSTRAINT IF EXISTS app_state_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS ONLY public.action_variable DROP CONSTRAINT IF EXISTS action_variable_pkey;
ALTER TABLE IF EXISTS ONLY public.action_tasks_version DROP CONSTRAINT IF EXISTS action_tasks_version_pkey;
ALTER TABLE IF EXISTS ONLY public.action_task_step DROP CONSTRAINT IF EXISTS action_task_step_pkey;
ALTER TABLE IF EXISTS ONLY public.action_task DROP CONSTRAINT IF EXISTS action_task_pkey;
ALTER TABLE IF EXISTS ONLY public.action_task_output DROP CONSTRAINT IF EXISTS action_task_output_pkey;
ALTER TABLE IF EXISTS ONLY public.action_schedule_spec DROP CONSTRAINT IF EXISTS action_schedule_spec_pkey;
ALTER TABLE IF EXISTS ONLY public.action_schedule DROP CONSTRAINT IF EXISTS action_schedule_pkey;
ALTER TABLE IF EXISTS ONLY public.action_runner_token DROP CONSTRAINT IF EXISTS action_runner_token_pkey;
ALTER TABLE IF EXISTS ONLY public.action_runner DROP CONSTRAINT IF EXISTS action_runner_pkey;
ALTER TABLE IF EXISTS ONLY public.action_run DROP CONSTRAINT IF EXISTS action_run_pkey;
ALTER TABLE IF EXISTS ONLY public.action_run_job DROP CONSTRAINT IF EXISTS action_run_job_pkey;
ALTER TABLE IF EXISTS ONLY public.action_run_index DROP CONSTRAINT IF EXISTS action_run_index_pkey;
ALTER TABLE IF EXISTS ONLY public.action DROP CONSTRAINT IF EXISTS action_pkey;
ALTER TABLE IF EXISTS ONLY public.action_artifact DROP CONSTRAINT IF EXISTS action_artifact_pkey;
ALTER TABLE IF EXISTS ONLY public.access_token DROP CONSTRAINT IF EXISTS access_token_pkey;
ALTER TABLE IF EXISTS ONLY public.access DROP CONSTRAINT IF EXISTS access_pkey;
ALTER TABLE IF EXISTS public.webhook ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.webauthn_credential ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_setting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_open_id ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_blocking ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_badge ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.upload ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.two_factor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tracked_time ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.topic ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_repo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team_invite ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.team ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system_setting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stopwatch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.star ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.secret ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_state ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repository ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_unit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_transfer ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_indexer_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repo_archiver ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.renamed_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.release ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reaction ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.push_mirror ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pull_request ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pull_auto_merge ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.public_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.protected_tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.protected_branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_issue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_board ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package_version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package_property ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package_file ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package_cleanup_rule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package_blob ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.package ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.org_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth2_grant ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth2_authorization_code ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth2_application ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notice ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mirror ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.milestone ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.login_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lfs_meta_object ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lfs_lock ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.language_stat ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_watch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_label ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_dependency ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_content_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue_assignees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.issue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hook_task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gpg_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.follow ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.email_address ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deploy_key ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dbfs_meta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.dbfs_data ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commit_status_summary ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commit_status_index ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commit_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.collaboration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.branch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.badge ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_variable ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_tasks_version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_task_step ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_task_output ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_schedule_spec ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_schedule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_runner_token ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_runner ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_run_job ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_run ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action_artifact ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.action ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.access_token ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.access ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.webhook_id_seq;
DROP TABLE IF EXISTS public.webhook;
DROP SEQUENCE IF EXISTS public.webauthn_credential_id_seq;
DROP TABLE IF EXISTS public.webauthn_credential;
DROP SEQUENCE IF EXISTS public.watch_id_seq;
DROP TABLE IF EXISTS public.watch;
DROP SEQUENCE IF EXISTS public.version_id_seq;
DROP TABLE IF EXISTS public.version;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_setting_id_seq;
DROP TABLE IF EXISTS public.user_setting;
DROP SEQUENCE IF EXISTS public.user_redirect_id_seq;
DROP TABLE IF EXISTS public.user_redirect;
DROP SEQUENCE IF EXISTS public.user_open_id_id_seq;
DROP TABLE IF EXISTS public.user_open_id;
DROP SEQUENCE IF EXISTS public.user_id_seq;
DROP SEQUENCE IF EXISTS public.user_blocking_id_seq;
DROP TABLE IF EXISTS public.user_blocking;
DROP SEQUENCE IF EXISTS public.user_badge_id_seq;
DROP TABLE IF EXISTS public.user_badge;
DROP TABLE IF EXISTS public."user";
DROP SEQUENCE IF EXISTS public.upload_id_seq;
DROP TABLE IF EXISTS public.upload;
DROP SEQUENCE IF EXISTS public.two_factor_id_seq;
DROP TABLE IF EXISTS public.two_factor;
DROP TABLE IF EXISTS public.trusted_assistants;
DROP SEQUENCE IF EXISTS public.tracked_time_id_seq;
DROP TABLE IF EXISTS public.tracked_time;
DROP SEQUENCE IF EXISTS public.topic_id_seq;
DROP TABLE IF EXISTS public.topic;
DROP SEQUENCE IF EXISTS public.team_user_id_seq;
DROP TABLE IF EXISTS public.team_user;
DROP SEQUENCE IF EXISTS public.team_unit_id_seq;
DROP TABLE IF EXISTS public.team_unit;
DROP SEQUENCE IF EXISTS public.team_repo_id_seq;
DROP TABLE IF EXISTS public.team_repo;
DROP SEQUENCE IF EXISTS public.team_invite_id_seq;
DROP TABLE IF EXISTS public.team_invite;
DROP SEQUENCE IF EXISTS public.team_id_seq;
DROP TABLE IF EXISTS public.team;
DROP SEQUENCE IF EXISTS public.task_id_seq;
DROP TABLE IF EXISTS public.task;
DROP SEQUENCE IF EXISTS public.system_setting_id_seq;
DROP TABLE IF EXISTS public.system_setting;
DROP TABLE IF EXISTS public.system_logs;
DROP TABLE IF EXISTS public.submissions;
DROP TABLE IF EXISTS public.student_repositories;
DROP SEQUENCE IF EXISTS public.stopwatch_id_seq;
DROP TABLE IF EXISTS public.stopwatch;
DROP SEQUENCE IF EXISTS public.star_id_seq;
DROP TABLE IF EXISTS public.star;
DROP TABLE IF EXISTS public.session;
DROP SEQUENCE IF EXISTS public.secret_id_seq;
DROP TABLE IF EXISTS public.secret;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.review_state_id_seq;
DROP TABLE IF EXISTS public.review_state;
DROP SEQUENCE IF EXISTS public.review_id_seq;
DROP TABLE IF EXISTS public.review;
DROP SEQUENCE IF EXISTS public.repository_id_seq;
DROP TABLE IF EXISTS public.repository;
DROP TABLE IF EXISTS public.repositories;
DROP SEQUENCE IF EXISTS public.repo_unit_id_seq;
DROP TABLE IF EXISTS public.repo_unit;
DROP SEQUENCE IF EXISTS public.repo_transfer_id_seq;
DROP TABLE IF EXISTS public.repo_transfer;
DROP TABLE IF EXISTS public.repo_topic;
DROP SEQUENCE IF EXISTS public.repo_redirect_id_seq;
DROP TABLE IF EXISTS public.repo_redirect;
DROP SEQUENCE IF EXISTS public.repo_indexer_status_id_seq;
DROP TABLE IF EXISTS public.repo_indexer_status;
DROP SEQUENCE IF EXISTS public.repo_archiver_id_seq;
DROP TABLE IF EXISTS public.repo_archiver;
DROP SEQUENCE IF EXISTS public.renamed_branch_id_seq;
DROP TABLE IF EXISTS public.renamed_branch;
DROP SEQUENCE IF EXISTS public.release_id_seq;
DROP TABLE IF EXISTS public.release;
DROP SEQUENCE IF EXISTS public.reaction_id_seq;
DROP TABLE IF EXISTS public.reaction;
DROP SEQUENCE IF EXISTS public.push_mirror_id_seq;
DROP TABLE IF EXISTS public.push_mirror;
DROP SEQUENCE IF EXISTS public.pull_request_id_seq;
DROP TABLE IF EXISTS public.pull_request;
DROP SEQUENCE IF EXISTS public.pull_auto_merge_id_seq;
DROP TABLE IF EXISTS public.pull_auto_merge;
DROP SEQUENCE IF EXISTS public.public_key_id_seq;
DROP TABLE IF EXISTS public.public_key;
DROP SEQUENCE IF EXISTS public.protected_tag_id_seq;
DROP TABLE IF EXISTS public.protected_tag;
DROP SEQUENCE IF EXISTS public.protected_branch_id_seq;
DROP TABLE IF EXISTS public.protected_branch;
DROP SEQUENCE IF EXISTS public.project_issue_id_seq;
DROP TABLE IF EXISTS public.project_issue;
DROP SEQUENCE IF EXISTS public.project_id_seq;
DROP SEQUENCE IF EXISTS public.project_board_id_seq;
DROP TABLE IF EXISTS public.project_board;
DROP TABLE IF EXISTS public.project;
DROP TABLE IF EXISTS public.permission_audit;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP SEQUENCE IF EXISTS public.package_version_id_seq;
DROP TABLE IF EXISTS public.package_version;
DROP SEQUENCE IF EXISTS public.package_property_id_seq;
DROP TABLE IF EXISTS public.package_property;
DROP SEQUENCE IF EXISTS public.package_id_seq;
DROP SEQUENCE IF EXISTS public.package_file_id_seq;
DROP TABLE IF EXISTS public.package_file;
DROP SEQUENCE IF EXISTS public.package_cleanup_rule_id_seq;
DROP TABLE IF EXISTS public.package_cleanup_rule;
DROP TABLE IF EXISTS public.package_blob_upload;
DROP SEQUENCE IF EXISTS public.package_blob_id_seq;
DROP TABLE IF EXISTS public.package_blob;
DROP TABLE IF EXISTS public.package;
DROP SEQUENCE IF EXISTS public.org_user_id_seq;
DROP TABLE IF EXISTS public.org_user;
DROP SEQUENCE IF EXISTS public.oauth2_grant_id_seq;
DROP TABLE IF EXISTS public.oauth2_grant;
DROP SEQUENCE IF EXISTS public.oauth2_authorization_code_id_seq;
DROP TABLE IF EXISTS public.oauth2_authorization_code;
DROP SEQUENCE IF EXISTS public.oauth2_application_id_seq;
DROP TABLE IF EXISTS public.oauth2_application;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notification_id_seq;
DROP TABLE IF EXISTS public.notification;
DROP SEQUENCE IF EXISTS public.notice_id_seq;
DROP TABLE IF EXISTS public.notice;
DROP SEQUENCE IF EXISTS public.mirror_id_seq;
DROP TABLE IF EXISTS public.mirror;
DROP SEQUENCE IF EXISTS public.milestone_id_seq;
DROP TABLE IF EXISTS public.milestone;
DROP SEQUENCE IF EXISTS public.login_source_id_seq;
DROP TABLE IF EXISTS public.login_source;
DROP SEQUENCE IF EXISTS public.lfs_meta_object_id_seq;
DROP TABLE IF EXISTS public.lfs_meta_object;
DROP SEQUENCE IF EXISTS public.lfs_lock_id_seq;
DROP TABLE IF EXISTS public.lfs_lock;
DROP SEQUENCE IF EXISTS public.language_stat_id_seq;
DROP TABLE IF EXISTS public.language_stat;
DROP SEQUENCE IF EXISTS public.label_id_seq;
DROP TABLE IF EXISTS public.label;
DROP SEQUENCE IF EXISTS public.issue_watch_id_seq;
DROP TABLE IF EXISTS public.issue_watch;
DROP SEQUENCE IF EXISTS public.issue_user_id_seq;
DROP TABLE IF EXISTS public.issue_user;
DROP SEQUENCE IF EXISTS public.issue_label_id_seq;
DROP TABLE IF EXISTS public.issue_label;
DROP TABLE IF EXISTS public.issue_index;
DROP SEQUENCE IF EXISTS public.issue_id_seq;
DROP SEQUENCE IF EXISTS public.issue_dependency_id_seq;
DROP TABLE IF EXISTS public.issue_dependency;
DROP SEQUENCE IF EXISTS public.issue_content_history_id_seq;
DROP TABLE IF EXISTS public.issue_content_history;
DROP SEQUENCE IF EXISTS public.issue_assignees_id_seq;
DROP TABLE IF EXISTS public.issue_assignees;
DROP TABLE IF EXISTS public.issue;
DROP SEQUENCE IF EXISTS public.hook_task_id_seq;
DROP TABLE IF EXISTS public.hook_task;
DROP TABLE IF EXISTS public.gpg_key_import;
DROP SEQUENCE IF EXISTS public.gpg_key_id_seq;
DROP TABLE IF EXISTS public.gpg_key;
DROP SEQUENCE IF EXISTS public.follow_id_seq;
DROP TABLE IF EXISTS public.follow;
DROP TABLE IF EXISTS public.external_login_user;
DROP TABLE IF EXISTS public.email_hash;
DROP SEQUENCE IF EXISTS public.email_address_id_seq;
DROP TABLE IF EXISTS public.email_address;
DROP SEQUENCE IF EXISTS public.deploy_key_id_seq;
DROP TABLE IF EXISTS public.deploy_key;
DROP SEQUENCE IF EXISTS public.dbfs_meta_id_seq;
DROP TABLE IF EXISTS public.dbfs_meta;
DROP SEQUENCE IF EXISTS public.dbfs_data_id_seq;
DROP TABLE IF EXISTS public.dbfs_data;
DROP TABLE IF EXISTS public.courses;
DROP TABLE IF EXISTS public.course_enrollments;
DROP SEQUENCE IF EXISTS public.commit_status_summary_id_seq;
DROP TABLE IF EXISTS public.commit_status_summary;
DROP SEQUENCE IF EXISTS public.commit_status_index_id_seq;
DROP TABLE IF EXISTS public.commit_status_index;
DROP SEQUENCE IF EXISTS public.commit_status_id_seq;
DROP TABLE IF EXISTS public.commit_status;
DROP SEQUENCE IF EXISTS public.comment_id_seq;
DROP TABLE IF EXISTS public.comment;
DROP SEQUENCE IF EXISTS public.collaboration_id_seq;
DROP TABLE IF EXISTS public.collaboration;
DROP SEQUENCE IF EXISTS public.branch_id_seq;
DROP TABLE IF EXISTS public.branch;
DROP SEQUENCE IF EXISTS public.badge_id_seq;
DROP TABLE IF EXISTS public.badge;
DROP TABLE IF EXISTS public.auth_token;
DROP SEQUENCE IF EXISTS public.attachment_id_seq;
DROP TABLE IF EXISTS public.attachment;
DROP TABLE IF EXISTS public.assignments;
DROP TABLE IF EXISTS public.assignment_files;
DROP TABLE IF EXISTS public.app_state;
DROP TABLE IF EXISTS public.alembic_version;
DROP TABLE IF EXISTS public.activity_log;
DROP SEQUENCE IF EXISTS public.action_variable_id_seq;
DROP TABLE IF EXISTS public.action_variable;
DROP SEQUENCE IF EXISTS public.action_tasks_version_id_seq;
DROP TABLE IF EXISTS public.action_tasks_version;
DROP SEQUENCE IF EXISTS public.action_task_step_id_seq;
DROP TABLE IF EXISTS public.action_task_step;
DROP SEQUENCE IF EXISTS public.action_task_output_id_seq;
DROP TABLE IF EXISTS public.action_task_output;
DROP SEQUENCE IF EXISTS public.action_task_id_seq;
DROP TABLE IF EXISTS public.action_task;
DROP SEQUENCE IF EXISTS public.action_schedule_spec_id_seq;
DROP TABLE IF EXISTS public.action_schedule_spec;
DROP SEQUENCE IF EXISTS public.action_schedule_id_seq;
DROP TABLE IF EXISTS public.action_schedule;
DROP SEQUENCE IF EXISTS public.action_runner_token_id_seq;
DROP TABLE IF EXISTS public.action_runner_token;
DROP SEQUENCE IF EXISTS public.action_runner_id_seq;
DROP TABLE IF EXISTS public.action_runner;
DROP SEQUENCE IF EXISTS public.action_run_job_id_seq;
DROP TABLE IF EXISTS public.action_run_job;
DROP TABLE IF EXISTS public.action_run_index;
DROP SEQUENCE IF EXISTS public.action_run_id_seq;
DROP TABLE IF EXISTS public.action_run;
DROP SEQUENCE IF EXISTS public.action_id_seq;
DROP SEQUENCE IF EXISTS public.action_artifact_id_seq;
DROP TABLE IF EXISTS public.action_artifact;
DROP TABLE IF EXISTS public.action;
DROP SEQUENCE IF EXISTS public.access_token_id_seq;
DROP TABLE IF EXISTS public.access_token;
DROP SEQUENCE IF EXISTS public.access_id_seq;
DROP TABLE IF EXISTS public.access;
DROP TYPE IF EXISTS public.user_role;
DROP TYPE IF EXISTS public.repository_type;
DROP TYPE IF EXISTS public.avatar_display_mode;
DROP EXTENSION IF EXISTS pg_stat_statements;
--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: avatar_display_mode; Type: TYPE; Schema: public; Owner: mtuci
--

CREATE TYPE public.avatar_display_mode AS ENUM (
    'cover',
    'contain',
    'fill',
    'scale-down'
);


ALTER TYPE public.avatar_display_mode OWNER TO mtuci;

--
-- Name: repository_type; Type: TYPE; Schema: public; Owner: mtuci
--

CREATE TYPE public.repository_type AS ENUM (
    'public',
    'private',
    'course'
);


ALTER TYPE public.repository_type OWNER TO mtuci;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: mtuci
--

CREATE TYPE public.user_role AS ENUM (
    'student',
    'teacher',
    'admin'
);


ALTER TYPE public.user_role OWNER TO mtuci;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.access (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint,
    mode integer
);


ALTER TABLE public.access OWNER TO mtuci;

--
-- Name: access_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_id_seq OWNER TO mtuci;

--
-- Name: access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.access_id_seq OWNED BY public.access.id;


--
-- Name: access_token; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.access_token (
    id bigint NOT NULL,
    uid bigint,
    name character varying(255),
    token_hash character varying(255),
    token_salt character varying(255),
    token_last_eight character varying(255),
    scope character varying(255),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.access_token OWNER TO mtuci;

--
-- Name: access_token_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.access_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_token_id_seq OWNER TO mtuci;

--
-- Name: access_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.access_token_id_seq OWNED BY public.access_token.id;


--
-- Name: action; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action (
    id bigint NOT NULL,
    user_id bigint,
    op_type integer,
    act_user_id bigint,
    repo_id bigint,
    comment_id bigint,
    is_deleted boolean DEFAULT false NOT NULL,
    ref_name character varying(255),
    is_private boolean DEFAULT false NOT NULL,
    content text,
    created_unix bigint
);


ALTER TABLE public.action OWNER TO mtuci;

--
-- Name: action_artifact; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_artifact (
    id bigint NOT NULL,
    run_id bigint,
    runner_id bigint,
    repo_id bigint,
    owner_id bigint,
    commit_sha character varying(255),
    storage_path character varying(255),
    file_size bigint,
    file_compressed_size bigint,
    content_encoding character varying(255),
    artifact_path character varying(255),
    artifact_name character varying(255),
    status bigint,
    created_unix bigint,
    updated_unix bigint,
    expired_unix bigint
);


ALTER TABLE public.action_artifact OWNER TO mtuci;

--
-- Name: action_artifact_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_artifact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_artifact_id_seq OWNER TO mtuci;

--
-- Name: action_artifact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_artifact_id_seq OWNED BY public.action_artifact.id;


--
-- Name: action_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_id_seq OWNER TO mtuci;

--
-- Name: action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_id_seq OWNED BY public.action.id;


--
-- Name: action_run; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_run (
    id bigint NOT NULL,
    title character varying(255),
    repo_id bigint,
    owner_id bigint,
    workflow_id character varying(255),
    index bigint,
    trigger_user_id bigint,
    schedule_id bigint,
    ref character varying(255),
    commit_sha character varying(255),
    is_fork_pull_request boolean,
    need_approval boolean,
    approved_by bigint,
    event character varying(255),
    event_payload text,
    trigger_event character varying(255),
    status integer,
    version integer DEFAULT 0,
    started bigint,
    stopped bigint,
    previous_duration bigint,
    created bigint,
    updated bigint
);


ALTER TABLE public.action_run OWNER TO mtuci;

--
-- Name: action_run_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_run_id_seq OWNER TO mtuci;

--
-- Name: action_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_run_id_seq OWNED BY public.action_run.id;


--
-- Name: action_run_index; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_run_index (
    group_id bigint NOT NULL,
    max_index bigint
);


ALTER TABLE public.action_run_index OWNER TO mtuci;

--
-- Name: action_run_job; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_run_job (
    id bigint NOT NULL,
    run_id bigint,
    repo_id bigint,
    owner_id bigint,
    commit_sha character varying(255),
    is_fork_pull_request boolean,
    name character varying(255),
    attempt bigint,
    workflow_payload bytea,
    job_id character varying(255),
    needs text,
    runs_on text,
    task_id bigint,
    status integer,
    started bigint,
    stopped bigint,
    created bigint,
    updated bigint
);


ALTER TABLE public.action_run_job OWNER TO mtuci;

--
-- Name: action_run_job_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_run_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_run_job_id_seq OWNER TO mtuci;

--
-- Name: action_run_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_run_job_id_seq OWNED BY public.action_run_job.id;


--
-- Name: action_runner; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_runner (
    id bigint NOT NULL,
    uuid character(36),
    name character varying(255),
    version character varying(64),
    owner_id bigint,
    repo_id bigint,
    description text,
    base integer,
    repo_range character varying(255),
    token_hash character varying(255),
    token_salt character varying(255),
    last_online bigint,
    last_active bigint,
    agent_labels text,
    created bigint,
    updated bigint,
    deleted bigint
);


ALTER TABLE public.action_runner OWNER TO mtuci;

--
-- Name: action_runner_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_runner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_runner_id_seq OWNER TO mtuci;

--
-- Name: action_runner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_runner_id_seq OWNED BY public.action_runner.id;


--
-- Name: action_runner_token; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_runner_token (
    id bigint NOT NULL,
    token character varying(255),
    owner_id bigint,
    repo_id bigint,
    is_active boolean,
    created bigint,
    updated bigint,
    deleted bigint
);


ALTER TABLE public.action_runner_token OWNER TO mtuci;

--
-- Name: action_runner_token_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_runner_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_runner_token_id_seq OWNER TO mtuci;

--
-- Name: action_runner_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_runner_token_id_seq OWNED BY public.action_runner_token.id;


--
-- Name: action_schedule; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_schedule (
    id bigint NOT NULL,
    title character varying(255),
    specs text,
    repo_id bigint,
    owner_id bigint,
    workflow_id character varying(255),
    trigger_user_id bigint,
    ref character varying(255),
    commit_sha character varying(255),
    event character varying(255),
    event_payload text,
    content bytea,
    created bigint,
    updated bigint
);


ALTER TABLE public.action_schedule OWNER TO mtuci;

--
-- Name: action_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_schedule_id_seq OWNER TO mtuci;

--
-- Name: action_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_schedule_id_seq OWNED BY public.action_schedule.id;


--
-- Name: action_schedule_spec; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_schedule_spec (
    id bigint NOT NULL,
    repo_id bigint,
    schedule_id bigint,
    next bigint,
    prev bigint,
    spec character varying(255),
    created bigint,
    updated bigint
);


ALTER TABLE public.action_schedule_spec OWNER TO mtuci;

--
-- Name: action_schedule_spec_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_schedule_spec_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_schedule_spec_id_seq OWNER TO mtuci;

--
-- Name: action_schedule_spec_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_schedule_spec_id_seq OWNED BY public.action_schedule_spec.id;


--
-- Name: action_task; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_task (
    id bigint NOT NULL,
    job_id bigint,
    attempt bigint,
    runner_id bigint,
    status integer,
    started bigint,
    stopped bigint,
    repo_id bigint,
    owner_id bigint,
    commit_sha character varying(255),
    is_fork_pull_request boolean,
    token_hash character varying(255),
    token_salt character varying(255),
    token_last_eight character varying(255),
    log_filename character varying(255),
    log_in_storage boolean,
    log_length bigint,
    log_size bigint,
    log_indexes bytea,
    log_expired boolean,
    created bigint,
    updated bigint
);


ALTER TABLE public.action_task OWNER TO mtuci;

--
-- Name: action_task_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_task_id_seq OWNER TO mtuci;

--
-- Name: action_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_task_id_seq OWNED BY public.action_task.id;


--
-- Name: action_task_output; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_task_output (
    id bigint NOT NULL,
    task_id bigint,
    output_key character varying(255),
    output_value text
);


ALTER TABLE public.action_task_output OWNER TO mtuci;

--
-- Name: action_task_output_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_task_output_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_task_output_id_seq OWNER TO mtuci;

--
-- Name: action_task_output_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_task_output_id_seq OWNED BY public.action_task_output.id;


--
-- Name: action_task_step; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_task_step (
    id bigint NOT NULL,
    name character varying(255),
    task_id bigint,
    index bigint,
    repo_id bigint,
    status integer,
    log_index bigint,
    log_length bigint,
    started bigint,
    stopped bigint,
    created bigint,
    updated bigint
);


ALTER TABLE public.action_task_step OWNER TO mtuci;

--
-- Name: action_task_step_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_task_step_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_task_step_id_seq OWNER TO mtuci;

--
-- Name: action_task_step_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_task_step_id_seq OWNED BY public.action_task_step.id;


--
-- Name: action_tasks_version; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_tasks_version (
    id bigint NOT NULL,
    owner_id bigint,
    repo_id bigint,
    version bigint,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.action_tasks_version OWNER TO mtuci;

--
-- Name: action_tasks_version_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_tasks_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_tasks_version_id_seq OWNER TO mtuci;

--
-- Name: action_tasks_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_tasks_version_id_seq OWNED BY public.action_tasks_version.id;


--
-- Name: action_variable; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.action_variable (
    id bigint NOT NULL,
    owner_id bigint,
    repo_id bigint,
    name character varying(255) NOT NULL,
    data text NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint
);


ALTER TABLE public.action_variable OWNER TO mtuci;

--
-- Name: action_variable_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.action_variable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_variable_id_seq OWNER TO mtuci;

--
-- Name: action_variable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.action_variable_id_seq OWNED BY public.action_variable.id;


--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.activity_log (
    id uuid NOT NULL,
    user_id uuid,
    activity_type character varying(20) NOT NULL,
    repo_name character varying(255),
    message character varying(500),
    ip_address character varying(45),
    user_agent character varying(500),
    created_at timestamp with time zone NOT NULL,
    user_login character varying(255)
);


ALTER TABLE public.activity_log OWNER TO mtuci;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO mtuci;

--
-- Name: app_state; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.app_state (
    id character varying(200) NOT NULL,
    revision bigint,
    content text
);


ALTER TABLE public.app_state OWNER TO mtuci;

--
-- Name: assignment_files; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.assignment_files (
    id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    original_filename character varying(255) NOT NULL,
    storage_path character varying(500) NOT NULL,
    content_type character varying(100),
    file_size integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.assignment_files OWNER TO mtuci;

--
-- Name: assignments; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.assignments (
    id uuid NOT NULL,
    course_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    deadline timestamp with time zone NOT NULL,
    gitea_repo_name character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    start_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    late_penalty_periods json DEFAULT '[]'::json NOT NULL
);


ALTER TABLE public.assignments OWNER TO mtuci;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.attachment (
    id bigint NOT NULL,
    uuid uuid,
    repo_id bigint,
    issue_id bigint,
    release_id bigint,
    uploader_id bigint DEFAULT 0,
    comment_id bigint,
    name character varying(255),
    download_count bigint DEFAULT 0,
    size bigint DEFAULT 0,
    created_unix bigint
);


ALTER TABLE public.attachment OWNER TO mtuci;

--
-- Name: attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachment_id_seq OWNER TO mtuci;

--
-- Name: attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.attachment_id_seq OWNED BY public.attachment.id;


--
-- Name: auth_token; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.auth_token (
    id character varying(255) NOT NULL,
    token_hash character varying(255),
    user_id bigint,
    expires_unix bigint
);


ALTER TABLE public.auth_token OWNER TO mtuci;

--
-- Name: badge; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.badge (
    id bigint NOT NULL,
    slug character varying(255),
    description character varying(255),
    image_url character varying(255)
);


ALTER TABLE public.badge OWNER TO mtuci;

--
-- Name: badge_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.badge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.badge_id_seq OWNER TO mtuci;

--
-- Name: badge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.badge_id_seq OWNED BY public.badge.id;


--
-- Name: branch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.branch (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255) NOT NULL,
    commit_id character varying(255),
    commit_message text,
    pusher_id bigint,
    is_deleted boolean,
    deleted_by_id bigint,
    deleted_unix bigint,
    commit_time bigint,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.branch OWNER TO mtuci;

--
-- Name: branch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.branch_id_seq OWNER TO mtuci;

--
-- Name: branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.branch_id_seq OWNED BY public.branch.id;


--
-- Name: collaboration; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.collaboration (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    user_id bigint NOT NULL,
    mode integer DEFAULT 2 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.collaboration OWNER TO mtuci;

--
-- Name: collaboration_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.collaboration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collaboration_id_seq OWNER TO mtuci;

--
-- Name: collaboration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.collaboration_id_seq OWNED BY public.collaboration.id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.comment (
    id bigint NOT NULL,
    type integer,
    poster_id bigint,
    original_author character varying(255),
    original_author_id bigint,
    issue_id bigint,
    label_id bigint,
    old_project_id bigint,
    project_id bigint,
    old_milestone_id bigint,
    milestone_id bigint,
    time_id bigint,
    assignee_id bigint,
    removed_assignee boolean,
    assignee_team_id bigint DEFAULT 0 NOT NULL,
    resolve_doer_id bigint,
    old_title character varying(255),
    new_title character varying(255),
    old_ref character varying(255),
    new_ref character varying(255),
    dependent_issue_id bigint,
    commit_id bigint,
    line bigint,
    tree_path character varying(255),
    content text,
    patch text,
    created_unix bigint,
    updated_unix bigint,
    commit_sha character varying(64),
    review_id bigint,
    invalidated boolean,
    ref_repo_id bigint,
    ref_issue_id bigint,
    ref_comment_id bigint,
    ref_action smallint,
    ref_is_pull boolean
);


ALTER TABLE public.comment OWNER TO mtuci;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comment_id_seq OWNER TO mtuci;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.id;


--
-- Name: commit_status; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.commit_status (
    id bigint NOT NULL,
    index bigint,
    repo_id bigint,
    state character varying(7) NOT NULL,
    sha character varying(64) NOT NULL,
    target_url text,
    description text,
    context_hash character varying(64),
    context text,
    creator_id bigint,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.commit_status OWNER TO mtuci;

--
-- Name: commit_status_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.commit_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commit_status_id_seq OWNER TO mtuci;

--
-- Name: commit_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.commit_status_id_seq OWNED BY public.commit_status.id;


--
-- Name: commit_status_index; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.commit_status_index (
    id bigint NOT NULL,
    repo_id bigint,
    sha character varying(255),
    max_index bigint
);


ALTER TABLE public.commit_status_index OWNER TO mtuci;

--
-- Name: commit_status_index_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.commit_status_index_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commit_status_index_id_seq OWNER TO mtuci;

--
-- Name: commit_status_index_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.commit_status_index_id_seq OWNED BY public.commit_status_index.id;


--
-- Name: commit_status_summary; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.commit_status_summary (
    id bigint NOT NULL,
    repo_id bigint,
    sha character varying(64) NOT NULL,
    state character varying(7) NOT NULL,
    target_url text
);


ALTER TABLE public.commit_status_summary OWNER TO mtuci;

--
-- Name: commit_status_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.commit_status_summary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commit_status_summary_id_seq OWNER TO mtuci;

--
-- Name: commit_status_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.commit_status_summary_id_seq OWNED BY public.commit_status_summary.id;


--
-- Name: course_enrollments; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.course_enrollments (
    id uuid NOT NULL,
    course_id uuid NOT NULL,
    student_id uuid NOT NULL,
    enrolled_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.course_enrollments OWNER TO mtuci;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.courses (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    teacher_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    grade_min integer DEFAULT 0 NOT NULL,
    grade_max integer DEFAULT 100 NOT NULL,
    target_groups character varying(50)[] DEFAULT '{}'::character varying[]
);


ALTER TABLE public.courses OWNER TO mtuci;

--
-- Name: dbfs_data; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.dbfs_data (
    id bigint NOT NULL,
    revision bigint NOT NULL,
    meta_id bigint NOT NULL,
    blob_offset bigint NOT NULL,
    blob_size bigint NOT NULL,
    blob_data bytea NOT NULL
);


ALTER TABLE public.dbfs_data OWNER TO mtuci;

--
-- Name: dbfs_data_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.dbfs_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dbfs_data_id_seq OWNER TO mtuci;

--
-- Name: dbfs_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.dbfs_data_id_seq OWNED BY public.dbfs_data.id;


--
-- Name: dbfs_meta; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.dbfs_meta (
    id bigint NOT NULL,
    full_path character varying(500) NOT NULL,
    block_size bigint NOT NULL,
    file_size bigint NOT NULL,
    create_timestamp bigint NOT NULL,
    modify_timestamp bigint NOT NULL
);


ALTER TABLE public.dbfs_meta OWNER TO mtuci;

--
-- Name: dbfs_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.dbfs_meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dbfs_meta_id_seq OWNER TO mtuci;

--
-- Name: dbfs_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.dbfs_meta_id_seq OWNED BY public.dbfs_meta.id;


--
-- Name: deploy_key; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.deploy_key (
    id bigint NOT NULL,
    key_id bigint,
    repo_id bigint,
    name character varying(255),
    fingerprint character varying(255),
    mode integer DEFAULT 1 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.deploy_key OWNER TO mtuci;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.deploy_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deploy_key_id_seq OWNER TO mtuci;

--
-- Name: deploy_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.deploy_key_id_seq OWNED BY public.deploy_key.id;


--
-- Name: email_address; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.email_address (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    email character varying(255) NOT NULL,
    lower_email character varying(255) NOT NULL,
    is_activated boolean,
    is_primary boolean DEFAULT false NOT NULL
);


ALTER TABLE public.email_address OWNER TO mtuci;

--
-- Name: email_address_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.email_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_address_id_seq OWNER TO mtuci;

--
-- Name: email_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.email_address_id_seq OWNED BY public.email_address.id;


--
-- Name: email_hash; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.email_hash (
    hash character varying(32) NOT NULL,
    email character varying(255) NOT NULL
);


ALTER TABLE public.email_hash OWNER TO mtuci;

--
-- Name: external_login_user; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.external_login_user (
    external_id character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    login_source_id bigint NOT NULL,
    raw_data json,
    provider character varying(25),
    email character varying(255),
    name character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    nick_name character varying(255),
    description character varying(255),
    avatar_url text,
    location character varying(255),
    access_token text,
    access_token_secret text,
    refresh_token text,
    expires_at timestamp without time zone
);


ALTER TABLE public.external_login_user OWNER TO mtuci;

--
-- Name: follow; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.follow (
    id bigint NOT NULL,
    user_id bigint,
    follow_id bigint,
    created_unix bigint
);


ALTER TABLE public.follow OWNER TO mtuci;

--
-- Name: follow_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.follow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follow_id_seq OWNER TO mtuci;

--
-- Name: follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.follow_id_seq OWNED BY public.follow.id;


--
-- Name: gpg_key; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.gpg_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    key_id character(16) NOT NULL,
    primary_key_id character(16),
    content text NOT NULL,
    created_unix bigint,
    expired_unix bigint,
    added_unix bigint,
    emails text,
    verified boolean DEFAULT false NOT NULL,
    can_sign boolean,
    can_encrypt_comms boolean,
    can_encrypt_storage boolean,
    can_certify boolean
);


ALTER TABLE public.gpg_key OWNER TO mtuci;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.gpg_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gpg_key_id_seq OWNER TO mtuci;

--
-- Name: gpg_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.gpg_key_id_seq OWNED BY public.gpg_key.id;


--
-- Name: gpg_key_import; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.gpg_key_import (
    key_id character(16) NOT NULL,
    content text NOT NULL
);


ALTER TABLE public.gpg_key_import OWNER TO mtuci;

--
-- Name: hook_task; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.hook_task (
    id bigint NOT NULL,
    hook_id bigint,
    uuid character varying(255),
    payload_content text,
    payload_version integer DEFAULT 1,
    event_type character varying(255),
    is_delivered boolean,
    delivered bigint,
    is_succeed boolean,
    request_content text,
    response_content text
);


ALTER TABLE public.hook_task OWNER TO mtuci;

--
-- Name: hook_task_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.hook_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hook_task_id_seq OWNER TO mtuci;

--
-- Name: hook_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.hook_task_id_seq OWNED BY public.hook_task.id;


--
-- Name: issue; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue (
    id bigint NOT NULL,
    repo_id bigint,
    index bigint,
    poster_id bigint,
    original_author character varying(255),
    original_author_id bigint,
    name character varying(255),
    content text,
    milestone_id bigint,
    priority integer,
    is_closed boolean,
    is_pull boolean,
    num_comments integer,
    ref character varying(255),
    pin_order integer DEFAULT 0,
    deadline_unix bigint,
    created_unix bigint,
    updated_unix bigint,
    closed_unix bigint,
    is_locked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.issue OWNER TO mtuci;

--
-- Name: issue_assignees; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_assignees (
    id bigint NOT NULL,
    assignee_id bigint,
    issue_id bigint
);


ALTER TABLE public.issue_assignees OWNER TO mtuci;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_assignees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_assignees_id_seq OWNER TO mtuci;

--
-- Name: issue_assignees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_assignees_id_seq OWNED BY public.issue_assignees.id;


--
-- Name: issue_content_history; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_content_history (
    id bigint NOT NULL,
    poster_id bigint,
    issue_id bigint,
    comment_id bigint,
    edited_unix bigint,
    content_text text,
    is_first_created boolean,
    is_deleted boolean
);


ALTER TABLE public.issue_content_history OWNER TO mtuci;

--
-- Name: issue_content_history_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_content_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_content_history_id_seq OWNER TO mtuci;

--
-- Name: issue_content_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_content_history_id_seq OWNED BY public.issue_content_history.id;


--
-- Name: issue_dependency; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_dependency (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    issue_id bigint NOT NULL,
    dependency_id bigint NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.issue_dependency OWNER TO mtuci;

--
-- Name: issue_dependency_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_dependency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_dependency_id_seq OWNER TO mtuci;

--
-- Name: issue_dependency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_dependency_id_seq OWNED BY public.issue_dependency.id;


--
-- Name: issue_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_id_seq OWNER TO mtuci;

--
-- Name: issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_id_seq OWNED BY public.issue.id;


--
-- Name: issue_index; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_index (
    group_id bigint NOT NULL,
    max_index bigint
);


ALTER TABLE public.issue_index OWNER TO mtuci;

--
-- Name: issue_label; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_label (
    id bigint NOT NULL,
    issue_id bigint,
    label_id bigint
);


ALTER TABLE public.issue_label OWNER TO mtuci;

--
-- Name: issue_label_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_label_id_seq OWNER TO mtuci;

--
-- Name: issue_label_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_label_id_seq OWNED BY public.issue_label.id;


--
-- Name: issue_user; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_user (
    id bigint NOT NULL,
    uid bigint,
    issue_id bigint,
    is_read boolean,
    is_mentioned boolean
);


ALTER TABLE public.issue_user OWNER TO mtuci;

--
-- Name: issue_user_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_user_id_seq OWNER TO mtuci;

--
-- Name: issue_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_user_id_seq OWNED BY public.issue_user.id;


--
-- Name: issue_watch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.issue_watch (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    issue_id bigint NOT NULL,
    is_watching boolean NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.issue_watch OWNER TO mtuci;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.issue_watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_watch_id_seq OWNER TO mtuci;

--
-- Name: issue_watch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.issue_watch_id_seq OWNED BY public.issue_watch.id;


--
-- Name: label; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.label (
    id bigint NOT NULL,
    repo_id bigint,
    org_id bigint,
    name character varying(255),
    exclusive boolean,
    description character varying(255),
    color character varying(7),
    num_issues integer,
    num_closed_issues integer,
    created_unix bigint,
    updated_unix bigint,
    archived_unix bigint
);


ALTER TABLE public.label OWNER TO mtuci;

--
-- Name: label_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.label_id_seq OWNER TO mtuci;

--
-- Name: label_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.label_id_seq OWNED BY public.label.id;


--
-- Name: language_stat; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.language_stat (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    commit_id character varying(255),
    is_primary boolean,
    language character varying(50) NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    created_unix bigint
);


ALTER TABLE public.language_stat OWNER TO mtuci;

--
-- Name: language_stat_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.language_stat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.language_stat_id_seq OWNER TO mtuci;

--
-- Name: language_stat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.language_stat_id_seq OWNED BY public.language_stat.id;


--
-- Name: lfs_lock; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.lfs_lock (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    owner_id bigint NOT NULL,
    path text,
    created timestamp without time zone
);


ALTER TABLE public.lfs_lock OWNER TO mtuci;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.lfs_lock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lfs_lock_id_seq OWNER TO mtuci;

--
-- Name: lfs_lock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.lfs_lock_id_seq OWNED BY public.lfs_lock.id;


--
-- Name: lfs_meta_object; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.lfs_meta_object (
    id bigint NOT NULL,
    oid character varying(255) NOT NULL,
    size bigint NOT NULL,
    repository_id bigint NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.lfs_meta_object OWNER TO mtuci;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.lfs_meta_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lfs_meta_object_id_seq OWNER TO mtuci;

--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.lfs_meta_object_id_seq OWNED BY public.lfs_meta_object.id;


--
-- Name: login_source; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.login_source (
    id bigint NOT NULL,
    type integer,
    name character varying(255),
    is_active boolean DEFAULT false NOT NULL,
    is_sync_enabled boolean DEFAULT false NOT NULL,
    cfg text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.login_source OWNER TO mtuci;

--
-- Name: login_source_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.login_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_source_id_seq OWNER TO mtuci;

--
-- Name: login_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.login_source_id_seq OWNED BY public.login_source.id;


--
-- Name: milestone; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.milestone (
    id bigint NOT NULL,
    repo_id bigint,
    name character varying(255),
    content text,
    is_closed boolean,
    num_issues integer,
    num_closed_issues integer,
    completeness integer,
    created_unix bigint,
    updated_unix bigint,
    deadline_unix bigint,
    closed_date_unix bigint
);


ALTER TABLE public.milestone OWNER TO mtuci;

--
-- Name: milestone_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.milestone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.milestone_id_seq OWNER TO mtuci;

--
-- Name: milestone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.milestone_id_seq OWNED BY public.milestone.id;


--
-- Name: mirror; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.mirror (
    id bigint NOT NULL,
    repo_id bigint,
    "interval" bigint,
    enable_prune boolean DEFAULT true NOT NULL,
    updated_unix bigint,
    next_update_unix bigint,
    lfs_enabled boolean DEFAULT false NOT NULL,
    lfs_endpoint text,
    remote_address character varying(2048)
);


ALTER TABLE public.mirror OWNER TO mtuci;

--
-- Name: mirror_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.mirror_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mirror_id_seq OWNER TO mtuci;

--
-- Name: mirror_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.mirror_id_seq OWNED BY public.mirror.id;


--
-- Name: notice; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.notice (
    id bigint NOT NULL,
    type integer,
    description text,
    created_unix bigint
);


ALTER TABLE public.notice OWNER TO mtuci;

--
-- Name: notice_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.notice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notice_id_seq OWNER TO mtuci;

--
-- Name: notice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.notice_id_seq OWNED BY public.notice.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.notification (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    repo_id bigint NOT NULL,
    status smallint NOT NULL,
    source smallint NOT NULL,
    issue_id bigint NOT NULL,
    commit_id character varying(255),
    comment_id bigint,
    updated_by bigint NOT NULL,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.notification OWNER TO mtuci;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_id_seq OWNER TO mtuci;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(20) NOT NULL,
    read boolean DEFAULT false NOT NULL,
    dedupe_key character varying(255) NOT NULL,
    href character varying(500),
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO mtuci;

--
-- Name: oauth2_application; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.oauth2_application (
    id bigint NOT NULL,
    uid bigint,
    name character varying(255),
    client_id character varying(255),
    client_secret character varying(255),
    confidential_client boolean DEFAULT true NOT NULL,
    redirect_uris text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.oauth2_application OWNER TO mtuci;

--
-- Name: oauth2_application_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.oauth2_application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth2_application_id_seq OWNER TO mtuci;

--
-- Name: oauth2_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.oauth2_application_id_seq OWNED BY public.oauth2_application.id;


--
-- Name: oauth2_authorization_code; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.oauth2_authorization_code (
    id bigint NOT NULL,
    grant_id bigint,
    code character varying(255),
    code_challenge character varying(255),
    code_challenge_method character varying(255),
    redirect_uri character varying(255),
    valid_until bigint
);


ALTER TABLE public.oauth2_authorization_code OWNER TO mtuci;

--
-- Name: oauth2_authorization_code_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.oauth2_authorization_code_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth2_authorization_code_id_seq OWNER TO mtuci;

--
-- Name: oauth2_authorization_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.oauth2_authorization_code_id_seq OWNED BY public.oauth2_authorization_code.id;


--
-- Name: oauth2_grant; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.oauth2_grant (
    id bigint NOT NULL,
    user_id bigint,
    application_id bigint,
    counter bigint DEFAULT 1 NOT NULL,
    scope text,
    nonce text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.oauth2_grant OWNER TO mtuci;

--
-- Name: oauth2_grant_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.oauth2_grant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth2_grant_id_seq OWNER TO mtuci;

--
-- Name: oauth2_grant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.oauth2_grant_id_seq OWNED BY public.oauth2_grant.id;


--
-- Name: org_user; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.org_user (
    id bigint NOT NULL,
    uid bigint,
    org_id bigint,
    is_public boolean
);


ALTER TABLE public.org_user OWNER TO mtuci;

--
-- Name: org_user_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.org_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.org_user_id_seq OWNER TO mtuci;

--
-- Name: org_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.org_user_id_seq OWNED BY public.org_user.id;


--
-- Name: package; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    repo_id bigint,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    lower_name character varying(255) NOT NULL,
    semver_compatible boolean DEFAULT false NOT NULL,
    is_internal boolean DEFAULT false NOT NULL
);


ALTER TABLE public.package OWNER TO mtuci;

--
-- Name: package_blob; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_blob (
    id bigint NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    hash_md5 character(32) NOT NULL,
    hash_sha1 character(40) NOT NULL,
    hash_sha256 character(64) NOT NULL,
    hash_sha512 character(128) NOT NULL,
    created_unix bigint NOT NULL
);


ALTER TABLE public.package_blob OWNER TO mtuci;

--
-- Name: package_blob_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_blob_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_blob_id_seq OWNER TO mtuci;

--
-- Name: package_blob_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_blob_id_seq OWNED BY public.package_blob.id;


--
-- Name: package_blob_upload; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_blob_upload (
    id character varying(255) NOT NULL,
    bytes_received bigint DEFAULT 0 NOT NULL,
    hash_state_bytes bytea,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.package_blob_upload OWNER TO mtuci;

--
-- Name: package_cleanup_rule; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_cleanup_rule (
    id bigint NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    owner_id bigint DEFAULT 0 NOT NULL,
    type character varying(255) NOT NULL,
    keep_count integer DEFAULT 0 NOT NULL,
    keep_pattern character varying(255) DEFAULT ''::character varying NOT NULL,
    remove_days integer DEFAULT 0 NOT NULL,
    remove_pattern character varying(255) DEFAULT ''::character varying NOT NULL,
    match_full_name boolean DEFAULT false NOT NULL,
    created_unix bigint DEFAULT 0 NOT NULL,
    updated_unix bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.package_cleanup_rule OWNER TO mtuci;

--
-- Name: package_cleanup_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_cleanup_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_cleanup_rule_id_seq OWNER TO mtuci;

--
-- Name: package_cleanup_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_cleanup_rule_id_seq OWNED BY public.package_cleanup_rule.id;


--
-- Name: package_file; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_file (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    lower_name character varying(255) NOT NULL,
    composite_key character varying(255),
    is_lead boolean DEFAULT false NOT NULL,
    created_unix bigint NOT NULL
);


ALTER TABLE public.package_file OWNER TO mtuci;

--
-- Name: package_file_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_file_id_seq OWNER TO mtuci;

--
-- Name: package_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_file_id_seq OWNED BY public.package_file.id;


--
-- Name: package_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_id_seq OWNER TO mtuci;

--
-- Name: package_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_id_seq OWNED BY public.package.id;


--
-- Name: package_property; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_property (
    id bigint NOT NULL,
    ref_type bigint NOT NULL,
    ref_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.package_property OWNER TO mtuci;

--
-- Name: package_property_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_property_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_property_id_seq OWNER TO mtuci;

--
-- Name: package_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_property_id_seq OWNED BY public.package_property.id;


--
-- Name: package_version; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.package_version (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    creator_id bigint DEFAULT 0 NOT NULL,
    version character varying(255) NOT NULL,
    lower_version character varying(255) NOT NULL,
    created_unix bigint NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    metadata_json text,
    download_count bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.package_version OWNER TO mtuci;

--
-- Name: package_version_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.package_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.package_version_id_seq OWNER TO mtuci;

--
-- Name: package_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.package_version_id_seq OWNED BY public.package_version.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.password_reset_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(128) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO mtuci;

--
-- Name: permission_audit; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.permission_audit (
    id uuid NOT NULL,
    actor_id uuid,
    actor_role character varying(50) NOT NULL,
    target_role character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    permission_id character varying(100),
    details text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.permission_audit OWNER TO mtuci;

--
-- Name: project; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    owner_id bigint,
    repo_id bigint,
    creator_id bigint NOT NULL,
    is_closed boolean,
    board_type bigint,
    card_type bigint,
    type bigint,
    created_unix bigint,
    updated_unix bigint,
    closed_date_unix bigint
);


ALTER TABLE public.project OWNER TO mtuci;

--
-- Name: project_board; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.project_board (
    id bigint NOT NULL,
    title character varying(255),
    "default" boolean DEFAULT false NOT NULL,
    sorting integer DEFAULT 0 NOT NULL,
    color character varying(7),
    project_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.project_board OWNER TO mtuci;

--
-- Name: project_board_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.project_board_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_board_id_seq OWNER TO mtuci;

--
-- Name: project_board_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.project_board_id_seq OWNED BY public.project_board.id;


--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_id_seq OWNER TO mtuci;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: project_issue; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.project_issue (
    id bigint NOT NULL,
    issue_id bigint,
    project_id bigint,
    project_board_id bigint,
    sorting bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_issue OWNER TO mtuci;

--
-- Name: project_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.project_issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_issue_id_seq OWNER TO mtuci;

--
-- Name: project_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.project_issue_id_seq OWNED BY public.project_issue.id;


--
-- Name: protected_branch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.protected_branch (
    id bigint NOT NULL,
    repo_id bigint,
    branch_name character varying(255),
    can_push boolean DEFAULT false NOT NULL,
    enable_whitelist boolean,
    whitelist_user_i_ds text,
    whitelist_team_i_ds text,
    enable_merge_whitelist boolean DEFAULT false NOT NULL,
    whitelist_deploy_keys boolean DEFAULT false NOT NULL,
    merge_whitelist_user_i_ds text,
    merge_whitelist_team_i_ds text,
    enable_status_check boolean DEFAULT false NOT NULL,
    status_check_contexts text,
    enable_approvals_whitelist boolean DEFAULT false NOT NULL,
    approvals_whitelist_user_i_ds text,
    approvals_whitelist_team_i_ds text,
    required_approvals bigint DEFAULT 0 NOT NULL,
    block_on_rejected_reviews boolean DEFAULT false NOT NULL,
    block_on_official_review_requests boolean DEFAULT false NOT NULL,
    block_on_outdated_branch boolean DEFAULT false NOT NULL,
    dismiss_stale_approvals boolean DEFAULT false NOT NULL,
    ignore_stale_approvals boolean DEFAULT false NOT NULL,
    require_signed_commits boolean DEFAULT false NOT NULL,
    protected_file_patterns text,
    unprotected_file_patterns text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.protected_branch OWNER TO mtuci;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.protected_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.protected_branch_id_seq OWNER TO mtuci;

--
-- Name: protected_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.protected_branch_id_seq OWNED BY public.protected_branch.id;


--
-- Name: protected_tag; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.protected_tag (
    id bigint NOT NULL,
    repo_id bigint,
    name_pattern character varying(255),
    allowlist_user_i_ds text,
    allowlist_team_i_ds text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.protected_tag OWNER TO mtuci;

--
-- Name: protected_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.protected_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.protected_tag_id_seq OWNER TO mtuci;

--
-- Name: protected_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.protected_tag_id_seq OWNED BY public.protected_tag.id;


--
-- Name: public_key; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.public_key (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    content text NOT NULL,
    mode integer DEFAULT 2 NOT NULL,
    type integer DEFAULT 1 NOT NULL,
    login_source_id bigint DEFAULT 0 NOT NULL,
    created_unix bigint,
    updated_unix bigint,
    verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.public_key OWNER TO mtuci;

--
-- Name: public_key_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.public_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.public_key_id_seq OWNER TO mtuci;

--
-- Name: public_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.public_key_id_seq OWNED BY public.public_key.id;


--
-- Name: pull_auto_merge; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.pull_auto_merge (
    id bigint NOT NULL,
    pull_id bigint,
    doer_id bigint NOT NULL,
    merge_style character varying(30),
    message text,
    created_unix bigint
);


ALTER TABLE public.pull_auto_merge OWNER TO mtuci;

--
-- Name: pull_auto_merge_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.pull_auto_merge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pull_auto_merge_id_seq OWNER TO mtuci;

--
-- Name: pull_auto_merge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.pull_auto_merge_id_seq OWNED BY public.pull_auto_merge.id;


--
-- Name: pull_request; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.pull_request (
    id bigint NOT NULL,
    type integer,
    status integer,
    conflicted_files json,
    commits_ahead integer,
    commits_behind integer,
    changed_protected_files json,
    issue_id bigint,
    index bigint,
    head_repo_id bigint,
    base_repo_id bigint,
    head_branch character varying(255),
    base_branch character varying(255),
    merge_base character varying(64),
    allow_maintainer_edit boolean DEFAULT false NOT NULL,
    has_merged boolean,
    merged_commit_id character varying(64),
    merger_id bigint,
    merged_unix bigint,
    flow integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.pull_request OWNER TO mtuci;

--
-- Name: pull_request_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.pull_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pull_request_id_seq OWNER TO mtuci;

--
-- Name: pull_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.pull_request_id_seq OWNED BY public.pull_request.id;


--
-- Name: push_mirror; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.push_mirror (
    id bigint NOT NULL,
    repo_id bigint,
    remote_name character varying(255),
    remote_address character varying(2048),
    sync_on_commit boolean DEFAULT true NOT NULL,
    "interval" bigint,
    created_unix bigint,
    last_update bigint,
    last_error text
);


ALTER TABLE public.push_mirror OWNER TO mtuci;

--
-- Name: push_mirror_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.push_mirror_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.push_mirror_id_seq OWNER TO mtuci;

--
-- Name: push_mirror_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.push_mirror_id_seq OWNED BY public.push_mirror.id;


--
-- Name: reaction; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.reaction (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    issue_id bigint NOT NULL,
    comment_id bigint,
    user_id bigint NOT NULL,
    original_author_id bigint DEFAULT 0 NOT NULL,
    original_author character varying(255),
    created_unix bigint
);


ALTER TABLE public.reaction OWNER TO mtuci;

--
-- Name: reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.reaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reaction_id_seq OWNER TO mtuci;

--
-- Name: reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.reaction_id_seq OWNED BY public.reaction.id;


--
-- Name: release; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.release (
    id bigint NOT NULL,
    repo_id bigint,
    publisher_id bigint,
    tag_name character varying(255),
    original_author character varying(255),
    original_author_id bigint,
    lower_tag_name character varying(255),
    target character varying(255),
    title character varying(255),
    sha1 character varying(64),
    num_commits bigint,
    note text,
    is_draft boolean DEFAULT false NOT NULL,
    is_prerelease boolean DEFAULT false NOT NULL,
    is_tag boolean DEFAULT false NOT NULL,
    created_unix bigint
);


ALTER TABLE public.release OWNER TO mtuci;

--
-- Name: release_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.release_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.release_id_seq OWNER TO mtuci;

--
-- Name: release_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.release_id_seq OWNED BY public.release.id;


--
-- Name: renamed_branch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.renamed_branch (
    id bigint NOT NULL,
    repo_id bigint NOT NULL,
    "from" character varying(255),
    "to" character varying(255),
    created_unix bigint
);


ALTER TABLE public.renamed_branch OWNER TO mtuci;

--
-- Name: renamed_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.renamed_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.renamed_branch_id_seq OWNER TO mtuci;

--
-- Name: renamed_branch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.renamed_branch_id_seq OWNED BY public.renamed_branch.id;


--
-- Name: repo_archiver; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_archiver (
    id bigint NOT NULL,
    repo_id bigint,
    type integer,
    status integer,
    commit_id character varying(64),
    created_unix bigint NOT NULL
);


ALTER TABLE public.repo_archiver OWNER TO mtuci;

--
-- Name: repo_archiver_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repo_archiver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repo_archiver_id_seq OWNER TO mtuci;

--
-- Name: repo_archiver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repo_archiver_id_seq OWNED BY public.repo_archiver.id;


--
-- Name: repo_indexer_status; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_indexer_status (
    id bigint NOT NULL,
    repo_id bigint,
    commit_sha character varying(64),
    indexer_type integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.repo_indexer_status OWNER TO mtuci;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repo_indexer_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repo_indexer_status_id_seq OWNER TO mtuci;

--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repo_indexer_status_id_seq OWNED BY public.repo_indexer_status.id;


--
-- Name: repo_redirect; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_redirect (
    id bigint NOT NULL,
    owner_id bigint,
    lower_name character varying(255) NOT NULL,
    redirect_repo_id bigint
);


ALTER TABLE public.repo_redirect OWNER TO mtuci;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repo_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repo_redirect_id_seq OWNER TO mtuci;

--
-- Name: repo_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repo_redirect_id_seq OWNED BY public.repo_redirect.id;


--
-- Name: repo_topic; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_topic (
    repo_id bigint NOT NULL,
    topic_id bigint NOT NULL
);


ALTER TABLE public.repo_topic OWNER TO mtuci;

--
-- Name: repo_transfer; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_transfer (
    id bigint NOT NULL,
    doer_id bigint,
    recipient_id bigint,
    repo_id bigint,
    team_i_ds text,
    created_unix bigint NOT NULL,
    updated_unix bigint NOT NULL
);


ALTER TABLE public.repo_transfer OWNER TO mtuci;

--
-- Name: repo_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repo_transfer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repo_transfer_id_seq OWNER TO mtuci;

--
-- Name: repo_transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repo_transfer_id_seq OWNED BY public.repo_transfer.id;


--
-- Name: repo_unit; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repo_unit (
    id bigint NOT NULL,
    repo_id bigint,
    type integer,
    config text,
    created_unix bigint,
    everyone_access_mode integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.repo_unit OWNER TO mtuci;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repo_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repo_unit_id_seq OWNER TO mtuci;

--
-- Name: repo_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repo_unit_id_seq OWNED BY public.repo_unit.id;


--
-- Name: repositories; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repositories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    github_url character varying(500),
    owner_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    gitea_repo_name character varying(255),
    clone_url character varying(500),
    repo_type public.repository_type NOT NULL,
    language character varying(50),
    is_blocked boolean NOT NULL,
    gitea_repo_id integer
);


ALTER TABLE public.repositories OWNER TO mtuci;

--
-- Name: repository; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.repository (
    id bigint NOT NULL,
    owner_id bigint,
    owner_name character varying(255),
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    website character varying(2048),
    original_service_type integer,
    original_url character varying(2048),
    default_branch character varying(255),
    default_wiki_branch character varying(255),
    num_watches integer,
    num_stars integer,
    num_forks integer,
    num_issues integer,
    num_closed_issues integer,
    num_pulls integer,
    num_closed_pulls integer,
    num_milestones integer DEFAULT 0 NOT NULL,
    num_closed_milestones integer DEFAULT 0 NOT NULL,
    num_projects integer DEFAULT 0 NOT NULL,
    num_closed_projects integer DEFAULT 0 NOT NULL,
    num_action_runs integer DEFAULT 0 NOT NULL,
    num_closed_action_runs integer DEFAULT 0 NOT NULL,
    is_private boolean,
    is_empty boolean,
    is_archived boolean,
    is_mirror boolean,
    status integer DEFAULT 0 NOT NULL,
    is_fork boolean DEFAULT false NOT NULL,
    fork_id bigint,
    is_template boolean DEFAULT false NOT NULL,
    template_id bigint,
    size bigint DEFAULT 0 NOT NULL,
    git_size bigint DEFAULT 0 NOT NULL,
    lfs_size bigint DEFAULT 0 NOT NULL,
    is_fsck_enabled boolean DEFAULT true NOT NULL,
    close_issues_via_commit_in_any_branch boolean DEFAULT false NOT NULL,
    topics json,
    object_format_name character varying(6) DEFAULT 'sha1'::character varying NOT NULL,
    trust_model integer,
    avatar character varying(64),
    created_unix bigint,
    updated_unix bigint,
    archived_unix bigint DEFAULT 0
);


ALTER TABLE public.repository OWNER TO mtuci;

--
-- Name: repository_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.repository_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repository_id_seq OWNER TO mtuci;

--
-- Name: repository_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.repository_id_seq OWNED BY public.repository.id;


--
-- Name: review; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.review (
    id bigint NOT NULL,
    type integer,
    reviewer_id bigint,
    reviewer_team_id bigint DEFAULT 0 NOT NULL,
    original_author character varying(255),
    original_author_id bigint,
    issue_id bigint,
    content text,
    official boolean DEFAULT false NOT NULL,
    commit_id character varying(64),
    stale boolean DEFAULT false NOT NULL,
    dismissed boolean DEFAULT false NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.review OWNER TO mtuci;

--
-- Name: review_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_id_seq OWNER TO mtuci;

--
-- Name: review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.review_id_seq OWNED BY public.review.id;


--
-- Name: review_state; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.review_state (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    pull_id bigint DEFAULT 0 NOT NULL,
    commit_sha character varying(64) NOT NULL,
    updated_files json NOT NULL,
    updated_unix bigint
);


ALTER TABLE public.review_state OWNER TO mtuci;

--
-- Name: review_state_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.review_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_state_id_seq OWNER TO mtuci;

--
-- Name: review_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.review_state_id_seq OWNED BY public.review_state.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.role_permissions (
    id uuid NOT NULL,
    role character varying(50) NOT NULL,
    permission_id character varying(100) NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO mtuci;

--
-- Name: secret; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.secret (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    repo_id bigint DEFAULT 0 NOT NULL,
    name character varying(255) NOT NULL,
    data text,
    created_unix bigint NOT NULL
);


ALTER TABLE public.secret OWNER TO mtuci;

--
-- Name: secret_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.secret_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.secret_id_seq OWNER TO mtuci;

--
-- Name: secret_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.secret_id_seq OWNED BY public.secret.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.session (
    key character(16) NOT NULL,
    data bytea,
    expiry bigint
);


ALTER TABLE public.session OWNER TO mtuci;

--
-- Name: star; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.star (
    id bigint NOT NULL,
    uid bigint,
    repo_id bigint,
    created_unix bigint
);


ALTER TABLE public.star OWNER TO mtuci;

--
-- Name: star_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.star_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.star_id_seq OWNER TO mtuci;

--
-- Name: star_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.star_id_seq OWNED BY public.star.id;


--
-- Name: stopwatch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.stopwatch (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint
);


ALTER TABLE public.stopwatch OWNER TO mtuci;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.stopwatch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stopwatch_id_seq OWNER TO mtuci;

--
-- Name: stopwatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.stopwatch_id_seq OWNED BY public.stopwatch.id;


--
-- Name: student_repositories; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.student_repositories (
    id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    student_id uuid NOT NULL,
    repo_name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.student_repositories OWNER TO mtuci;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.submissions (
    id uuid NOT NULL,
    assignment_id uuid NOT NULL,
    student_id uuid NOT NULL,
    grade integer,
    comment text,
    submitted_at timestamp with time zone,
    graded_at timestamp with time zone,
    final_grade double precision,
    penalty_points double precision DEFAULT '0'::double precision NOT NULL,
    weeks_late integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_submissions_ck_submissions_grade_0_100 CHECK (((grade IS NULL) OR ((grade >= 0) AND (grade <= 100))))
);


ALTER TABLE public.submissions OWNER TO mtuci;

--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.system_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    level character varying(10) NOT NULL,
    source character varying(20) NOT NULL,
    user_id uuid,
    user_email character varying(255),
    user_full_name character varying(255),
    message text NOT NULL,
    detail text,
    ip_address character varying(45) NOT NULL,
    http_status integer,
    request_id character varying(255)
);


ALTER TABLE public.system_logs OWNER TO mtuci;

--
-- Name: system_setting; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.system_setting (
    id bigint NOT NULL,
    setting_key character varying(255),
    setting_value text,
    version integer,
    created bigint,
    updated bigint
);


ALTER TABLE public.system_setting OWNER TO mtuci;

--
-- Name: system_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.system_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_setting_id_seq OWNER TO mtuci;

--
-- Name: system_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.system_setting_id_seq OWNED BY public.system_setting.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.task (
    id bigint NOT NULL,
    doer_id bigint,
    owner_id bigint,
    repo_id bigint,
    type integer,
    status integer,
    start_time bigint,
    end_time bigint,
    payload_content text,
    message text,
    created bigint
);


ALTER TABLE public.task OWNER TO mtuci;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_id_seq OWNER TO mtuci;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.task.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.team (
    id bigint NOT NULL,
    org_id bigint,
    lower_name character varying(255),
    name character varying(255),
    description character varying(255),
    authorize integer,
    num_repos integer,
    num_members integer,
    includes_all_repositories boolean DEFAULT false NOT NULL,
    can_create_org_repo boolean DEFAULT false NOT NULL
);


ALTER TABLE public.team OWNER TO mtuci;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_id_seq OWNER TO mtuci;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: team_invite; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.team_invite (
    id bigint NOT NULL,
    token character varying(255) DEFAULT ''::character varying NOT NULL,
    inviter_id bigint DEFAULT 0 NOT NULL,
    org_id bigint DEFAULT 0 NOT NULL,
    team_id bigint DEFAULT 0 NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.team_invite OWNER TO mtuci;

--
-- Name: team_invite_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.team_invite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_invite_id_seq OWNER TO mtuci;

--
-- Name: team_invite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.team_invite_id_seq OWNED BY public.team_invite.id;


--
-- Name: team_repo; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.team_repo (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    repo_id bigint
);


ALTER TABLE public.team_repo OWNER TO mtuci;

--
-- Name: team_repo_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.team_repo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_repo_id_seq OWNER TO mtuci;

--
-- Name: team_repo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.team_repo_id_seq OWNED BY public.team_repo.id;


--
-- Name: team_unit; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.team_unit (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    type integer,
    access_mode integer
);


ALTER TABLE public.team_unit OWNER TO mtuci;

--
-- Name: team_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.team_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_unit_id_seq OWNER TO mtuci;

--
-- Name: team_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.team_unit_id_seq OWNED BY public.team_unit.id;


--
-- Name: team_user; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.team_user (
    id bigint NOT NULL,
    org_id bigint,
    team_id bigint,
    uid bigint
);


ALTER TABLE public.team_user OWNER TO mtuci;

--
-- Name: team_user_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.team_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_user_id_seq OWNER TO mtuci;

--
-- Name: team_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.team_user_id_seq OWNED BY public.team_user.id;


--
-- Name: topic; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.topic (
    id bigint NOT NULL,
    name character varying(50),
    repo_count integer,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.topic OWNER TO mtuci;

--
-- Name: topic_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.topic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.topic_id_seq OWNER TO mtuci;

--
-- Name: topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.topic_id_seq OWNED BY public.topic.id;


--
-- Name: tracked_time; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.tracked_time (
    id bigint NOT NULL,
    issue_id bigint,
    user_id bigint,
    created_unix bigint,
    "time" bigint NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tracked_time OWNER TO mtuci;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.tracked_time_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tracked_time_id_seq OWNER TO mtuci;

--
-- Name: tracked_time_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.tracked_time_id_seq OWNED BY public.tracked_time.id;


--
-- Name: trusted_assistants; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.trusted_assistants (
    id uuid NOT NULL,
    teacher_id uuid NOT NULL,
    assistant_id uuid NOT NULL,
    can_grade boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.trusted_assistants OWNER TO mtuci;

--
-- Name: two_factor; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.two_factor (
    id bigint NOT NULL,
    uid bigint,
    secret character varying(255),
    scratch_salt character varying(255),
    scratch_hash character varying(255),
    last_used_passcode character varying(10),
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.two_factor OWNER TO mtuci;

--
-- Name: two_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.two_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.two_factor_id_seq OWNER TO mtuci;

--
-- Name: two_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.two_factor_id_seq OWNED BY public.two_factor.id;


--
-- Name: upload; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.upload (
    id bigint NOT NULL,
    uuid uuid,
    name character varying(255)
);


ALTER TABLE public.upload OWNER TO mtuci;

--
-- Name: upload_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_id_seq OWNER TO mtuci;

--
-- Name: upload_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.upload_id_seq OWNED BY public.upload.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    lower_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    full_name character varying(255),
    email character varying(255) NOT NULL,
    keep_email_private boolean,
    email_notifications_preference character varying(20) DEFAULT 'enabled'::character varying NOT NULL,
    passwd character varying(255) NOT NULL,
    passwd_hash_algo character varying(255) DEFAULT 'argon2'::character varying NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    login_type integer,
    login_source bigint DEFAULT 0 NOT NULL,
    login_name character varying(255),
    type integer,
    location character varying(255),
    website character varying(255),
    rands character varying(32),
    salt character varying(32),
    language character varying(5),
    description character varying(255),
    created_unix bigint,
    updated_unix bigint,
    last_login_unix bigint,
    last_repo_visibility boolean,
    max_repo_creation integer DEFAULT '-1'::integer NOT NULL,
    is_active boolean,
    is_admin boolean,
    is_restricted boolean DEFAULT false NOT NULL,
    allow_git_hook boolean,
    allow_import_local boolean,
    allow_create_organization boolean DEFAULT true,
    prohibit_login boolean DEFAULT false NOT NULL,
    avatar character varying(2048) NOT NULL,
    avatar_email character varying(255) NOT NULL,
    use_custom_avatar boolean,
    num_followers integer,
    num_following integer DEFAULT 0 NOT NULL,
    num_stars integer,
    num_repos integer,
    num_teams integer,
    num_members integer,
    visibility integer DEFAULT 0 NOT NULL,
    repo_admin_change_team_access boolean DEFAULT false NOT NULL,
    diff_view_style character varying(255) DEFAULT ''::character varying NOT NULL,
    theme character varying(255) DEFAULT ''::character varying NOT NULL,
    keep_activity_private boolean DEFAULT false NOT NULL
);


ALTER TABLE public."user" OWNER TO mtuci;

--
-- Name: user_badge; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.user_badge (
    id bigint NOT NULL,
    badge_id bigint,
    user_id bigint
);


ALTER TABLE public.user_badge OWNER TO mtuci;

--
-- Name: user_badge_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_badge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_badge_id_seq OWNER TO mtuci;

--
-- Name: user_badge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_badge_id_seq OWNED BY public.user_badge.id;


--
-- Name: user_blocking; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.user_blocking (
    id bigint NOT NULL,
    blocker_id bigint,
    blockee_id bigint,
    note character varying(255),
    created_unix bigint
);


ALTER TABLE public.user_blocking OWNER TO mtuci;

--
-- Name: user_blocking_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_blocking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_blocking_id_seq OWNER TO mtuci;

--
-- Name: user_blocking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_blocking_id_seq OWNED BY public.user_blocking.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO mtuci;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_open_id; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.user_open_id (
    id bigint NOT NULL,
    uid bigint NOT NULL,
    uri character varying(255) NOT NULL,
    show boolean DEFAULT false
);


ALTER TABLE public.user_open_id OWNER TO mtuci;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_open_id_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_open_id_id_seq OWNER TO mtuci;

--
-- Name: user_open_id_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_open_id_id_seq OWNED BY public.user_open_id.id;


--
-- Name: user_redirect; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.user_redirect (
    id bigint NOT NULL,
    lower_name character varying(255) NOT NULL,
    redirect_user_id bigint
);


ALTER TABLE public.user_redirect OWNER TO mtuci;

--
-- Name: user_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_redirect_id_seq OWNER TO mtuci;

--
-- Name: user_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_redirect_id_seq OWNED BY public.user_redirect.id;


--
-- Name: user_setting; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.user_setting (
    id bigint NOT NULL,
    user_id bigint,
    setting_key character varying(255),
    setting_value text
);


ALTER TABLE public.user_setting OWNER TO mtuci;

--
-- Name: user_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.user_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_setting_id_seq OWNER TO mtuci;

--
-- Name: user_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.user_setting_id_seq OWNED BY public.user_setting.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    role public.user_role DEFAULT 'student'::public.user_role NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    group_name character varying(50),
    student_id character varying(50),
    avatar_url character varying(500),
    avatar_display_mode public.avatar_display_mode DEFAULT 'cover'::public.avatar_display_mode NOT NULL,
    mtuci_login character varying(100),
    mtuci_password character varying(255),
    is_pending boolean DEFAULT true NOT NULL,
    last_login timestamp with time zone,
    allow_assistant_grading boolean DEFAULT false NOT NULL,
    preferences json
);


ALTER TABLE public.users OWNER TO mtuci;

--
-- Name: version; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.version (
    id bigint NOT NULL,
    version bigint
);


ALTER TABLE public.version OWNER TO mtuci;

--
-- Name: version_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.version_id_seq OWNER TO mtuci;

--
-- Name: version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.version_id_seq OWNED BY public.version.id;


--
-- Name: watch; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.watch (
    id bigint NOT NULL,
    user_id bigint,
    repo_id bigint,
    mode smallint DEFAULT 1 NOT NULL,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.watch OWNER TO mtuci;

--
-- Name: watch_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.watch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_id_seq OWNER TO mtuci;

--
-- Name: watch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.watch_id_seq OWNED BY public.watch.id;


--
-- Name: webauthn_credential; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.webauthn_credential (
    id bigint NOT NULL,
    name character varying(255),
    lower_name character varying(255),
    user_id bigint,
    credential_id bytea,
    public_key bytea,
    attestation_type character varying(255),
    aaguid bytea,
    sign_count bigint,
    clone_warning boolean,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.webauthn_credential OWNER TO mtuci;

--
-- Name: webauthn_credential_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.webauthn_credential_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webauthn_credential_id_seq OWNER TO mtuci;

--
-- Name: webauthn_credential_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.webauthn_credential_id_seq OWNED BY public.webauthn_credential.id;


--
-- Name: webhook; Type: TABLE; Schema: public; Owner: mtuci
--

CREATE TABLE public.webhook (
    id bigint NOT NULL,
    repo_id bigint,
    owner_id bigint,
    is_system_webhook boolean,
    url text,
    http_method character varying(255),
    content_type integer,
    secret text,
    events text,
    is_active boolean,
    type character varying(16),
    meta text,
    last_status integer,
    header_authorization_encrypted text,
    created_unix bigint,
    updated_unix bigint
);


ALTER TABLE public.webhook OWNER TO mtuci;

--
-- Name: webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: mtuci
--

CREATE SEQUENCE public.webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.webhook_id_seq OWNER TO mtuci;

--
-- Name: webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mtuci
--

ALTER SEQUENCE public.webhook_id_seq OWNED BY public.webhook.id;


--
-- Name: access id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.access ALTER COLUMN id SET DEFAULT nextval('public.access_id_seq'::regclass);


--
-- Name: access_token id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.access_token ALTER COLUMN id SET DEFAULT nextval('public.access_token_id_seq'::regclass);


--
-- Name: action id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action ALTER COLUMN id SET DEFAULT nextval('public.action_id_seq'::regclass);


--
-- Name: action_artifact id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_artifact ALTER COLUMN id SET DEFAULT nextval('public.action_artifact_id_seq'::regclass);


--
-- Name: action_run id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_run ALTER COLUMN id SET DEFAULT nextval('public.action_run_id_seq'::regclass);


--
-- Name: action_run_job id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_run_job ALTER COLUMN id SET DEFAULT nextval('public.action_run_job_id_seq'::regclass);


--
-- Name: action_runner id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_runner ALTER COLUMN id SET DEFAULT nextval('public.action_runner_id_seq'::regclass);


--
-- Name: action_runner_token id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_runner_token ALTER COLUMN id SET DEFAULT nextval('public.action_runner_token_id_seq'::regclass);


--
-- Name: action_schedule id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_schedule ALTER COLUMN id SET DEFAULT nextval('public.action_schedule_id_seq'::regclass);


--
-- Name: action_schedule_spec id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_schedule_spec ALTER COLUMN id SET DEFAULT nextval('public.action_schedule_spec_id_seq'::regclass);


--
-- Name: action_task id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task ALTER COLUMN id SET DEFAULT nextval('public.action_task_id_seq'::regclass);


--
-- Name: action_task_output id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task_output ALTER COLUMN id SET DEFAULT nextval('public.action_task_output_id_seq'::regclass);


--
-- Name: action_task_step id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task_step ALTER COLUMN id SET DEFAULT nextval('public.action_task_step_id_seq'::regclass);


--
-- Name: action_tasks_version id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_tasks_version ALTER COLUMN id SET DEFAULT nextval('public.action_tasks_version_id_seq'::regclass);


--
-- Name: action_variable id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_variable ALTER COLUMN id SET DEFAULT nextval('public.action_variable_id_seq'::regclass);


--
-- Name: attachment id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.attachment ALTER COLUMN id SET DEFAULT nextval('public.attachment_id_seq'::regclass);


--
-- Name: badge id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.badge ALTER COLUMN id SET DEFAULT nextval('public.badge_id_seq'::regclass);


--
-- Name: branch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.branch ALTER COLUMN id SET DEFAULT nextval('public.branch_id_seq'::regclass);


--
-- Name: collaboration id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.collaboration ALTER COLUMN id SET DEFAULT nextval('public.collaboration_id_seq'::regclass);


--
-- Name: comment id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.comment ALTER COLUMN id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: commit_status id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status ALTER COLUMN id SET DEFAULT nextval('public.commit_status_id_seq'::regclass);


--
-- Name: commit_status_index id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status_index ALTER COLUMN id SET DEFAULT nextval('public.commit_status_index_id_seq'::regclass);


--
-- Name: commit_status_summary id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status_summary ALTER COLUMN id SET DEFAULT nextval('public.commit_status_summary_id_seq'::regclass);


--
-- Name: dbfs_data id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.dbfs_data ALTER COLUMN id SET DEFAULT nextval('public.dbfs_data_id_seq'::regclass);


--
-- Name: dbfs_meta id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.dbfs_meta ALTER COLUMN id SET DEFAULT nextval('public.dbfs_meta_id_seq'::regclass);


--
-- Name: deploy_key id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.deploy_key ALTER COLUMN id SET DEFAULT nextval('public.deploy_key_id_seq'::regclass);


--
-- Name: email_address id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.email_address ALTER COLUMN id SET DEFAULT nextval('public.email_address_id_seq'::regclass);


--
-- Name: follow id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.follow ALTER COLUMN id SET DEFAULT nextval('public.follow_id_seq'::regclass);


--
-- Name: gpg_key id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.gpg_key ALTER COLUMN id SET DEFAULT nextval('public.gpg_key_id_seq'::regclass);


--
-- Name: hook_task id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.hook_task ALTER COLUMN id SET DEFAULT nextval('public.hook_task_id_seq'::regclass);


--
-- Name: issue id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue ALTER COLUMN id SET DEFAULT nextval('public.issue_id_seq'::regclass);


--
-- Name: issue_assignees id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_assignees ALTER COLUMN id SET DEFAULT nextval('public.issue_assignees_id_seq'::regclass);


--
-- Name: issue_content_history id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_content_history ALTER COLUMN id SET DEFAULT nextval('public.issue_content_history_id_seq'::regclass);


--
-- Name: issue_dependency id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_dependency ALTER COLUMN id SET DEFAULT nextval('public.issue_dependency_id_seq'::regclass);


--
-- Name: issue_label id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_label ALTER COLUMN id SET DEFAULT nextval('public.issue_label_id_seq'::regclass);


--
-- Name: issue_user id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_user ALTER COLUMN id SET DEFAULT nextval('public.issue_user_id_seq'::regclass);


--
-- Name: issue_watch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_watch ALTER COLUMN id SET DEFAULT nextval('public.issue_watch_id_seq'::regclass);


--
-- Name: label id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.label ALTER COLUMN id SET DEFAULT nextval('public.label_id_seq'::regclass);


--
-- Name: language_stat id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.language_stat ALTER COLUMN id SET DEFAULT nextval('public.language_stat_id_seq'::regclass);


--
-- Name: lfs_lock id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.lfs_lock ALTER COLUMN id SET DEFAULT nextval('public.lfs_lock_id_seq'::regclass);


--
-- Name: lfs_meta_object id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.lfs_meta_object ALTER COLUMN id SET DEFAULT nextval('public.lfs_meta_object_id_seq'::regclass);


--
-- Name: login_source id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.login_source ALTER COLUMN id SET DEFAULT nextval('public.login_source_id_seq'::regclass);


--
-- Name: milestone id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.milestone ALTER COLUMN id SET DEFAULT nextval('public.milestone_id_seq'::regclass);


--
-- Name: mirror id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.mirror ALTER COLUMN id SET DEFAULT nextval('public.mirror_id_seq'::regclass);


--
-- Name: notice id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notice ALTER COLUMN id SET DEFAULT nextval('public.notice_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: oauth2_application id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_application ALTER COLUMN id SET DEFAULT nextval('public.oauth2_application_id_seq'::regclass);


--
-- Name: oauth2_authorization_code id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_authorization_code ALTER COLUMN id SET DEFAULT nextval('public.oauth2_authorization_code_id_seq'::regclass);


--
-- Name: oauth2_grant id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_grant ALTER COLUMN id SET DEFAULT nextval('public.oauth2_grant_id_seq'::regclass);


--
-- Name: org_user id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.org_user ALTER COLUMN id SET DEFAULT nextval('public.org_user_id_seq'::regclass);


--
-- Name: package id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package ALTER COLUMN id SET DEFAULT nextval('public.package_id_seq'::regclass);


--
-- Name: package_blob id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_blob ALTER COLUMN id SET DEFAULT nextval('public.package_blob_id_seq'::regclass);


--
-- Name: package_cleanup_rule id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_cleanup_rule ALTER COLUMN id SET DEFAULT nextval('public.package_cleanup_rule_id_seq'::regclass);


--
-- Name: package_file id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_file ALTER COLUMN id SET DEFAULT nextval('public.package_file_id_seq'::regclass);


--
-- Name: package_property id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_property ALTER COLUMN id SET DEFAULT nextval('public.package_property_id_seq'::regclass);


--
-- Name: package_version id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_version ALTER COLUMN id SET DEFAULT nextval('public.package_version_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: project_board id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project_board ALTER COLUMN id SET DEFAULT nextval('public.project_board_id_seq'::regclass);


--
-- Name: project_issue id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project_issue ALTER COLUMN id SET DEFAULT nextval('public.project_issue_id_seq'::regclass);


--
-- Name: protected_branch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.protected_branch ALTER COLUMN id SET DEFAULT nextval('public.protected_branch_id_seq'::regclass);


--
-- Name: protected_tag id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.protected_tag ALTER COLUMN id SET DEFAULT nextval('public.protected_tag_id_seq'::regclass);


--
-- Name: public_key id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.public_key ALTER COLUMN id SET DEFAULT nextval('public.public_key_id_seq'::regclass);


--
-- Name: pull_auto_merge id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.pull_auto_merge ALTER COLUMN id SET DEFAULT nextval('public.pull_auto_merge_id_seq'::regclass);


--
-- Name: pull_request id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.pull_request ALTER COLUMN id SET DEFAULT nextval('public.pull_request_id_seq'::regclass);


--
-- Name: push_mirror id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.push_mirror ALTER COLUMN id SET DEFAULT nextval('public.push_mirror_id_seq'::regclass);


--
-- Name: reaction id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.reaction ALTER COLUMN id SET DEFAULT nextval('public.reaction_id_seq'::regclass);


--
-- Name: release id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.release ALTER COLUMN id SET DEFAULT nextval('public.release_id_seq'::regclass);


--
-- Name: renamed_branch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.renamed_branch ALTER COLUMN id SET DEFAULT nextval('public.renamed_branch_id_seq'::regclass);


--
-- Name: repo_archiver id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_archiver ALTER COLUMN id SET DEFAULT nextval('public.repo_archiver_id_seq'::regclass);


--
-- Name: repo_indexer_status id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_indexer_status ALTER COLUMN id SET DEFAULT nextval('public.repo_indexer_status_id_seq'::regclass);


--
-- Name: repo_redirect id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_redirect ALTER COLUMN id SET DEFAULT nextval('public.repo_redirect_id_seq'::regclass);


--
-- Name: repo_transfer id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_transfer ALTER COLUMN id SET DEFAULT nextval('public.repo_transfer_id_seq'::regclass);


--
-- Name: repo_unit id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_unit ALTER COLUMN id SET DEFAULT nextval('public.repo_unit_id_seq'::regclass);


--
-- Name: repository id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repository ALTER COLUMN id SET DEFAULT nextval('public.repository_id_seq'::regclass);


--
-- Name: review id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.review ALTER COLUMN id SET DEFAULT nextval('public.review_id_seq'::regclass);


--
-- Name: review_state id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.review_state ALTER COLUMN id SET DEFAULT nextval('public.review_state_id_seq'::regclass);


--
-- Name: secret id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.secret ALTER COLUMN id SET DEFAULT nextval('public.secret_id_seq'::regclass);


--
-- Name: star id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.star ALTER COLUMN id SET DEFAULT nextval('public.star_id_seq'::regclass);


--
-- Name: stopwatch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.stopwatch ALTER COLUMN id SET DEFAULT nextval('public.stopwatch_id_seq'::regclass);


--
-- Name: system_setting id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.system_setting ALTER COLUMN id SET DEFAULT nextval('public.system_setting_id_seq'::regclass);


--
-- Name: task id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.task ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: team_invite id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_invite ALTER COLUMN id SET DEFAULT nextval('public.team_invite_id_seq'::regclass);


--
-- Name: team_repo id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_repo ALTER COLUMN id SET DEFAULT nextval('public.team_repo_id_seq'::regclass);


--
-- Name: team_unit id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_unit ALTER COLUMN id SET DEFAULT nextval('public.team_unit_id_seq'::regclass);


--
-- Name: team_user id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_user ALTER COLUMN id SET DEFAULT nextval('public.team_user_id_seq'::regclass);


--
-- Name: topic id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.topic ALTER COLUMN id SET DEFAULT nextval('public.topic_id_seq'::regclass);


--
-- Name: tracked_time id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.tracked_time ALTER COLUMN id SET DEFAULT nextval('public.tracked_time_id_seq'::regclass);


--
-- Name: two_factor id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.two_factor ALTER COLUMN id SET DEFAULT nextval('public.two_factor_id_seq'::regclass);


--
-- Name: upload id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.upload ALTER COLUMN id SET DEFAULT nextval('public.upload_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_badge id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_badge ALTER COLUMN id SET DEFAULT nextval('public.user_badge_id_seq'::regclass);


--
-- Name: user_blocking id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_blocking ALTER COLUMN id SET DEFAULT nextval('public.user_blocking_id_seq'::regclass);


--
-- Name: user_open_id id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_open_id ALTER COLUMN id SET DEFAULT nextval('public.user_open_id_id_seq'::regclass);


--
-- Name: user_redirect id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_redirect ALTER COLUMN id SET DEFAULT nextval('public.user_redirect_id_seq'::regclass);


--
-- Name: user_setting id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_setting ALTER COLUMN id SET DEFAULT nextval('public.user_setting_id_seq'::regclass);


--
-- Name: version id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.version ALTER COLUMN id SET DEFAULT nextval('public.version_id_seq'::regclass);


--
-- Name: watch id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.watch ALTER COLUMN id SET DEFAULT nextval('public.watch_id_seq'::regclass);


--
-- Name: webauthn_credential id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.webauthn_credential ALTER COLUMN id SET DEFAULT nextval('public.webauthn_credential_id_seq'::regclass);


--
-- Name: webhook id; Type: DEFAULT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.webhook ALTER COLUMN id SET DEFAULT nextval('public.webhook_id_seq'::regclass);


--
-- Data for Name: access; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.access (id, user_id, repo_id, mode) FROM stdin;
\.


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.access_token (id, uid, name, token_hash, token_salt, token_last_eight, scope, created_unix, updated_unix) FROM stdin;
2	34	mtuci-clone-a07f048de6	e5dc8164be6f31362e0581cf6a9951976296dbf0cbba59f801e0250b2622bf7d8f8370d2596690cf27b103e117ea7f04484c	anqW6WCTHO	70c0b326	write:repository,read:user	1778949319	1778949319
\.


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action (id, user_id, op_type, act_user_id, repo_id, comment_id, is_deleted, ref_name, is_private, content, created_unix) FROM stdin;
10	1	1	1	12	0	f		t		1778936079
11	1	5	1	12	0	f	refs/heads/main	t		1778936080
12	1	5	1	12	0	f	refs/heads/main	t	{"Commits":[{"Sha1":"b4a8ed872da6fbf6c7c6601a1cc81cf75209a980","Message":"Initial commit: add README\\n","AuthorEmail":"admin@gitea.local","AuthorName":"gitea_admin","CommitterEmail":"admin@gitea.local","CommitterName":"gitea_admin","Timestamp":"2026-05-16T12:54:39Z"}],"HeadCommit":{"Sha1":"b4a8ed872da6fbf6c7c6601a1cc81cf75209a980","Message":"Initial commit: add README\\n","AuthorEmail":"admin@gitea.local","AuthorName":"gitea_admin","CommitterEmail":"admin@gitea.local","CommitterName":"gitea_admin","Timestamp":"2026-05-16T12:54:39Z"},"CompareURL":"","Len":1}	1778936080
13	1	5	1	12	0	f	refs/heads/main	t	{"Commits":[{"Sha1":"e58f4cee0ae40dd126afc34d7c94360e946db811","Message":"Add file via MTUCI\\n","AuthorEmail":"admin@gitea.local","AuthorName":"gitea_admin","CommitterEmail":"admin@gitea.local","CommitterName":"gitea_admin","Timestamp":"2026-05-16T13:03:19Z"}],"HeadCommit":{"Sha1":"e58f4cee0ae40dd126afc34d7c94360e946db811","Message":"Add file via MTUCI\\n","AuthorEmail":"admin@gitea.local","AuthorName":"gitea_admin","CommitterEmail":"admin@gitea.local","CommitterName":"gitea_admin","Timestamp":"2026-05-16T13:03:19Z"},"CompareURL":"yu.e.lashkov/face2voice/compare/b4a8ed872da6fbf6c7c6601a1cc81cf75209a980...e58f4cee0ae40dd126afc34d7c94360e946db811","Len":1}	1778936601
14	1	1	1	14	0	f		t		1779322424
15	1	1	1	15	0	f		t		1779396928
16	1	1	1	16	0	f		f		1779621259
17	1	1	1	21	0	f		f		1779626961
18	1	1	1	22	0	f		f		1779627543
\.


--
-- Data for Name: action_artifact; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_artifact (id, run_id, runner_id, repo_id, owner_id, commit_sha, storage_path, file_size, file_compressed_size, content_encoding, artifact_path, artifact_name, status, created_unix, updated_unix, expired_unix) FROM stdin;
\.


--
-- Data for Name: action_run; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_run (id, title, repo_id, owner_id, workflow_id, index, trigger_user_id, schedule_id, ref, commit_sha, is_fork_pull_request, need_approval, approved_by, event, event_payload, trigger_event, status, version, started, stopped, previous_duration, created, updated) FROM stdin;
\.


--
-- Data for Name: action_run_index; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_run_index (group_id, max_index) FROM stdin;
\.


--
-- Data for Name: action_run_job; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_run_job (id, run_id, repo_id, owner_id, commit_sha, is_fork_pull_request, name, attempt, workflow_payload, job_id, needs, runs_on, task_id, status, started, stopped, created, updated) FROM stdin;
\.


--
-- Data for Name: action_runner; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_runner (id, uuid, name, version, owner_id, repo_id, description, base, repo_range, token_hash, token_salt, last_online, last_active, agent_labels, created, updated, deleted) FROM stdin;
\.


--
-- Data for Name: action_runner_token; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_runner_token (id, token, owner_id, repo_id, is_active, created, updated, deleted) FROM stdin;
\.


--
-- Data for Name: action_schedule; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_schedule (id, title, specs, repo_id, owner_id, workflow_id, trigger_user_id, ref, commit_sha, event, event_payload, content, created, updated) FROM stdin;
\.


--
-- Data for Name: action_schedule_spec; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_schedule_spec (id, repo_id, schedule_id, next, prev, spec, created, updated) FROM stdin;
\.


--
-- Data for Name: action_task; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_task (id, job_id, attempt, runner_id, status, started, stopped, repo_id, owner_id, commit_sha, is_fork_pull_request, token_hash, token_salt, token_last_eight, log_filename, log_in_storage, log_length, log_size, log_indexes, log_expired, created, updated) FROM stdin;
\.


--
-- Data for Name: action_task_output; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_task_output (id, task_id, output_key, output_value) FROM stdin;
\.


--
-- Data for Name: action_task_step; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_task_step (id, name, task_id, index, repo_id, status, log_index, log_length, started, stopped, created, updated) FROM stdin;
\.


--
-- Data for Name: action_tasks_version; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_tasks_version (id, owner_id, repo_id, version, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: action_variable; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.action_variable (id, owner_id, repo_id, name, data, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.activity_log (id, user_id, activity_type, repo_name, message, ip_address, user_agent, created_at, user_login) FROM stdin;
e0d3c5f4-f202-4330-92c1-79693f206576	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-16 10:57:10.067569+00	\N
bcccf112-f0f0-4a4c-8e00-7370183dc640	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-16 11:08:54.791072+00	\N
785620bb-48bd-4483-b78c-b757b0a0fa81	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	face2voice	Repository created	\N	\N	2026-05-16 12:20:34.742364+00	\N
89b437d7-a830-4d9c-ac21-63f779accaa8	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_deleted	face2voice	Repository deleted	\N	\N	2026-05-16 12:42:11.660841+00	\N
a1b987b4-5aaa-4b59-9d07-163bcfd87d83	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	face2voice	Repository created	\N	\N	2026-05-16 12:42:20.298407+00	\N
b406a472-eba7-4fb2-92d5-5e433ab4bb24	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	123213	Repository created	\N	\N	2026-05-16 12:42:29.771291+00	\N
29277bcf-483a-41f2-8f36-b6f727abd31f	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	123123	Repository created	\N	\N	2026-05-16 12:50:13.762769+00	\N
75e32a68-da4a-4d76-a706-550072795327	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-16 12:50:51.878877+00	\N
7fe45182-b866-4776-a94c-f3d40a2152ce	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	1235442133241	Repository created	\N	\N	2026-05-16 12:51:11.803742+00	\N
e9b5f871-0b4d-4af0-916d-a2b9268884ca	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_deleted	1235442133241	Repository deleted	\N	\N	2026-05-16 12:54:21.390545+00	\N
724741c6-a18a-4dc4-a300-0dd7a8cc0205	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_deleted	123123	Repository deleted	\N	\N	2026-05-16 12:54:23.473452+00	\N
061f68bc-f0cd-4d86-81a6-a90894734e92	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_deleted	face2voice	Repository deleted	\N	\N	2026-05-16 12:54:25.460417+00	\N
5f51713a-25e7-40da-9116-895174106887	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_deleted	123213	Repository deleted	\N	\N	2026-05-16 12:54:27.241218+00	\N
ccfd7618-a2e6-4931-919c-d2ccbce6ed34	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	repo_created	face2voice	Repository created	\N	\N	2026-05-16 12:54:37.894046+00	\N
e94a8a5f-6e2c-4e0a-8ed5-39af657c6cfe	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-16 18:41:09.242643+00	\N
1604a480-53f5-43c8-a0c7-4731512ae480	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-16 18:41:36.873485+00	\N
77c66c89-d2e9-48d0-b291-fa58590b0523	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-16 22:01:31.044628+00	\N
6616a904-7b83-4ce4-9c84-eac35186a54f	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-20 23:58:27.886816+00	\N
aef35459-ea1a-4b55-b9e4-d062f991e279	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 00:07:46.98472+00	\N
8708ab50-94b0-41dd-b18d-22b699bade9b	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 16:54:05.274846+00	\N
165fe2db-7af7-4ad9-ba1c-ee9fa315038f	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 17:25:59.129189+00	\N
1b1db9d9-9e93-4609-ab59-973c971aeecc	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 17:31:51.548541+00	\N
b10b564b-dd08-40a6-8b96-1f3e1c4a717d	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 17:31:51.575974+00	\N
33854be2-6b17-4d3b-88b5-b10103315784	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 17:32:02.460403+00	\N
8d427cb1-82a4-4f56-92c9-a439d6a17c8f	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	login	\N	\N	172.18.0.6	\N	2026-05-21 18:13:17.236409+00	\N
47ec7155-2b54-4b1f-acbf-04aeb979cae8	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-21 20:15:50.360147+00	\N
bae8bd6b-476f-4244-bf67-0b9166cbb007	\N	login	\N	\N	172.18.0.6	\N	2026-05-21 17:30:50.562142+00	\N
70a4ca8f-e12e-4c94-b4ce-bd33de1534a3	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	login	\N	\N	172.18.0.6	\N	2026-05-21 20:32:02.608929+00	\N
716da657-3a67-47ce-adcc-247a3fad2999	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	login	\N	\N	172.18.0.6	\N	2026-05-24 09:39:21.423498+00	\N
246d3da1-c659-4c53-83de-fc509539d8d0	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	repo_created	lab1	Repository created	\N	\N	2026-05-24 11:14:19.337732+00	\N
afe49dcd-dff1-4d69-a47e-9a098dde1d37	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-24 11:26:43.637881+00	\N
0de4a5e2-3f58-4259-aa4a-a6e00b4e8aa7	596ca07f-ea2d-400b-9b99-f150fff23016	repo_created	my-lab-work	Repository created	\N	\N	2026-05-24 12:06:18.907159+00	\N
af063a55-209f-4cb4-9202-e6d15c482796	596ca07f-ea2d-400b-9b99-f150fff23016	repo_created	my-lab	Repository created	\N	\N	2026-05-24 12:09:11.884939+00	\N
c21d6127-de10-4765-9015-93697e9ecbef	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-24 12:27:53.827157+00	\N
1609732b-dc45-40b4-9281-b97d84620ff7	596ca07f-ea2d-400b-9b99-f150fff23016	repo_created	mylab	Repository created	\N	\N	2026-05-24 12:28:25.151535+00	\N
9e1572ac-ae8d-4d01-b4a1-d4cb36f72ce0	596ca07f-ea2d-400b-9b99-f150fff23016	repo_created	mylab1111	Repository created	\N	\N	2026-05-24 12:49:21.829398+00	\N
4c076894-dc38-43bc-be1e-4b57e9147041	596ca07f-ea2d-400b-9b99-f150fff23016	repo_created	golinter	Repository created	\N	\N	2026-05-24 12:59:04.005559+00	\N
7f34ede2-1e9d-4e51-a1d6-c55f01a06a55	596ca07f-ea2d-400b-9b99-f150fff23016	repo_deleted	my-lab	Repository deleted	\N	\N	2026-05-24 13:05:34.079984+00	\N
771388fe-d68e-4a52-b40f-187466418c7b	596ca07f-ea2d-400b-9b99-f150fff23016	repo_deleted	my-lab-work	Repository deleted	\N	\N	2026-05-24 13:05:38.3854+00	\N
1a68cc07-8787-4ae5-b90b-f73955bd2f25	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-24 13:23:23.608802+00	\N
0bea28e7-8416-4952-83ad-6f11cf1e033d	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-24 13:31:24.086549+00	\N
13e4da6b-a1fd-473f-89e5-6e4c75ac9587	596ca07f-ea2d-400b-9b99-f150fff23016	login	\N	\N	172.18.0.6	\N	2026-05-24 13:32:05.266435+00	\N
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.alembic_version (version_num) FROM stdin;
0028
\.


--
-- Data for Name: app_state; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.app_state (id, revision, content) FROM stdin;
runtime-state	0	{"last_app_path":"/usr/local/bin/gitea","last_custom_conf":"/data/gitea/conf/app.ini"}
\.


--
-- Data for Name: assignment_files; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.assignment_files (id, assignment_id, original_filename, storage_path, content_type, file_size, created_at) FROM stdin;
\.


--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.assignments (id, course_id, title, description, deadline, gitea_repo_name, created_at, start_date, late_penalty_periods) FROM stdin;
992c906f-c134-4a63-a702-a9cbd93a0181	323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5	1 лаба	1231231233	2026-05-24 18:42:00+00	\N	2026-05-16 18:42:41.329247+00	2026-05-16 18:42:00+00	[{"weeks": 1, "max_grade": 4}]
153d8c9f-9657-4b6e-8910-415741df819e	930bee0d-1c21-4057-8cba-10fa9bbe63be	21434321	23144213213	2026-05-25 20:55:00+00	\N	2026-05-21 20:55:26.750358+00	2026-05-21 20:55:00+00	[{"weeks": 1, "max_grade": 4}]
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.attachment (id, uuid, repo_id, issue_id, release_id, uploader_id, comment_id, name, download_count, size, created_unix) FROM stdin;
\.


--
-- Data for Name: auth_token; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.auth_token (id, token_hash, user_id, expires_unix) FROM stdin;
\.


--
-- Data for Name: badge; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.badge (id, slug, description, image_url) FROM stdin;
\.


--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.branch (id, repo_id, name, commit_id, commit_message, pusher_id, is_deleted, deleted_by_id, deleted_unix, commit_time, created_unix, updated_unix) FROM stdin;
4	12	main	e58f4cee0ae40dd126afc34d7c94360e946db811	Add file via MTUCI	1	f	0	0	1778936599	1778936080	1778936600
5	14	main	ac090402dec4609340fc7624fc49bc3fb4a221ec	Initial commit	1	f	0	0	1779322423	1779322424	1779322424
6	15	main	5659866a2c6c2495e515b423f0d3256be68ce2aa	Initial commit	1	f	0	0	1779396927	1779396927	1779396927
7	16	main	4401b6650cb9c7dcdafaf9525698ef65e9a7f9bc	Initial commit	1	f	0	0	1779621257	1779621258	1779621258
8	21	main	32edc9c2fb4b3f19f7aae0384d650669735c5be8	Initial commit	1	f	0	0	1779626961	1779626961	1779626961
9	22	main	f9540c977cc1423486f9d85bdc1292b1ae95c4ce	Initial commit	1	f	0	0	1779627543	1779627543	1779627543
\.


--
-- Data for Name: collaboration; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.collaboration (id, repo_id, user_id, mode, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.comment (id, type, poster_id, original_author, original_author_id, issue_id, label_id, old_project_id, project_id, old_milestone_id, milestone_id, time_id, assignee_id, removed_assignee, assignee_team_id, resolve_doer_id, old_title, new_title, old_ref, new_ref, dependent_issue_id, commit_id, line, tree_path, content, patch, created_unix, updated_unix, commit_sha, review_id, invalidated, ref_repo_id, ref_issue_id, ref_comment_id, ref_action, ref_is_pull) FROM stdin;
\.


--
-- Data for Name: commit_status; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.commit_status (id, index, repo_id, state, sha, target_url, description, context_hash, context, creator_id, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: commit_status_index; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.commit_status_index (id, repo_id, sha, max_index) FROM stdin;
\.


--
-- Data for Name: commit_status_summary; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.commit_status_summary (id, repo_id, sha, state, target_url) FROM stdin;
\.


--
-- Data for Name: course_enrollments; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.course_enrollments (id, course_id, student_id, enrolled_at) FROM stdin;
30cbd47c-e25c-4072-b9f7-266fc64e87c6	323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-21 00:13:43.543542+00
175a3ad3-9a40-4bbc-913b-a4fab3529ae3	930bee0d-1c21-4057-8cba-10fa9bbe63be	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-21 20:53:40.914928+00
27bcb642-d94a-4b06-9d0c-6a8cb08fe7e1	4d3aa91c-2c55-4378-8e3b-c9b114024344	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-21 21:08:00.282209+00
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.courses (id, title, description, teacher_id, created_at, grade_min, grade_max, target_groups) FROM stdin;
323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5	Кибернетика		a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-16 18:42:02.297062+00	0	10	{}
930bee0d-1c21-4057-8cba-10fa9bbe63be	киба		0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	2026-05-21 20:52:31.375491+00	0	15	{БВТ2403}
4d3aa91c-2c55-4378-8e3b-c9b114024344	алгосы	123132	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	2026-05-21 21:08:00.274871+00	0	10	{БВТ2403}
\.


--
-- Data for Name: dbfs_data; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.dbfs_data (id, revision, meta_id, blob_offset, blob_size, blob_data) FROM stdin;
\.


--
-- Data for Name: dbfs_meta; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.dbfs_meta (id, full_path, block_size, file_size, create_timestamp, modify_timestamp) FROM stdin;
\.


--
-- Data for Name: deploy_key; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.deploy_key (id, key_id, repo_id, name, fingerprint, mode, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: email_address; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.email_address (id, uid, email, lower_email, is_activated, is_primary) FROM stdin;
1	1	admin@gitea.local	admin@gitea.local	t	t
34	34	yu.e.lashkov@gitmtuci.lab	yu.e.lashkov@gitmtuci.lab	t	t
35	35	simonov@gitmtuci.lab	simonov@gitmtuci.lab	t	t
36	36	u596ca07fea2d@gitmtuci.lab	u596ca07fea2d@gitmtuci.lab	t	t
\.


--
-- Data for Name: email_hash; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.email_hash (hash, email) FROM stdin;
\.


--
-- Data for Name: external_login_user; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.external_login_user (external_id, user_id, login_source_id, raw_data, provider, email, name, first_name, last_name, nick_name, description, avatar_url, location, access_token, access_token_secret, refresh_token, expires_at) FROM stdin;
\.


--
-- Data for Name: follow; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.follow (id, user_id, follow_id, created_unix) FROM stdin;
\.


--
-- Data for Name: gpg_key; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.gpg_key (id, owner_id, key_id, primary_key_id, content, created_unix, expired_unix, added_unix, emails, verified, can_sign, can_encrypt_comms, can_encrypt_storage, can_certify) FROM stdin;
\.


--
-- Data for Name: gpg_key_import; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.gpg_key_import (key_id, content) FROM stdin;
\.


--
-- Data for Name: hook_task; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.hook_task (id, hook_id, uuid, payload_content, payload_version, event_type, is_delivered, delivered, is_succeed, request_content, response_content) FROM stdin;
\.


--
-- Data for Name: issue; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue (id, repo_id, index, poster_id, original_author, original_author_id, name, content, milestone_id, priority, is_closed, is_pull, num_comments, ref, pin_order, deadline_unix, created_unix, updated_unix, closed_unix, is_locked) FROM stdin;
\.


--
-- Data for Name: issue_assignees; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_assignees (id, assignee_id, issue_id) FROM stdin;
\.


--
-- Data for Name: issue_content_history; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_content_history (id, poster_id, issue_id, comment_id, edited_unix, content_text, is_first_created, is_deleted) FROM stdin;
\.


--
-- Data for Name: issue_dependency; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_dependency (id, user_id, issue_id, dependency_id, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: issue_index; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_index (group_id, max_index) FROM stdin;
\.


--
-- Data for Name: issue_label; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_label (id, issue_id, label_id) FROM stdin;
\.


--
-- Data for Name: issue_user; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_user (id, uid, issue_id, is_read, is_mentioned) FROM stdin;
\.


--
-- Data for Name: issue_watch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.issue_watch (id, user_id, issue_id, is_watching, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.label (id, repo_id, org_id, name, exclusive, description, color, num_issues, num_closed_issues, created_unix, updated_unix, archived_unix) FROM stdin;
\.


--
-- Data for Name: language_stat; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.language_stat (id, repo_id, commit_id, is_primary, language, size, created_unix) FROM stdin;
1	12	e58f4cee0ae40dd126afc34d7c94360e946db811	t	Python	21	1778936603
\.


--
-- Data for Name: lfs_lock; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.lfs_lock (id, repo_id, owner_id, path, created) FROM stdin;
\.


--
-- Data for Name: lfs_meta_object; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.lfs_meta_object (id, oid, size, repository_id, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: login_source; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.login_source (id, type, name, is_active, is_sync_enabled, cfg, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: milestone; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.milestone (id, repo_id, name, content, is_closed, num_issues, num_closed_issues, completeness, created_unix, updated_unix, deadline_unix, closed_date_unix) FROM stdin;
\.


--
-- Data for Name: mirror; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.mirror (id, repo_id, "interval", enable_prune, updated_unix, next_update_unix, lfs_enabled, lfs_endpoint, remote_address) FROM stdin;
\.


--
-- Data for Name: notice; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.notice (id, type, description, created_unix) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.notification (id, user_id, repo_id, status, source, issue_id, commit_id, comment_id, updated_by, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.notifications (id, user_id, title, message, type, read, dedupe_key, href, created_at) FROM stdin;
8a575280-3798-4ae5-b297-ba5c35832ce4	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	Новое задание	1 лаба · Кибернетика	info	t	assignment-new:992c906f-c134-4a63-a702-a9cbd93a0181	/courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181	2026-05-16 18:42:41.329247+00
7ce53679-496a-4e15-9fc4-8706e96d9c09	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	Приближается дедлайн	1 лаба · Кибернетика — через 3 дн.	warning	t	deadline:992c906f-c134-4a63-a702-a9cbd93a0181	/courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181	2026-05-21 00:07:47.385651+00
713d82c6-af47-4ba1-9c08-0a4afe1af5c5	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	Новое задание	21434321 · киба	info	f	assignment-new:153d8c9f-9657-4b6e-8910-415741df819e	/courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/assignments/153d8c9f-9657-4b6e-8910-415741df819e	2026-05-21 20:55:26.750358+00
50c737ec-9310-4b57-ab7b-028f3a22178f	596ca07f-ea2d-400b-9b99-f150fff23016	Ожидают одобрения	2 пользователь(ей) ждут подтверждения	warning	t	admin:pending-users	/users	2026-05-21 20:15:50.531814+00
\.


--
-- Data for Name: oauth2_application; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.oauth2_application (id, uid, name, client_id, client_secret, confidential_client, redirect_uris, created_unix, updated_unix) FROM stdin;
1	0	git-credential-oauth	a4792ccc-144e-407e-86c9-5e7d8d9c3269		f	["http://127.0.0.1","https://127.0.0.1"]	1778928973	1778928973
2	0	Git Credential Manager	e90ee53c-94e2-48ac-9358-a874fb9e0662		f	["http://127.0.0.1","https://127.0.0.1"]	1778928973	1778928973
3	0	tea	d57cb8c4-630c-4168-8324-ec79935e18d4		f	["http://127.0.0.1","https://127.0.0.1"]	1778928973	1778928973
\.


--
-- Data for Name: oauth2_authorization_code; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.oauth2_authorization_code (id, grant_id, code, code_challenge, code_challenge_method, redirect_uri, valid_until) FROM stdin;
\.


--
-- Data for Name: oauth2_grant; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.oauth2_grant (id, user_id, application_id, counter, scope, nonce, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: org_user; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.org_user (id, uid, org_id, is_public) FROM stdin;
\.


--
-- Data for Name: package; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package (id, owner_id, repo_id, type, name, lower_name, semver_compatible, is_internal) FROM stdin;
\.


--
-- Data for Name: package_blob; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_blob (id, size, hash_md5, hash_sha1, hash_sha256, hash_sha512, created_unix) FROM stdin;
\.


--
-- Data for Name: package_blob_upload; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_blob_upload (id, bytes_received, hash_state_bytes, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: package_cleanup_rule; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_cleanup_rule (id, enabled, owner_id, type, keep_count, keep_pattern, remove_days, remove_pattern, match_full_name, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: package_file; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_file (id, version_id, blob_id, name, lower_name, composite_key, is_lead, created_unix) FROM stdin;
\.


--
-- Data for Name: package_property; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_property (id, ref_type, ref_id, name, value) FROM stdin;
\.


--
-- Data for Name: package_version; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.package_version (id, package_id, creator_id, version, lower_version, created_unix, is_internal, metadata_json, download_count) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: permission_audit; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.permission_audit (id, actor_id, actor_role, target_role, action, permission_id, details, created_at) FROM stdin;
651d1673-75ab-4e26-8bb5-96c04cbd3c8e	596ca07f-ea2d-400b-9b99-f150fff23016	admin	student	reset	\N	\N	2026-05-24 14:27:31.14604+00
61316e0c-e78b-450e-8639-6c2ede3991ae	596ca07f-ea2d-400b-9b99-f150fff23016	admin	student	save_batch	\N	{"permissions": [{"id": "repo_view", "enabled": true}, {"id": "repo_create", "enabled": false}, {"id": "user_view", "enabled": true}, {"id": "assignment_view", "enabled": true}, {"id": "settings_view", "enabled": true}]}	2026-05-24 14:27:34.149373+00
b0204f59-574d-41f8-9ca7-c7a2ab093f68	596ca07f-ea2d-400b-9b99-f150fff23016	admin	admin	reset	\N	\N	2026-05-24 15:29:02.649092+00
cc534bf9-ba47-491e-9503-b376130086f7	596ca07f-ea2d-400b-9b99-f150fff23016	admin	admin	reset	\N	\N	2026-05-24 15:30:33.984691+00
1b5d5387-d3f7-4b8e-aa45-eda2df7083c7	596ca07f-ea2d-400b-9b99-f150fff23016	admin	admin	reset	\N	\N	2026-05-24 15:30:34.967097+00
ddf60737-9361-42e5-882e-7aff16c2575d	596ca07f-ea2d-400b-9b99-f150fff23016	admin	admin	save_batch	\N	{"permissions": [{"id": "repo_view", "enabled": true}, {"id": "repo_view_students", "enabled": true}, {"id": "repo_create", "enabled": true}, {"id": "repo_delete", "enabled": false}, {"id": "repo_comment", "enabled": true}, {"id": "user_view", "enabled": true}, {"id": "user_edit", "enabled": true}, {"id": "group_manage", "enabled": true}, {"id": "assignment_view", "enabled": true}, {"id": "assignment_create", "enabled": true}, {"id": "grade_edit", "enabled": true}, {"id": "lab_accept", "enabled": true}, {"id": "grade_view_groups", "enabled": true}, {"id": "settings_view", "enabled": true}, {"id": "settings_edit", "enabled": true}, {"id": "logs_view", "enabled": true}]}	2026-05-24 15:30:36.454729+00
f0758007-812c-4f77-b70d-2f61c5d101f8	596ca07f-ea2d-400b-9b99-f150fff23016	admin	admin	reset	\N	\N	2026-05-24 15:30:37.15685+00
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.project (id, title, description, owner_id, repo_id, creator_id, is_closed, board_type, card_type, type, created_unix, updated_unix, closed_date_unix) FROM stdin;
\.


--
-- Data for Name: project_board; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.project_board (id, title, "default", sorting, color, project_id, creator_id, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: project_issue; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.project_issue (id, issue_id, project_id, project_board_id, sorting) FROM stdin;
\.


--
-- Data for Name: protected_branch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.protected_branch (id, repo_id, branch_name, can_push, enable_whitelist, whitelist_user_i_ds, whitelist_team_i_ds, enable_merge_whitelist, whitelist_deploy_keys, merge_whitelist_user_i_ds, merge_whitelist_team_i_ds, enable_status_check, status_check_contexts, enable_approvals_whitelist, approvals_whitelist_user_i_ds, approvals_whitelist_team_i_ds, required_approvals, block_on_rejected_reviews, block_on_official_review_requests, block_on_outdated_branch, dismiss_stale_approvals, ignore_stale_approvals, require_signed_commits, protected_file_patterns, unprotected_file_patterns, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: protected_tag; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.protected_tag (id, repo_id, name_pattern, allowlist_user_i_ds, allowlist_team_i_ds, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: public_key; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.public_key (id, owner_id, name, fingerprint, content, mode, type, login_source_id, created_unix, updated_unix, verified) FROM stdin;
\.


--
-- Data for Name: pull_auto_merge; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.pull_auto_merge (id, pull_id, doer_id, merge_style, message, created_unix) FROM stdin;
\.


--
-- Data for Name: pull_request; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.pull_request (id, type, status, conflicted_files, commits_ahead, commits_behind, changed_protected_files, issue_id, index, head_repo_id, base_repo_id, head_branch, base_branch, merge_base, allow_maintainer_edit, has_merged, merged_commit_id, merger_id, merged_unix, flow) FROM stdin;
\.


--
-- Data for Name: push_mirror; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.push_mirror (id, repo_id, remote_name, remote_address, sync_on_commit, "interval", created_unix, last_update, last_error) FROM stdin;
\.


--
-- Data for Name: reaction; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.reaction (id, type, issue_id, comment_id, user_id, original_author_id, original_author, created_unix) FROM stdin;
\.


--
-- Data for Name: release; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.release (id, repo_id, publisher_id, tag_name, original_author, original_author_id, lower_tag_name, target, title, sha1, num_commits, note, is_draft, is_prerelease, is_tag, created_unix) FROM stdin;
\.


--
-- Data for Name: renamed_branch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.renamed_branch (id, repo_id, "from", "to", created_unix) FROM stdin;
\.


--
-- Data for Name: repo_archiver; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_archiver (id, repo_id, type, status, commit_id, created_unix) FROM stdin;
\.


--
-- Data for Name: repo_indexer_status; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_indexer_status (id, repo_id, commit_sha, indexer_type) FROM stdin;
4	12	e58f4cee0ae40dd126afc34d7c94360e946db811	1
5	14	ac090402dec4609340fc7624fc49bc3fb4a221ec	1
6	15	5659866a2c6c2495e515b423f0d3256be68ce2aa	1
7	16	4401b6650cb9c7dcdafaf9525698ef65e9a7f9bc	1
8	22	f9540c977cc1423486f9d85bdc1292b1ae95c4ce	1
9	21	32edc9c2fb4b3f19f7aae0384d650669735c5be8	1
\.


--
-- Data for Name: repo_redirect; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_redirect (id, owner_id, lower_name, redirect_repo_id) FROM stdin;
\.


--
-- Data for Name: repo_topic; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_topic (repo_id, topic_id) FROM stdin;
\.


--
-- Data for Name: repo_transfer; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_transfer (id, doer_id, recipient_id, repo_id, team_i_ds, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: repo_unit; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repo_unit (id, repo_id, type, config, created_unix, everyone_access_mode) FROM stdin;
73	14	1	\N	1779322423	0
74	14	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1779322423	0
75	14	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1779322423	0
76	14	4	\N	1779322423	0
77	14	5	\N	1779322423	0
78	14	8	{"ProjectsMode":"all"}	1779322423	0
79	14	9	\N	1779322423	0
80	14	10	\N	1779322423	0
81	15	1	\N	1779396926	0
82	15	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1779396926	0
83	15	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1779396926	0
84	15	4	\N	1779396926	0
85	15	5	\N	1779396926	0
86	15	8	{"ProjectsMode":"all"}	1779396926	0
87	15	9	\N	1779396926	0
88	15	10	\N	1779396926	0
89	16	1	\N	1779621257	0
90	16	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1779621257	0
91	16	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1779621257	0
92	16	4	\N	1779621257	0
93	16	5	\N	1779621257	0
94	16	8	{"ProjectsMode":"all"}	1779621257	0
95	16	9	\N	1779621257	0
96	16	10	\N	1779621257	0
129	21	1	\N	1779626960	0
130	21	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1779626960	0
131	21	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1779626960	0
132	21	4	\N	1779626960	0
133	21	5	\N	1779626960	0
134	21	8	{"ProjectsMode":"all"}	1779626960	0
135	21	9	\N	1779626960	0
65	12	1	\N	1778936079	0
66	12	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1778936079	0
67	12	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1778936079	0
68	12	4	\N	1778936079	0
69	12	5	\N	1778936079	0
70	12	8	{"ProjectsMode":"all"}	1778936079	0
71	12	9	\N	1778936079	0
72	12	10	\N	1778936079	0
136	21	10	\N	1779626960	0
137	22	1	\N	1779627543	0
138	22	2	{"EnableTimetracker":true,"AllowOnlyContributorsToTrackTime":true,"EnableDependencies":true}	1779627543	0
139	22	3	{"IgnoreWhitespaceConflicts":false,"AllowMerge":true,"AllowRebase":true,"AllowRebaseMerge":true,"AllowSquash":true,"AllowFastForwardOnly":true,"AllowManualMerge":false,"AutodetectManualMerge":false,"AllowRebaseUpdate":true,"DefaultDeleteBranchAfterMerge":false,"DefaultMergeStyle":"merge","DefaultAllowMaintainerEdit":false}	1779627543	0
140	22	4	\N	1779627543	0
141	22	5	\N	1779627543	0
142	22	8	{"ProjectsMode":"all"}	1779627543	0
143	22	9	\N	1779627543	0
144	22	10	\N	1779627543	0
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repositories (id, name, description, github_url, owner_id, created_at, updated_at, gitea_repo_name, clone_url, repo_type, language, is_blocked, gitea_repo_id) FROM stdin;
efefd638-7f13-42c6-a75e-bafbcc312b07	face2voice	Ilm	\N	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-16 12:54:37.856686+00	2026-05-16 22:23:51.572715+00	face2voice	http://localhost:3000/yu.e.lashkov/face2voice.git	private	\N	f	\N
5e9b0ae8-41d7-400a-b2ef-bda939783992	lab1	lab	\N	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	2026-05-24 11:14:19.277171+00	2026-05-24 12:07:09.900637+00	lab1	http://localhost:3000/simonov/lab1.git	public	\N	f	\N
147f7f1b-831a-468e-87db-92755416cfcd	mylab	123123	\N	596ca07f-ea2d-400b-9b99-f150fff23016	2026-05-24 12:28:25.117397+00	2026-05-24 12:28:25.1174+00	\N	\N	public	\N	f	\N
165c39cf-7af3-46a0-81fd-3fb7b0e2a711	mylab1111	lab	\N	596ca07f-ea2d-400b-9b99-f150fff23016	2026-05-24 12:49:21.795915+00	2026-05-24 12:49:21.795943+00	mylab1111	http://localhost:3000/u596ca07fea2d/mylab1111.git	public	\N	f	\N
e5470133-d66b-43f3-a13b-372114232ba5	golinter	\N	\N	596ca07f-ea2d-400b-9b99-f150fff23016	2026-05-24 12:59:03.973735+00	2026-05-24 12:59:03.97374+00	golinter	http://localhost:3000/u596ca07fea2d/golinter.git	public	\N	f	\N
\.


--
-- Data for Name: repository; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.repository (id, owner_id, owner_name, lower_name, name, description, website, original_service_type, original_url, default_branch, default_wiki_branch, num_watches, num_stars, num_forks, num_issues, num_closed_issues, num_pulls, num_closed_pulls, num_milestones, num_closed_milestones, num_projects, num_closed_projects, num_action_runs, num_closed_action_runs, is_private, is_empty, is_archived, is_mirror, status, is_fork, fork_id, is_template, template_id, size, git_size, lfs_size, is_fsck_enabled, close_issues_via_commit_in_any_branch, topics, object_format_name, trust_model, avatar, created_unix, updated_unix, archived_unix) FROM stdin;
14	34	yu.e.lashkov	assignment_992c906f-c134-4a63-a702-a9cbd93a0181_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	assignment_992c906f-c134-4a63-a702-a9cbd93a0181_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	Assignment repository		0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	t	f	f	f	0	f	0	f	0	23800	23800	0	t	f	null	sha1	0		1779322423	1779322424	0
15	34	yu.e.lashkov	assignment_153d8c9f-9657-4b6e-8910-415741df819e_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	assignment_153d8c9f-9657-4b6e-8910-415741df819e_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	Assignment repository		0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	t	f	f	f	0	f	0	f	0	23800	23800	0	t	f	null	sha1	0		1779396926	1779396927	0
12	34	yu.e.lashkov	face2voice	face2voice	Ilm		0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	t	f	f	f	0	f	0	f	0	24485	24485	0	t	f	null	sha1	0		1778936079	1778936601	0
16	35	simonov	lab1	lab1	lab		0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	f	0	f	0	f	0	25297	25297	0	t	f	null	sha1	0		1779621256	1779621258	0
21	36	u596ca07fea2d	mylab1111	mylab1111	lab		0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	f	0	f	0	f	0	25983	25983	0	t	f	null	sha1	0		1779626960	1779626961	0
22	36	u596ca07fea2d	golinter	golinter			0		main	main	1	0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	f	0	f	0	f	0	24759	24759	0	t	f	null	sha1	0		1779627543	1779627543	0
\.


--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.review (id, type, reviewer_id, reviewer_team_id, original_author, original_author_id, issue_id, content, official, commit_id, stale, dismissed, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: review_state; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.review_state (id, user_id, pull_id, commit_sha, updated_files, updated_unix) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.role_permissions (id, role, permission_id, enabled, created_at, updated_at) FROM stdin;
b23d531a-ed0a-4437-b575-71112f1abd2e	student	repo_view	t	2026-05-24 14:27:34.15159+00	2026-05-24 14:27:34.151592+00
c9a19d24-a5f1-4ea3-8130-95565c0745a7	student	repo_create	f	2026-05-24 14:27:34.151597+00	2026-05-24 14:27:34.151598+00
8d1665dd-b4ca-4578-b0d8-040dc1fc0f5c	student	user_view	t	2026-05-24 14:27:34.151601+00	2026-05-24 14:27:34.151602+00
602b6efc-ca1b-4120-bbee-806ab3dfe3f7	student	assignment_view	t	2026-05-24 14:27:34.151605+00	2026-05-24 14:27:34.151606+00
f289d7d4-a0ee-4142-a915-4a0815a37c15	student	settings_view	t	2026-05-24 14:27:34.151609+00	2026-05-24 14:27:34.15161+00
\.


--
-- Data for Name: secret; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.secret (id, owner_id, repo_id, name, data, created_unix) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.session (key, data, expiry) FROM stdin;
\.


--
-- Data for Name: star; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.star (id, uid, repo_id, created_unix) FROM stdin;
\.


--
-- Data for Name: stopwatch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.stopwatch (id, issue_id, user_id, created_unix) FROM stdin;
\.


--
-- Data for Name: student_repositories; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.student_repositories (id, assignment_id, student_id, repo_name, created_at) FROM stdin;
20a9854f-0e86-4333-9592-af5db6341429	992c906f-c134-4a63-a702-a9cbd93a0181	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	assignment_992c906f-c134-4a63-a702-a9cbd93a0181_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-21 00:13:44.737532+00
2afdee7a-0128-4a5c-92b0-b11eb19df31c	153d8c9f-9657-4b6e-8910-415741df819e	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	assignment_153d8c9f-9657-4b6e-8910-415741df819e_student_a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	2026-05-21 20:55:28.293223+00
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.submissions (id, assignment_id, student_id, grade, comment, submitted_at, graded_at, final_grade, penalty_points, weeks_late) FROM stdin;
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.system_logs (id, created_at, level, source, user_id, user_email, user_full_name, message, detail, ip_address, http_status, request_id) FROM stdin;
7bb467d1-ecb2-453b-b11c-ebeefde3ee67	2026-05-16 10:56:58.770455+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (9ms)	\N	172.18.0.6	401	\N
c5a4c893-aad5-49e3-93db-ee1fb7aeb5aa	2026-05-16 10:56:58.732751+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
1603a0f3-3685-448d-a9bf-3b4967d8f962	2026-05-16 10:56:58.733913+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
eafae6a9-50d2-4c5e-b26e-8ebce9eacbb7	2026-05-16 10:56:58.88327+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (79ms)	\N	172.18.0.6	401	\N
9b0c4d50-cad2-4935-9bb5-88fdafe60dcb	2026-05-16 10:56:58.883648+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (77ms)	\N	172.18.0.6	401	\N
af26a9ed-7004-4111-a172-966e9beac89b	2026-05-16 10:56:58.916424+00	WARNING	admin	\N	\N	\N	GET /notifications - 401 (5ms)	\N	172.18.0.6	401	\N
e08413ab-6da9-4355-8012-c9d64721c855	2026-05-16 10:56:58.915196+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (5ms)	\N	172.18.0.6	401	\N
9471c042-d697-4d00-980b-47df456c8325	2026-05-16 10:56:58.933152+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (4ms)	\N	172.18.0.6	401	\N
2b82a7b9-df55-4bdb-8848-4672dd5631a9	2026-05-16 10:56:58.954174+00	WARNING	admin	\N	\N	\N	GET /notifications - 401 (13ms)	\N	172.18.0.6	401	\N
86dac8ba-6718-4837-b178-71b5161f43df	2026-05-16 10:56:59.002595+00	WARNING	admin	\N	\N	\N	GET /students/me/activity-feed - 401 (8ms)	\N	172.18.0.6	401	\N
43f98f0e-0e06-4515-ac9c-ce0890fa94e1	2026-05-16 10:56:59.003121+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/recent - 401 (10ms)	\N	172.18.0.6	401	\N
f3f5b6b3-7bdd-4f31-9483-ac678ee4380c	2026-05-16 10:56:59.003303+00	WARNING	admin	\N	\N	\N	GET /students/me/dashboard-stats - 401 (59ms)	\N	172.18.0.6	401	\N
426a78e6-f8ee-4138-833e-ed4186a745fd	2026-05-16 10:56:59.042079+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (92ms)	\N	172.18.0.6	401	\N
6a75c46e-bee6-48e1-b801-e660c80ed4ef	2026-05-16 10:56:59.042566+00	WARNING	admin	\N	\N	\N	GET /students/me/activity-summary - 401 (51ms)	\N	172.18.0.6	401	\N
38049a9b-0605-4466-bfc2-65501e26a140	2026-05-16 10:56:59.06163+00	WARNING	admin	\N	\N	\N	GET /students/me/activity-feed - 401 (17ms)	\N	172.18.0.6	401	\N
9cd55fdc-bfc9-41a4-951e-912d9803130c	2026-05-16 10:56:59.124644+00	WARNING	admin	\N	\N	\N	GET /students/me/group-ranking - 401 (124ms)	\N	172.18.0.6	401	\N
f0fc53af-5ddb-465b-8cbe-49cdc504800b	2026-05-16 10:56:59.133536+00	WARNING	admin	\N	\N	\N	GET /students/me/activity-summary - 401 (13ms)	\N	172.18.0.6	401	\N
c107d676-de91-4abb-a8a6-542c39313b0c	2026-05-16 10:56:59.141911+00	WARNING	admin	\N	\N	\N	GET /students/me/group-ranking - 401 (5ms)	\N	172.18.0.6	401	\N
658c0741-5907-464c-98ef-7dd75f66bb95	2026-05-16 10:56:59.15057+00	WARNING	admin	\N	\N	\N	GET /students/me/dashboard-stats - 401 (102ms)	\N	172.18.0.6	401	\N
3b431a35-22bc-44d1-98d7-2dd022b338e3	2026-05-16 10:56:59.15176+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/recent - 401 (99ms)	\N	172.18.0.6	401	\N
389790b7-f7a2-4ee3-82b0-a576ecb0bc03	2026-05-16 10:57:08.737622+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (242ms)	\N	172.18.0.6	401	\N
5956aecc-ad96-466b-9a2c-a02919df4d37	2026-05-16 10:57:08.736536+00	WARNING	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Failed login attempt for user: admin@mtuci.ru	\N	172.18.0.6	\N	\N
e8e35711-c797-4650-95c2-6d5f1d39a9b3	2026-05-16 10:57:10.067923+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
56c550e0-2b16-4a12-9ef4-51eb4c60b916	2026-05-16 10:57:10.121114+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (367ms)	\N	172.18.0.6	200	\N
92135235-0e83-442c-b2e6-cca845fb10c9	2026-05-16 10:57:10.160454+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
61118b10-897e-47aa-8d8b-c34ada85f5bc	2026-05-16 10:57:10.160012+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
22cbdb9b-774c-4a5b-a717-022c48ab77f3	2026-05-16 10:57:17.022529+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
636aa56e-b848-4016-bdae-a71a4c6431e3	2026-05-16 10:57:17.028117+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
587013f7-9176-4aab-ab96-0c25ad603239	2026-05-16 10:57:17.034808+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (1ms)	\N	172.18.0.1	405	\N
a9fcf48c-0506-4870-8b14-60809c868922	2026-05-16 10:57:17.042084+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (1ms)	\N	172.18.0.1	405	\N
cb95b4dc-07ba-40cc-9f94-1d9f289e285c	2026-05-16 10:57:19.275593+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
b32aba4e-99b0-4c30-9c6a-3b6c391354d0	2026-05-16 10:57:19.276067+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
65a7923b-e6ae-45a8-8699-37a108a7c6b2	2026-05-16 10:57:19.283887+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (1ms)	\N	172.18.0.1	405	\N
c9c58b0d-7e22-4055-b7c4-bc24a83fe7d1	2026-05-16 10:57:19.28453+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (1ms)	\N	172.18.0.1	405	\N
2130f234-5470-486e-aed0-2e86a45b8f77	2026-05-16 10:57:32.526131+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
19df822e-874f-4e59-be12-6faabbd4d371	2026-05-16 10:57:32.526591+00	INFO	admin	\N	\N	\N	GET /repositories - 307 (1ms)	\N	172.18.0.1	307	\N
42e76cdb-2a1f-4a31-8293-a67172e38907	2026-05-16 10:57:32.53537+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (1ms)	\N	172.18.0.1	405	\N
d19a797e-f717-4f43-8ce7-87f936624ead	2026-05-16 10:57:32.538351+00	WARNING	admin	\N	\N	\N	GET /repositories/ - 405 (3ms)	\N	172.18.0.1	405	\N
d772a2b1-572b-41c4-8ff1-652fa257238a	2026-05-16 11:02:14.556316+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c3dc3a84-67c2-4cfd-8cb0-2119ef2fffb0	2026-05-16 11:02:14.556962+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
715e01b1-1ac6-42fa-ac75-adc7426a4b46	2026-05-16 11:08:48.587959+00	INFO	admin	\N	\N	\N	POST /auth/register-student-mtuci - 201 (2497ms)	\N	172.18.0.6	201	\N
a28c7b26-b5ce-4f71-8192-5c44831bbe0a	2026-05-16 11:08:54.791456+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
dce794c0-d857-4482-b4dd-d6e9097d3a1d	2026-05-16 11:08:54.843792+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (297ms)	\N	172.18.0.6	200	\N
3b957c55-7631-428b-b61a-dd791e9f5999	2026-05-16 11:08:54.915582+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
58593f55-1a06-4673-a06c-23678411379a	2026-05-16 11:08:54.919208+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
4c187491-1aa9-4ab0-86d7-f26428ed7858	2026-05-16 11:10:25.388833+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9461ca16-38cf-41c6-89dc-afadf4302988	2026-05-16 11:10:25.388532+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
8e8932b3-d73a-4215-a738-935843734979	2026-05-16 11:11:21.96608+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
58ce82d7-8d64-4d11-b452-baf0b7e31603	2026-05-16 11:11:21.966477+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b9ec715e-0725-426f-b703-290df319a098	2026-05-16 11:12:09.035151+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 404 (1ms)	\N	172.18.0.6	404	\N
3bd7e944-71cf-458e-827e-105edf81e1a3	2026-05-16 11:12:09.042581+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 404 (1ms)	\N	172.18.0.6	404	\N
5972b45e-083f-4c85-a665-e8b4c4497520	2026-05-16 11:12:41.055095+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
d91cfb90-0924-41fa-8343-bca866aab2ff	2026-05-16 11:12:41.056148+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
83042fe2-41ea-4733-aee4-f2761145ea14	2026-05-16 11:12:41.056543+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 404 (2ms)	\N	172.18.0.6	404	\N
30869b41-fa9e-49a8-b64b-60425c9dbda6	2026-05-16 11:12:41.05718+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 404 (2ms)	\N	172.18.0.6	404	\N
1697d69b-35fa-4670-9b57-368d392566d2	2026-05-16 11:14:05.879706+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
ece2511a-d0e4-4ede-8493-e8afd4b16da7	2026-05-16 11:14:05.882214+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
8dd4a283-353f-4dd9-b892-d9942497ab5a	2026-05-16 11:14:37.243844+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f6a2657f-a2af-4800-b5b2-905f0a7823b3	2026-05-16 11:14:37.243357+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1eb034f6-4d7e-4762-9e33-e58518279370	2026-05-16 11:24:17.098385+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f50e68d6-cb6b-448d-a2be-27711f77c79a	2026-05-16 11:24:17.393701+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
534a2dc2-c27f-455a-b123-8881cb0e3ae4	2026-05-16 11:24:39.750412+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
238c360e-17c2-4b88-a9e6-e7a445e54650	2026-05-16 11:24:39.749261+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1919ffdc-c486-4369-8662-6cacce26157f	2026-05-16 11:30:02.17939+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (12ms)	\N	172.18.0.6	404	\N
25fa6edb-c158-4891-b69a-f1ecbfd7a46c	2026-05-24 14:27:31.206977+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Reset permissions to defaults for role: student	\N	172.18.0.6	200	\N
476bd850-f7f7-446b-8878-159887d63898	2026-05-24 14:27:34.175765+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/student - 200 (32ms)	\N	172.18.0.6	200	\N
50c5859c-500a-4e35-adf4-c9ca23826a9d	2026-05-24 16:18:54.872907+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/restart - 200 (8ms)	\N	172.18.0.6	200	\N
fd3d212b-3281-4d4e-ae23-aebbf381794f	2026-05-16 11:30:02.200942+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
99b8fd45-52c1-4efe-8218-edbe3e5f2437	2026-05-16 11:32:04.77039+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
7958d4db-94de-49ea-b879-0cb04ddc2130	2026-05-16 11:37:57.308106+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
378ea663-6d15-4763-8b73-ddb7b1c3c5e3	2026-05-16 11:37:58.940616+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
549792ef-426e-4549-b923-c71974e3d446	2026-05-24 14:27:31.207702+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/student/reset - 200 (67ms)	\N	172.18.0.6	200	\N
63a4e025-f45e-471f-a24d-cc2d3c8fe0d9	2026-05-16 11:32:04.80503+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b76732b4-f69c-474e-8198-c0a98de7ea59	2026-05-16 11:37:57.29714+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f1e741dd-61a3-48c0-9424-aa38dd8140a5	2026-05-16 11:37:58.941172+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
18fc2b48-1e12-4109-a081-2d7847ce3828	2026-05-16 11:43:50.289403+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
ec0cab55-3786-46a4-a3c8-ef3685775235	2026-05-16 11:43:50.27516+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
56cd6e99-4a37-4e87-bafd-f0f59ce6486b	2026-05-16 11:44:48.73572+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (14ms)	\N	172.18.0.6	404	\N
a2cfe822-bd7b-4903-b16a-f14bc21510e1	2026-05-16 11:44:48.72398+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
d54e1858-2b0d-4648-825c-a703f4af434a	2026-05-16 12:13:02.01089+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
dbe215c8-172d-4914-a927-78f9d94ebfe9	2026-05-16 12:13:02.031467+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
294f9b5c-eff6-48ce-9c69-904b6bcb6017	2026-05-16 12:13:17.997237+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
a8c7e49d-9858-48b1-988e-68c7f9e28c93	2026-05-16 12:13:17.998187+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2d5e6f11-882d-4635-a951-59653a6900eb	2026-05-16 12:14:23.690332+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (9ms)	\N	172.18.0.6	404	\N
26c18239-35be-4fd4-9c36-9cdf46bff11a	2026-05-16 12:14:23.69147+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
90b7cde1-7de8-4099-b26e-dba61fbec4d0	2026-05-16 12:19:03.46151+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c9659ed5-5b65-45e0-b204-ca959cc42f41	2026-05-16 12:19:03.486985+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
2283a88d-0f91-4f63-9e40-cd6ba9286dfd	2026-05-16 12:19:26.45639+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b55b11c7-7a52-49a5-abae-12612b9f01a9	2026-05-16 12:19:26.456923+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
942b71af-4c01-45ff-acd7-e6d2ed24bec9	2026-05-16 12:20:11.303457+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
0990031c-3baf-4903-a028-d71fd1f2fc38	2026-05-16 12:20:11.305132+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c400c3b3-10f6-4df5-9e5c-f3c2abd4e290	2026-05-16 12:20:34.743298+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: face2voice	\N	172.18.0.6	201	\N
f0ae23d5-f03c-4ce7-b13e-5165ead43d1d	2026-05-16 12:20:34.7435+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: face2voice	\N	172.18.0.6	\N	\N
733bea0e-9094-4c7f-ad95-c3664df2118a	2026-05-16 12:20:34.799203+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (225ms)	\N	172.18.0.6	201	\N
5d9f3e4b-2ce9-49c0-af52-95e8aea832f0	2026-05-16 12:41:59.097969+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
4bced771-5618-4fb1-ab12-fb0dabb9ea06	2026-05-16 12:41:59.148693+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9789e692-1ec7-483c-882d-692c428b606d	2026-05-16 12:42:02.389175+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/summary - 404 (246ms)	\N	172.18.0.6	404	\N
f3fd0fb5-61ff-44f9-b94a-b57840dbe27f	2026-05-16 12:42:02.38862+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/branches - 404 (253ms)	\N	172.18.0.6	404	\N
3ddd11d1-8039-46c2-a23d-c6ed4412087d	2026-05-16 12:42:02.413371+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/files - 404 (272ms)	\N	172.18.0.6	404	\N
7fdc0ab5-8023-4c85-afbd-55a283b831fc	2026-05-16 12:42:02.776953+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/files - 404 (324ms)	\N	172.18.0.6	404	\N
dd5eab7c-9b76-43e3-bd61-ae0084a849bb	2026-05-16 12:42:02.79176+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/summary - 404 (345ms)	\N	172.18.0.6	404	\N
17b88cf5-51c4-4531-9219-fd60ce7604a8	2026-05-16 12:42:02.792159+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/branches - 404 (348ms)	\N	172.18.0.6	404	\N
300deb99-95c9-4697-914b-06060d0653e2	2026-05-16 12:42:04.408955+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/branches - 404 (448ms)	\N	172.18.0.6	404	\N
7fe941ff-4ae2-4ad7-8bd8-2f158d130e5c	2026-05-16 12:42:04.410924+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/branches - 404 (462ms)	\N	172.18.0.6	404	\N
228ecb91-042d-49f4-a546-a0e3b253efa4	2026-05-16 12:42:04.409911+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/summary - 404 (445ms)	\N	172.18.0.6	404	\N
4bf0bb7e-cd20-4dbf-88a1-fafdb11ed216	2026-05-16 12:42:04.41125+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/files - 404 (455ms)	\N	172.18.0.6	404	\N
1e2a1a33-8f94-4f07-8721-6ba48017bb04	2026-05-16 12:42:04.418503+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/summary - 404 (454ms)	\N	172.18.0.6	404	\N
d80a1720-1c8d-4925-a77d-86fd3258e588	2026-05-16 12:42:04.478188+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74/files - 404 (512ms)	\N	172.18.0.6	404	\N
c9cf089e-e3a8-4ccd-ac45-5f081a38e08d	2026-05-16 12:42:11.711772+00	INFO	admin	\N	\N	\N	DELETE /students/me/repositories/6f7a34db-e2ae-454b-8a95-4ede23e1ba74 - 204 (270ms)	\N	172.18.0.6	204	\N
cf00d7af-62c7-4715-bc50-a89821de5550	2026-05-16 12:42:20.29891+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: face2voice	\N	172.18.0.6	201	\N
2ede5933-59ff-4c30-b715-f23c9c6b8989	2026-05-16 12:42:20.299115+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: face2voice	\N	172.18.0.6	\N	\N
b1cbdbfe-94de-4993-87d3-a62fde0813ff	2026-05-16 12:42:20.32223+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (475ms)	\N	172.18.0.6	201	\N
04b80ad0-476d-483f-9d93-362330eef685	2026-05-16 12:42:21.396051+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/summary - 404 (227ms)	\N	172.18.0.6	404	\N
cb68a65e-68da-4ee4-a347-5c27d2405059	2026-05-16 12:42:21.397762+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/branches - 404 (229ms)	\N	172.18.0.6	404	\N
0cd0bdde-593a-4e3e-804e-5251fdc3e309	2026-05-16 12:42:21.408331+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/files - 404 (247ms)	\N	172.18.0.6	404	\N
f87cd7ad-a598-47ea-b353-d106e5b93fb2	2026-05-16 12:42:21.655441+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/branches - 404 (239ms)	\N	172.18.0.6	404	\N
686a7e19-3687-44df-be05-2972332a46dd	2026-05-16 12:42:21.687427+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/summary - 404 (274ms)	\N	172.18.0.6	404	\N
0787364f-9b83-4e3a-bfd3-5a0e1d09af18	2026-05-16 12:42:21.697585+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/files - 404 (221ms)	\N	172.18.0.6	404	\N
3b0315c5-5e9b-4d8e-89d5-67a5866f882c	2026-05-16 12:42:29.77197+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: 123213	\N	172.18.0.6	\N	\N
c64ab69b-5c43-4157-b5d0-1830f8e5fadd	2026-05-16 12:42:29.771722+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: 123213	\N	172.18.0.6	201	\N
a5f59d7d-9456-466d-a722-117ff34ef7e2	2026-05-16 12:42:29.796683+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (278ms)	\N	172.18.0.6	201	\N
63351d3a-0a34-4649-91c1-0d57f5a38bc9	2026-05-16 12:42:31.323891+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/branches - 404 (253ms)	\N	172.18.0.6	404	\N
bbbd8777-1079-44ca-bd80-968d75568cf4	2026-05-16 12:42:31.324696+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/summary - 404 (250ms)	\N	172.18.0.6	404	\N
99fcbe11-6d0c-4027-8fdd-2e611e6808aa	2026-05-16 12:42:31.32549+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/files - 404 (252ms)	\N	172.18.0.6	404	\N
706de818-ecc2-4cf3-9671-c108bf13e3a4	2026-05-16 12:42:31.577186+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/branches - 404 (235ms)	\N	172.18.0.6	404	\N
764e4ef3-15fe-40d0-8046-746e867e0772	2026-05-16 12:42:38.308191+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/files - 404 (456ms)	\N	172.18.0.6	404	\N
31e20487-acb7-4394-8a3c-5b6ad421652c	2026-05-24 14:27:34.175153+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Updated permissions for role: student	\N	172.18.0.6	200	\N
21e5aa38-4237-4e7a-bea5-c33d70729f29	2026-05-24 15:29:02.70106+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Reset permissions to defaults for role: admin	\N	172.18.0.6	200	\N
c2a788ff-2b7c-4eba-b38c-8763476e0dcf	2026-05-16 12:42:31.620229+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/summary - 404 (238ms)	\N	172.18.0.6	404	\N
8cfe5d2a-957d-460f-9ccf-8f77d5e65f5b	2026-05-16 12:42:38.306081+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/branches - 404 (510ms)	\N	172.18.0.6	404	\N
2fb41a9e-6c01-4001-91ba-8ee4a0eb7b74	2026-05-24 15:29:02.701684+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/admin/reset - 200 (60ms)	\N	172.18.0.6	200	\N
ad850fc4-0c53-47c3-b4e4-c80bea059d78	2026-05-24 15:30:34.001014+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Reset permissions to defaults for role: admin	\N	172.18.0.6	200	\N
e081c896-bfa0-4ad7-9a1e-09b96a428c39	2026-05-24 15:30:34.984385+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/admin/reset - 200 (24ms)	\N	172.18.0.6	200	\N
9a7b8410-3df2-4ad0-8022-711e905aaffc	2026-05-16 12:42:31.627558+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/files - 404 (239ms)	\N	172.18.0.6	404	\N
f6b34f36-6eef-46f1-85b7-52d279234250	2026-05-16 12:42:38.307389+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/summary - 404 (457ms)	\N	172.18.0.6	404	\N
f63d9dde-4258-4270-bd30-714af7c14776	2026-05-24 15:30:34.001837+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/admin/reset - 200 (26ms)	\N	172.18.0.6	200	\N
a8ba69f4-ecdf-4a41-8546-e7ce6f6ae87f	2026-05-16 12:42:38.256536+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/branches - 404 (469ms)	\N	172.18.0.6	404	\N
f42685b0-1063-4714-bce5-52d1ed7c0fa4	2026-05-16 12:42:38.305324+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/files - 404 (511ms)	\N	172.18.0.6	404	\N
935be1d8-7e41-4da1-98b9-960e03b75eb5	2026-05-24 15:30:34.983787+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Reset permissions to defaults for role: admin	\N	172.18.0.6	200	\N
4dee4fa7-0221-4c81-bb4d-da9e861ca53b	2026-05-24 15:30:36.508219+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/admin - 200 (60ms)	\N	172.18.0.6	200	\N
268ed189-aa85-4ea4-9cf6-7683929c2607	2026-05-24 15:30:37.183427+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /roles/permissions/admin/reset - 200 (31ms)	\N	172.18.0.6	200	\N
10e73fa7-8363-486e-b63a-cf7545bf5a2e	2026-05-16 12:42:38.340515+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9/summary - 404 (489ms)	\N	172.18.0.6	404	\N
b2d3a5ac-6a50-466f-ae91-89a34430407d	2026-05-16 12:49:52.918407+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
7b83ecc6-2c66-453c-917b-bc55ec0def9e	2026-05-16 12:49:52.93768+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b5f45ee2-8f85-4e7c-a678-2f581356f6ec	2026-05-16 12:49:57.032088+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/branches - 404 (339ms)	\N	172.18.0.6	404	\N
7bc6e921-6d07-4766-b0c0-aa2c94465ef1	2026-05-16 12:49:57.13425+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/files - 404 (440ms)	\N	172.18.0.6	404	\N
eecbb630-8edf-4964-9967-351fc28c937a	2026-05-16 12:49:57.73586+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec/branches - 404 (697ms)	\N	172.18.0.6	404	\N
da9d948a-abf9-4d98-97a9-2827cf46a3dc	2026-05-16 12:50:13.763974+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: 123123	\N	172.18.0.6	\N	\N
690462fa-7c3b-4446-b5bf-3dc584c9320b	2026-05-16 12:50:13.763765+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: 123123	\N	172.18.0.6	201	\N
7c7ed2ea-6420-4fba-9db8-3e29cf0510a4	2026-05-16 12:50:13.786854+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (248ms)	\N	172.18.0.6	201	\N
e919335b-85cc-4d84-af88-473de37e635b	2026-05-16 12:50:16.28049+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/687cdc70-b0d4-40e4-b7ff-b44ee6568314/branches - 404 (330ms)	\N	172.18.0.6	404	\N
7a7d663f-30d0-4dd1-8334-52a2ce395625	2026-05-16 12:50:16.376552+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/687cdc70-b0d4-40e4-b7ff-b44ee6568314/files - 404 (420ms)	\N	172.18.0.6	404	\N
aa024fd1-37da-44ed-b974-3ea304cea9ab	2026-05-16 12:50:17.073962+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/687cdc70-b0d4-40e4-b7ff-b44ee6568314/branches - 404 (786ms)	\N	172.18.0.6	404	\N
bdf695be-3aa8-4736-b970-a8029c982566	2026-05-16 12:50:51.879332+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
b651a747-bd46-47fc-af93-6b7e8dc52180	2026-05-16 12:50:51.923123+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (333ms)	\N	172.18.0.6	200	\N
dd0245f7-ed72-4e2b-9c8c-a39033778690	2026-05-16 12:50:51.969845+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
3e53a7f2-3c84-4740-b1b5-d74b0c15f214	2026-05-16 12:50:51.973792+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
cce43e54-fc0f-483a-a673-f33775270c83	2026-05-16 12:50:58.497308+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (12ms)	\N	172.18.0.6	400	\N
d5f22784-018a-463f-9d81-87b18da5fea8	2026-05-16 12:50:59.847495+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (5ms)	\N	172.18.0.6	400	\N
95b70e7f-a445-4c24-a74e-3de890363a88	2026-05-16 12:51:01.718496+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (5ms)	\N	172.18.0.6	400	\N
59330283-c243-4048-abc8-003d70a4a44c	2026-05-16 12:51:02.284948+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (5ms)	\N	172.18.0.6	400	\N
583494ee-f60d-4fb8-9319-65d68e643380	2026-05-16 12:51:02.452772+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (4ms)	\N	172.18.0.6	400	\N
92b40e38-31a4-46d0-9d55-42396f7bf904	2026-05-16 12:51:02.655117+00	WARNING	admin	\N	\N	\N	POST /repositories/ - 400 (5ms)	\N	172.18.0.6	400	\N
205151c3-1a3e-4434-90f1-7a370f6eef40	2026-05-16 12:51:11.804185+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: 1235442133241	\N	172.18.0.6	201	\N
b766c353-2709-4071-a562-f69df624017c	2026-05-16 12:51:11.804611+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: 1235442133241	\N	172.18.0.6	\N	\N
290de1ae-1c36-4d0d-90c4-7720078948ba	2026-05-16 12:51:11.830329+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (329ms)	\N	172.18.0.6	201	\N
543fafbb-756f-4c90-80b3-27108d7ff526	2026-05-16 12:51:13.657307+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/340afe7c-05f7-4b79-a79c-a4ed1fabfcd0/files - 404 (348ms)	\N	172.18.0.6	404	\N
ed3a9c06-000e-4646-8b32-4abb1215df80	2026-05-16 12:51:13.736252+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/340afe7c-05f7-4b79-a79c-a4ed1fabfcd0/summary - 404 (418ms)	\N	172.18.0.6	404	\N
7793b295-71f0-46c2-84b4-ae0e9a897e84	2026-05-16 12:53:14.187624+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b09d3343-44ff-429f-ab7e-00f89e598eac	2026-05-16 12:53:14.242471+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
64e4e7e3-c691-4b63-96c4-839bbb89291b	2026-05-16 12:54:11.931135+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
cd11ea17-4945-44e2-8d00-c013ecb6b734	2026-05-16 12:54:11.932383+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
67386df5-e0c1-4f71-9bd0-2ddf5230161a	2026-05-16 12:54:21.466992+00	INFO	admin	\N	\N	\N	DELETE /students/me/repositories/340afe7c-05f7-4b79-a79c-a4ed1fabfcd0 - 204 (299ms)	\N	172.18.0.6	204	\N
944e1cfa-34ca-4287-a833-a6634c13759e	2026-05-16 12:54:23.533605+00	INFO	admin	\N	\N	\N	DELETE /students/me/repositories/687cdc70-b0d4-40e4-b7ff-b44ee6568314 - 204 (335ms)	\N	172.18.0.6	204	\N
f39e6016-0df6-465c-9790-628adcc3ea8f	2026-05-16 12:54:25.533709+00	INFO	admin	\N	\N	\N	DELETE /students/me/repositories/46af23be-6566-4514-ac2f-4a77a39d69ec - 204 (318ms)	\N	172.18.0.6	204	\N
b29c1de5-5d34-4887-ba5c-09c0ef0f6025	2026-05-16 12:54:27.325282+00	INFO	admin	\N	\N	\N	DELETE /students/me/repositories/6722d658-12b1-43e9-ac0c-ee163c8682d9 - 204 (245ms)	\N	172.18.0.6	204	\N
13598f00-1081-4486-b732-6c0607c14a11	2026-05-16 12:54:37.894448+00	INFO	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Created repository: face2voice	\N	172.18.0.6	201	\N
865e8146-bde8-4248-a2a3-4b9008d9a990	2026-05-16 12:54:37.894643+00	WARNING	repositories	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Repository created in DB but Gitea creation failed: face2voice	\N	172.18.0.6	\N	\N
da845c09-9540-48eb-9b4d-7c79648a0761	2026-05-16 12:54:37.926457+00	INFO	admin	\N	\N	\N	POST /repositories/ - 201 (307ms)	\N	172.18.0.6	201	\N
66e73249-a331-45fb-b9e5-37e00c7f6c3c	2026-05-16 12:54:39.343316+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/branches - 404 (345ms)	\N	172.18.0.6	404	\N
d91ec44f-1d74-4909-be61-8fef9372b0d7	2026-05-16 12:54:39.448091+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/files - 404 (446ms)	\N	172.18.0.6	404	\N
fc34fce3-d64f-41a3-8670-4fda9b05a64b	2026-05-16 12:54:40.023762+00	WARNING	admin	\N	\N	\N	GET /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/branches - 404 (674ms)	\N	172.18.0.6	404	\N
602cfb6a-5d34-4059-9a6e-48a5a54cc744	2026-05-16 12:54:45.562248+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
84478d2a-5a05-4cc8-a544-09dc145cd62d	2026-05-16 12:54:45.464695+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
4bca5e68-dfd4-4bfa-9f8d-69b707c305d4	2026-05-16 12:56:32.003261+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e0ef917b-faaf-4a0f-ad50-6900d7661fbe	2026-05-16 12:56:32.073671+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
08ade00d-057a-462a-8ba7-4ba6b10dae5c	2026-05-16 13:02:55.061985+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
3ec61a61-d12f-4236-84be-33483f16d2e1	2026-05-16 13:02:55.144215+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
9b66a2eb-5fd8-4b5a-9153-3cc858dcc766	2026-05-16 13:03:06.148416+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (9ms)	\N	172.18.0.6	404	\N
5825f550-ee3c-468e-ac27-983bcb6aa271	2026-05-16 13:03:06.152498+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
9b2545dd-85fb-4432-8852-4d55f11ac596	2026-05-16 13:03:20.3461+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/files - 200 (855ms)	\N	172.18.0.6	200	\N
74e5a0cf-3c2f-4e62-9a52-3a3bd3059af9	2026-05-16 13:05:15.751222+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
93c537a2-6dc7-451d-9f7c-bb9af70170d4	2026-05-16 13:05:15.757455+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9fd2ef5c-3cd5-4c3d-ae15-c585ba2fe071	2026-05-16 13:08:20.442929+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
594ece82-4fb6-4283-ad34-c6a147671f1e	2026-05-16 13:08:20.605463+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
010f5ca0-b735-4210-b823-887e1b7e239d	2026-05-16 13:08:41.33651+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
d214a58b-bc2f-41b3-99b5-f39b41d0636f	2026-05-16 13:08:41.355366+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
40e48b7f-de59-4cb6-a4dd-3d3027ad192e	2026-05-16 13:09:52.217129+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
906a1bd4-97d2-4323-8b15-5372d0919967	2026-05-16 13:09:52.218077+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
75f481f4-5b71-4dd6-a5dc-bbed8fc06bf2	2026-05-16 13:10:07.466021+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
8bbe17d2-7db9-40b8-ae59-4cbf4dab2dc4	2026-05-16 13:10:08.143706+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
ccd673df-6a1c-411c-9021-a0f5c2083b5b	2026-05-16 13:10:13.595511+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (149ms)	\N	172.18.0.6	200	\N
6eaaabf1-20d3-4657-bee1-7b1336f6a264	2026-05-16 13:10:18.784945+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (117ms)	\N	172.18.0.6	200	\N
ff9171a7-4e0b-46e5-905d-fa50336c9e01	2026-05-16 13:10:19.113413+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (157ms)	\N	172.18.0.6	200	\N
c1d3fec5-7338-4d6b-9d3b-f84798cb0a9f	2026-05-16 13:10:29.832959+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (166ms)	\N	172.18.0.6	200	\N
efa98904-c7cd-4b12-9205-b2981e208d21	2026-05-16 13:10:30.100901+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (144ms)	\N	172.18.0.6	200	\N
37ebff75-f184-448d-93a7-087b532c9e79	2026-05-16 13:10:31.546766+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (164ms)	\N	172.18.0.6	200	\N
c8198bd9-8111-4636-9211-8389e9b5e76b	2026-05-16 13:10:31.82576+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (147ms)	\N	172.18.0.6	200	\N
d87272de-5a33-4d90-a1fe-bf88cfcbe48d	2026-05-16 13:11:45.564931+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
867db9dc-8aa1-40ff-94dc-36a0351eb8c8	2026-05-16 13:11:45.6654+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
4db7da07-6bb8-4990-81d2-f78f0c89f1e8	2026-05-16 13:12:11.318759+00	INFO	admin	\N	\N	\N	POST /students/me/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/lint - 200 (131ms)	\N	172.18.0.6	200	\N
4e7cfead-5953-4f42-9fb4-a9d586030a48	2026-05-16 15:32:11.721959+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (8ms)	\N	172.18.0.6	404	\N
ab13e921-c8b1-4087-90b2-493d054d8bcb	2026-05-16 15:32:11.756303+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
85226498-e893-4e07-bc82-ae0b88e549a4	2026-05-16 15:41:10.786585+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
106c058c-b108-4d22-b95c-6a1e3d2a43a8	2026-05-16 15:41:10.841099+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
cf28274a-b9cb-4994-b24e-87eab27d6638	2026-05-16 15:57:44.905934+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
3fd9ba01-ff65-4b24-be0c-491e4bbf404c	2026-05-16 15:57:45.093022+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2da9e433-2cdc-4f2d-b1b2-fe00ccef0442	2026-05-16 16:07:41.604392+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
dbe361f7-8977-40fd-ba11-529ab9bbf088	2026-05-16 16:07:41.651957+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
876b57dc-ea89-418c-858a-231b0a8f9782	2026-05-16 16:07:58.442558+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e8930647-7c70-4336-aa66-ed3459898559	2026-05-16 16:07:58.469856+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
8e996097-2617-4fdf-927a-d20f47981d5b	2026-05-16 16:09:25.322463+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (78ms)	\N	172.18.0.6	200	\N
ffc466db-2869-48da-a07b-0500082fe5f6	2026-05-16 16:09:27.621314+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (35ms)	\N	172.18.0.6	200	\N
733341be-83f4-4aab-8cf7-77028fbc1385	2026-05-16 16:09:29.27063+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (28ms)	\N	172.18.0.6	200	\N
655dac22-b187-4cc0-a6c0-8dfc574fbffa	2026-05-16 16:09:30.797111+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
dae4ebdb-8584-4e9d-a301-d698c963f2e6	2026-05-16 16:09:36.382769+00	ERROR	admin	\N	\N	\N	POST /students/me/git-clone-token/regenerate - 502 (121ms)	\N	172.18.0.6	502	\N
cb8af909-c6a1-4180-af0c-ab8e21659803	2026-05-16 16:15:29.573071+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c47a88ac-184c-4083-b7fe-c087ef02fa11	2026-05-16 16:15:29.583467+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
1d3b1fdd-5d17-4ae3-8e7e-92c13fcafe46	2026-05-16 16:15:30.523316+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
fb7f25a9-2b1a-4b7d-a353-8c1f84634129	2026-05-16 16:15:44.86401+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (12ms)	\N	172.18.0.6	200	\N
7dad7014-d270-4a14-b242-832f48dbb311	2026-05-16 16:15:51.296406+00	ERROR	admin	\N	\N	\N	POST /students/me/git-clone-token/regenerate - 502 (101ms)	\N	172.18.0.6	502	\N
0cb67ef8-6fbc-48f0-8337-2df7312b9905	2026-05-16 16:35:10.859414+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f71f8c59-dc0d-4c82-a38d-3bf4a4ea1411	2026-05-16 16:35:10.820133+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
869f717c-b4c5-4cba-b362-a5538ece5d0a	2026-05-16 16:35:17.167131+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (11ms)	\N	172.18.0.6	200	\N
1fa08f02-4106-4226-adb4-c200702f3af7	2026-05-16 16:35:19.405296+00	INFO	admin	\N	\N	\N	POST /students/me/git-clone-token/regenerate - 200 (511ms)	\N	172.18.0.6	200	\N
d6fb7d3c-5049-4a64-a484-13db9e0f190d	2026-05-16 16:35:36.771469+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (42ms)	\N	172.18.0.6	200	\N
c8332349-efc0-4c60-90fd-4d0f903b6d08	2026-05-16 16:35:55.637226+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
978c2157-7e37-4134-9858-525643514f18	2026-05-16 18:32:35.092694+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
98581477-9c62-4934-b961-803fa77bd5a7	2026-05-16 18:32:34.978904+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
02727f68-69c7-4727-a1ab-41853703e764	2026-05-16 18:32:35.759316+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (136ms)	\N	172.18.0.6	200	\N
e4460632-82ab-4c7c-8098-d9eccec7c899	2026-05-16 18:33:24.88244+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (98ms)	\N	172.18.0.6	200	\N
3e29cc61-eb6c-4ca8-90f5-f84a12232005	2026-05-16 18:33:25.245044+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
aa07558b-6571-4b19-a4f9-ee12c87fafc4	2026-05-16 18:36:08.7591+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
7211f33a-49ae-42a5-b7bc-4878da722d3c	2026-05-16 18:36:08.911241+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
86119048-7501-4720-a359-46218153132d	2026-05-16 18:36:08.962076+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (1ms)	\N	172.18.0.6	401	\N
43018ff1-d2ae-491f-98d8-f5d23ac12340	2026-05-16 18:36:08.975578+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
115adfa6-a2e3-47b5-b9a1-6c4edfa8760b	2026-05-16 18:36:09.083066+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (4ms)	\N	172.18.0.6	401	\N
24b08df9-c527-4df5-9dbe-eaa07964cbb6	2026-05-16 18:36:09.144825+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
648b144d-2751-4497-bdc0-fad15f419dde	2026-05-16 18:36:09.160235+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (6ms)	\N	172.18.0.6	401	\N
6383514f-9d3b-488b-ad43-1e44167e2cca	2026-05-16 18:36:09.280914+00	WARNING	admin	\N	\N	\N	GET /notifications - 401 (1ms)	\N	172.18.0.6	401	\N
104a87a7-919a-47a0-a834-663307e93c69	2026-05-16 18:36:09.354331+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (0ms)	\N	172.18.0.6	401	\N
afbf7671-b755-472d-9939-34e4a8fd8277	2026-05-16 18:36:09.394696+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (7ms)	\N	172.18.0.6	401	\N
44f4b486-872f-43c2-88ca-b4168924d083	2026-05-16 18:36:09.398156+00	WARNING	admin	\N	\N	\N	GET /notifications - 401 (14ms)	\N	172.18.0.6	401	\N
ac76d9df-ad89-4c15-a7e1-d6243fd75b5c	2026-05-16 18:36:09.866747+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (71ms)	\N	172.18.0.6	200	\N
1015959e-9e85-4340-ae4b-754cf4a2fb13	2026-05-16 18:37:14.298531+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
4b368338-5c61-4bea-9b6e-54a02d1f33b6	2026-05-16 18:41:09.296218+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (334ms)	\N	172.18.0.6	200	\N
829caad0-6cc0-4c85-a540-9c2254c5542a	2026-05-24 15:30:36.507531+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Updated permissions for role: admin	\N	172.18.0.6	200	\N
19938ca8-8559-4f82-af58-fbda0a4517f7	2026-05-16 18:37:14.387729+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
62644f4b-e5e8-42b8-ae04-91841c93b0df	2026-05-16 18:37:15.253086+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
95d6a068-ec6a-48bb-a28d-520225eb90df	2026-05-16 18:41:09.243196+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
dd561e3f-866d-4dd4-9ea7-616d74d8e8ca	2026-05-16 18:41:09.537186+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
79e0da00-903b-4012-be55-16db435b2a16	2026-05-16 18:41:37.072213+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
52b6897c-7f29-4704-9d94-22c97a07d728	2026-05-16 18:42:02.4248+00	INFO	admin	\N	\N	\N	POST /courses - 201 (132ms)	\N	172.18.0.6	201	\N
67c918f5-45e8-4768-8d97-efd1cfc1d312	2026-05-16 18:44:06.037033+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (68ms)	\N	172.18.0.6	200	\N
5314b517-d8af-4453-9f10-e279f09bf3a6	2026-05-16 18:44:06.994561+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
36807922-eee0-4be0-8520-e81bb473b152	2026-05-16 18:44:26.541352+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
a8263c36-61fd-4e81-b56d-3864cc3e6e5c	2026-05-16 18:45:04.681597+00	WARNING	admin	\N	\N	\N	GET /students/me/grades - 403 (3ms)	\N	172.18.0.6	403	\N
65c1cc2c-1acf-4a5a-8e1d-2495a3e3f5ab	2026-05-16 18:45:06.76185+00	WARNING	admin	\N	\N	\N	GET /students/me/deadlines - 403 (5ms)	\N	172.18.0.6	403	\N
e7bd248e-3c68-4810-90e7-fb85b2400290	2026-05-16 18:45:07.48009+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 403 (5ms)	\N	172.18.0.6	403	\N
f07efc50-bf2b-49f6-b7b5-daf1e058d71b	2026-05-16 18:45:10.407892+00	WARNING	admin	\N	\N	\N	GET /students/me/forks - 403 (3ms)	\N	172.18.0.6	403	\N
36822770-08c9-4d4a-8e02-e77a4a5dacd8	2026-05-16 18:45:10.418146+00	WARNING	admin	\N	\N	\N	GET /students/me/forks - 403 (3ms)	\N	172.18.0.6	403	\N
a80e72f0-a05c-476a-92de-5b47be4e6fba	2026-05-16 18:45:34.016746+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
b7c40cce-2df2-46fd-a9e4-712170b8c8a2	2026-05-16 18:45:34.263057+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
d1bdb5d8-1adb-4fd0-8fd0-d3be8cc9a4cb	2026-05-16 18:45:34.58923+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (28ms)	\N	172.18.0.6	200	\N
6f4db9f6-7b07-44a0-baf8-60691e29b082	2026-05-16 18:45:37.561175+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
5612f494-5450-47c3-baf9-4bc55d164803	2026-05-16 18:45:38.210918+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b2806e01-9a12-4ee3-8bf3-8936e19c6665	2026-05-16 18:46:24.390111+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b04e271f-6240-407d-825b-40f8174fb594	2026-05-16 18:46:31.114148+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
fcaf8c8e-033b-4a22-8b17-39f5390c2b1a	2026-05-16 18:46:31.224179+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
c9bc979b-5a38-4af6-8979-5442b9a01dc5	2026-05-16 18:46:35.029725+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
5313a431-20eb-4d5b-aca8-a544cbeb8495	2026-05-16 18:46:35.22414+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
fd591a14-1117-490c-bde9-9ef8a15d1495	2026-05-16 18:46:42.639731+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
52a02483-fe6c-4b47-9f61-dd2e4a5ea522	2026-05-16 18:46:42.637658+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
dbe23913-781b-4c1a-93fd-26c096e297f7	2026-05-24 15:30:37.182839+00	INFO	permissions	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Reset permissions to defaults for role: admin	\N	172.18.0.6	200	\N
43416a08-50b7-4a3b-8bed-d9e91f8c4ca0	2026-05-16 18:41:09.370129+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e5121a57-6900-4e7c-b1b8-653f4abc8dd2	2026-05-16 18:41:22.952059+00	INFO	admin	\N	\N	\N	PATCH /admin/users/a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9 - 200 (34ms)	\N	172.18.0.6	200	\N
25825c7c-ecd5-4cab-99fb-8be00a3e7f89	2026-05-16 18:41:36.87386+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
2322823c-80ea-4adc-b1dd-2a6e886baa62	2026-05-16 18:41:36.971457+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (350ms)	\N	172.18.0.6	200	\N
3fe5ee6d-0901-4304-b4a6-a136678fccab	2026-05-16 18:41:37.033793+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
c95ce881-895a-4d37-86b5-37f96d4d6447	2026-05-16 18:42:15.629995+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (34ms)	\N	172.18.0.6	200	\N
c58cbec6-d914-45b2-a3e4-4434ce266f09	2026-05-16 18:42:41.376772+00	INFO	admin	\N	\N	\N	POST /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments - 201 (54ms)	\N	172.18.0.6	201	\N
332c72b2-364d-485f-8a4c-f1d66e9c5677	2026-05-16 18:44:06.380612+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
a742d814-c5e5-4b53-86e6-b505c7959ea5	2026-05-16 18:44:06.602863+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (28ms)	\N	172.18.0.6	200	\N
83755123-6950-4804-9fcc-ed313ecc1156	2026-05-16 18:44:26.142819+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (27ms)	\N	172.18.0.6	200	\N
0afeed92-6688-4482-9883-21486d4311b5	2026-05-16 18:45:04.672483+00	WARNING	admin	\N	\N	\N	GET /students/me/grades - 403 (4ms)	\N	172.18.0.6	403	\N
35e65beb-986c-4491-9473-5b8d039d4d61	2026-05-16 18:45:05.128127+00	WARNING	admin	\N	\N	\N	GET /students/me/deadlines - 403 (4ms)	\N	172.18.0.6	403	\N
01a9410f-b5b3-40a8-9d7e-cb2f9c66f4c2	2026-05-16 18:45:05.138242+00	WARNING	admin	\N	\N	\N	GET /students/me/deadlines - 403 (4ms)	\N	172.18.0.6	403	\N
9d77542c-471a-48a5-a89f-b4b13b73e1ac	2026-05-16 18:45:06.146376+00	WARNING	admin	\N	\N	\N	GET /students/me/grades - 403 (6ms)	\N	172.18.0.6	403	\N
479f8af4-38b6-4fe7-b9c4-da3ea434897e	2026-05-16 18:45:06.147361+00	WARNING	admin	\N	\N	\N	GET /students/me/grades - 403 (6ms)	\N	172.18.0.6	403	\N
399430fc-7a3d-4c25-ab93-e723548f1b91	2026-05-16 18:45:06.763888+00	WARNING	admin	\N	\N	\N	GET /students/me/deadlines - 403 (6ms)	\N	172.18.0.6	403	\N
069040c3-5db6-486a-9619-06bda07235b6	2026-05-16 18:45:07.468451+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 403 (3ms)	\N	172.18.0.6	403	\N
52e91fa7-9dc7-4dc8-8c1a-7c4d827e2b3a	2026-05-16 18:45:08.972195+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 403 (5ms)	\N	172.18.0.6	403	\N
630f2954-7b6b-4af0-a735-7c5ef403550d	2026-05-16 18:45:08.973019+00	WARNING	admin	\N	\N	\N	GET /students/me/assignments - 403 (5ms)	\N	172.18.0.6	403	\N
b4a312c5-b5f1-4bff-bd48-da4ab8754371	2026-05-16 18:45:34.133284+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
dabfd67b-aa0a-4898-8eee-35b8e0b30ddb	2026-05-16 18:45:34.212312+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
5ecc5867-e372-4ff7-bad5-89bba567a54f	2026-05-16 18:45:35.215334+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
ab8cd13a-d553-4d95-ad34-48e91deb9a06	2026-05-16 18:45:37.558699+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
93181f8c-f901-4223-9deb-34479a55805a	2026-05-16 18:45:38.002855+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
d4a8e28e-3eed-424f-b25b-1caaef17cccc	2026-05-16 18:45:38.234596+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
94ef4456-36ff-4605-9a42-165d77ed77b1	2026-05-16 18:45:39.204528+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
7bbce98f-594d-479c-b800-baf8f760b828	2026-05-16 18:46:24.929413+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
40f0c104-a9cd-4b53-acd2-a395da7cf2d3	2026-05-16 18:46:25.206234+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
c98f8f07-95cf-47b7-a853-4947a0c074b1	2026-05-16 18:46:25.218618+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9144293c-cc9c-48ae-aba6-6c9e17294891	2026-05-16 18:46:27.963809+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
0702f4ef-b085-464e-891f-87fa4c3805b5	2026-05-16 18:46:27.965284+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f3672f6d-b249-430a-9916-30038e26e1c1	2026-05-16 18:46:28.205521+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
3bfbf5c7-5f55-46bc-8abe-7400d4572b7f	2026-05-16 18:46:28.270716+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
970b1ff3-f9ca-40b6-bca0-ad4767b0420b	2026-05-16 18:46:31.112811+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
dd19dd23-5eac-4e59-a753-6d1d56cbc281	2026-05-16 18:46:31.213132+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c8fe7295-0715-4459-a257-3ebed4fad68c	2026-05-16 18:46:35.028957+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
0e5df91c-06f0-4f17-ae5b-4259c05d231d	2026-05-16 18:46:35.236372+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
306b362a-fcd2-4aab-ad29-9d19935199dd	2026-05-16 18:46:43.330469+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
add27bbb-7056-4a30-b02c-b1eddbf9a110	2026-05-16 18:46:43.446254+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (29ms)	\N	172.18.0.6	404	\N
007917db-2044-4279-abda-8d0bc9185652	2026-05-16 18:46:43.333753+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
ff25d171-7fd5-4427-b5e4-9601feade3dd	2026-05-16 18:46:43.339119+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
f16a414b-c024-4a11-b6cc-a9f9d3c00d7d	2026-05-16 18:46:46.425719+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
02730a32-5c2b-4cee-88c0-38a5cc998f49	2026-05-16 18:46:46.427328+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c18aa3d1-ab8d-4bc9-a8b4-35bff6b2befb	2026-05-16 18:46:46.973346+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
860fdf9b-843b-4903-ac7d-454c3d6450c0	2026-05-16 18:46:46.970248+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
6b5922f5-9583-46a3-9327-42050aa86241	2026-05-16 18:46:47.211665+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
d9b317d2-451d-4f85-9a5d-f04aedafb3c2	2026-05-16 18:46:47.292434+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
82d4b265-8df1-47d6-a45c-0f364c094c6d	2026-05-16 18:46:47.510861+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (18ms)	\N	172.18.0.6	200	\N
b416d074-fb30-47ba-85f9-19e7fda9dd0a	2026-05-16 18:46:48.212852+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
7e1af588-b60f-4ce4-a47c-83ab7fcb625b	2026-05-16 18:57:56.204602+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2be4105f-8249-40f1-b4e2-75bae3ca1946	2026-05-16 18:57:56.336308+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f1aee186-fa2f-48c1-9f9d-f2dde5b1c3bd	2026-05-16 18:57:56.525383+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (9ms)	\N	172.18.0.6	404	\N
a58ebc48-70c8-43c1-a888-8d4e31c5d5ff	2026-05-16 18:57:56.735525+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
70ea60ce-9ab5-4640-be44-5893469b024d	2026-05-16 18:57:59.745689+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (22ms)	\N	172.18.0.6	200	\N
37435231-cd9b-46d8-ace2-bf7d1897d4a5	2026-05-16 18:58:00.816702+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
bf431dcc-3abb-47fc-88c4-9b8db6f01312	2026-05-16 18:58:01.272494+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b2b044eb-38fc-421d-9be7-8a98da6cbd51	2026-05-16 18:58:30.974325+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
df4764db-9325-4275-8b40-f0a41cb7c4d3	2026-05-16 18:58:30.987071+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
fb095727-7729-43c6-8578-eb69dba88dbb	2026-05-16 18:58:31.253407+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
d4daf427-5d7f-4085-a755-31d8e6a41781	2026-05-16 18:58:31.267303+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f8435ccf-bb0a-4601-abc5-2d97ba7c4dc4	2026-05-16 18:58:32.202674+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
5cc8e928-df7d-4c01-805f-7eaef6805a52	2026-05-16 18:58:46.057933+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
39d057d9-438f-4eb8-a36d-6726ea7d810a	2026-05-16 18:58:46.057695+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ecc4ecc8-907f-4c8c-b548-ec185a79b6f7	2026-05-16 18:59:20.913796+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
04323f45-ceb1-42ec-affe-1ca1db0ddbe5	2026-05-16 18:59:20.995559+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
6aa89434-1412-41a7-8795-a05915084f1a	2026-05-16 18:59:20.916537+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
a1c5c9a0-585a-4919-8b69-8bd042356ef5	2026-05-16 18:59:22.42037+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (43ms)	\N	172.18.0.6	200	\N
97fa93c2-c33b-4e38-81f1-230cb0f5f888	2026-05-16 18:59:45.20326+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
a90f6280-cc3f-4d03-9def-9543c7c3b1e7	2026-05-16 19:00:06.01964+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (25ms)	\N	172.18.0.6	200	\N
b8c85881-ac23-4f33-b0fd-2825b8a59eb7	2026-05-16 19:00:06.273188+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2b59d647-0fe2-4a3f-b327-c0e46fb4d606	2026-05-16 19:00:07.461683+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (217ms)	\N	172.18.0.6	200	\N
7046d70d-d2d2-4e20-9705-8d0a7e9196b8	2026-05-16 18:59:21.007381+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
1dc4dc43-656b-482c-b644-7181cd5a688d	2026-05-16 18:59:22.418128+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (42ms)	\N	172.18.0.6	200	\N
59b99548-7078-4113-9aec-c4bad84b46a8	2026-05-16 18:59:42.265824+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
860bbdda-4aab-44aa-9db6-21db33a38bcb	2026-05-16 18:59:43.329688+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
2c0d2d9c-9a43-4084-a192-73e00ca85199	2026-05-16 19:00:04.772952+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
6804eb76-5f72-4283-8fa0-49f26d4b7244	2026-05-16 19:00:06.008119+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
e593dd57-f5e7-40d4-9ce4-322f26846c32	2026-05-16 19:01:06.027952+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
1b44dcae-d01e-4de2-b7d2-3bd2b9ba9d5e	2026-05-16 19:01:13.027215+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
f562a37c-0295-4892-82c2-4190f552f644	2026-05-16 19:02:55.740129+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
62c9a193-aca6-488d-81c1-ac030c3e40ce	2026-05-16 19:03:00.833131+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
7afff3a3-f166-49be-80a1-73d65c10dc12	2026-05-16 18:59:42.272126+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
b99ea635-6bda-41c7-abe5-2018f7220907	2026-05-16 18:59:43.340006+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (15ms)	\N	172.18.0.6	200	\N
803d5e66-6377-4605-b5b6-7a9b8e2f0560	2026-05-16 18:59:44.026977+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
39ba53e3-0e1d-4773-ab9d-40192186fa72	2026-05-16 19:00:04.756801+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e23c1b09-bf50-4a99-b750-7774c3028dcd	2026-05-16 19:00:17.249668+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
37dc0380-4298-41af-ac69-36d2f03fa652	2026-05-16 19:00:17.252363+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
de2aed19-a321-4918-bab5-219cd4055090	2026-05-16 19:00:17.801259+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
4b1d85f6-2413-4c14-b843-e5d1a2165979	2026-05-16 19:00:18.213999+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
605dfd88-e414-4f66-b7a0-3b884f22df45	2026-05-16 19:00:18.234801+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
1c063976-1a63-4f5f-a440-995df79e1be4	2026-05-16 19:00:19.221687+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
8f22acae-6165-41c3-b9fa-5bf6058fc615	2026-05-16 19:00:26.954841+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
960f43cf-06da-4286-bbd0-5add5f3878ee	2026-05-16 19:00:26.95511+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
940b9c9a-4ac9-4cc8-bade-b4c27d03b163	2026-05-16 19:00:27.476894+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
a959fee1-a672-497f-afea-4323a25e024b	2026-05-16 19:01:07.732384+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
99a4916e-2b11-447b-945b-03958229f5ae	2026-05-16 19:01:09.421131+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
af8cb8fe-6d41-4472-8bce-6e7adfc8b714	2026-05-16 19:01:09.421879+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
48e1ef74-1fd0-4c61-9623-dfb5062028b2	2026-05-16 19:01:13.026963+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
ccc847a8-5fe1-48fe-a6d0-520e24c5f9a5	2026-05-16 19:01:14.381883+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
136601a3-bcb1-4bbe-9286-a72b9324f94a	2026-05-16 19:02:51.81793+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
8fd6b198-3266-4ecf-ac04-a47e80838973	2026-05-16 19:02:51.826932+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9be8b4e5-5f69-459f-af9a-03e5ee31061a	2026-05-16 19:02:58.936916+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
5ed31c95-c74c-4cf6-abc8-fbcc60412ac8	2026-05-16 19:03:00.831563+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
b4b08b5e-f34f-4744-9665-85da238f47bb	2026-05-16 19:03:01.051587+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
c546e453-a275-49c2-ac0e-7d79d992dba8	2026-05-16 19:03:00.942248+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
94d02f84-deee-4379-8cd7-b2962a027f2b	2026-05-16 19:03:02.565962+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f23ed930-46fd-4b2b-aa7b-2b2c144e5783	2026-05-16 19:03:02.68628+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
117a4794-c568-4e5a-84a2-a158de9d53d5	2026-05-16 19:03:02.802359+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
037caeb5-a0df-459d-b945-f7726a221743	2026-05-16 19:03:02.799526+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
6e78ab86-64b1-46fc-b45c-3b0c36317d9c	2026-05-16 19:03:03.50286+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (117ms)	\N	172.18.0.6	200	\N
d3746c83-bf0a-4c17-b141-ddbfc36276da	2026-05-16 19:03:04.155398+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
0b56f4a7-8769-45b5-9b9e-475fcd52cda3	2026-05-16 19:03:04.254296+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
78276992-46f2-4661-870f-cd4a088a08e2	2026-05-16 19:03:04.734212+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f4892ce1-032e-4483-8434-b6972bf3c086	2026-05-16 19:03:04.733387+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
261e2ff6-4230-4fa8-a3ea-b5b05739a0a0	2026-05-16 19:03:05.226392+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
3a042e05-7cdd-4c60-9c51-4986fa12bdbb	2026-05-16 19:03:05.731596+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
08ec44e3-5e8c-4f85-858d-688685dc0ba2	2026-05-16 19:03:16.208377+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
dd9866fa-f0f7-4600-a9e4-3fb9ee1cb16b	2026-05-16 19:03:16.227011+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
6c740b9a-a611-4414-8b94-a6b44a8acd77	2026-05-16 19:03:16.51161+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
fe945a97-cdb6-4a81-89a5-7dac11be6420	2026-05-16 19:03:16.512183+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
63a7d465-775b-471c-8a07-ea990c2472a5	2026-05-16 19:03:17.214225+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
2accb273-3048-4c7e-bb7c-dee56267c953	2026-05-16 19:03:17.398861+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
899392a2-8591-442a-a81d-03296e741a4b	2026-05-16 19:03:23.955502+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
17c7e4c4-9d21-4365-a53f-490019c6b65c	2026-05-16 19:03:24.054621+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
be4da6e4-5e95-4049-83e0-ae052b13c03b	2026-05-16 19:03:24.265963+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
5a8cbcd0-1a97-41c0-8a4a-6be27e28ce21	2026-05-16 19:03:24.278902+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (12ms)	\N	172.18.0.6	404	\N
ac5dace0-05e6-49d7-89d1-9b07b8d0a939	2026-05-16 19:03:25.585814+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (21ms)	\N	172.18.0.6	200	\N
5a9e3c81-b37a-4090-9b5f-5aca3b57f49c	2026-05-16 19:03:26.206478+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
a21621b0-ee07-4331-b5fe-a5a44d1ed18d	2026-05-16 19:06:54.148639+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
7c3ae149-c5b7-41f6-9aa8-b6a34f7cdfb1	2026-05-16 19:06:54.531185+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
9d330c11-664d-45c5-9383-f19b3e7393c1	2026-05-16 19:06:54.856756+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
97391f85-6194-40a8-9273-9086d32fc475	2026-05-16 19:06:54.984834+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
dbf3146d-c2da-4868-abfc-e68c84173501	2026-05-16 19:06:56.240946+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
f2583dba-47cd-4179-8794-db4ba8a49c19	2026-05-16 19:06:56.574222+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
8b741496-13ad-4025-b7b3-2f26a7189499	2026-05-16 19:08:33.337949+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
86d9471e-bacf-46d4-a4b6-eebc38533a8d	2026-05-16 19:08:33.421777+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
7db7b9bf-5eed-4867-abb5-202c1bfb24a6	2026-05-16 19:08:33.343008+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
c6420fe5-a729-4640-92a5-0fc7134ee785	2026-05-16 19:08:33.432237+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
73436e01-7e88-40eb-b9fa-886ba3021c12	2026-05-16 19:08:34.224136+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
14dec1c9-2b46-4075-a0d0-3d2a179d0689	2026-05-16 19:08:34.328417+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
cf731b53-cfe7-4a60-94b0-60418fa3ee67	2026-05-16 19:10:48.21367+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
7832b7b4-9db6-45ec-bae5-a47516d6f8f1	2026-05-16 19:10:48.255355+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
70989c63-12b7-4c36-a1c5-f9ef88c1c6e9	2026-05-16 19:10:48.258749+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
c2d5a34c-7633-4e33-b925-33cbded31812	2026-05-16 19:10:48.261303+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2417dcde-3d57-49c8-af8e-4e073d4f03c1	2026-05-16 19:10:49.858675+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (25ms)	\N	172.18.0.6	200	\N
15728aa2-179f-4187-9627-8785ab8c87bc	2026-05-16 19:10:49.857983+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (23ms)	\N	172.18.0.6	200	\N
d057e35a-8dcc-4f5f-909a-346dc43b691a	2026-05-16 19:10:52.248802+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
dddcfae6-5954-4c50-b88a-a32966267973	2026-05-16 19:10:52.323181+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2c9a0acb-9ef0-457d-8c28-e1b827624c36	2026-05-16 19:10:53.5301+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (10ms)	\N	172.18.0.6	200	\N
68e4041d-7870-40ea-8b3c-d9e188c0cab6	2026-05-16 19:10:55.977756+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
fd25ada2-7027-48ec-9628-c8b20bec01e1	2026-05-16 19:13:16.577682+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c373ebc6-38a5-4a7e-8df1-4ad5c8413445	2026-05-16 19:26:49.322659+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
eeab1645-758c-41d8-a445-5750fe2b42e2	2026-05-16 19:26:50.442375+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (16ms)	\N	172.18.0.6	200	\N
90fee6f4-099a-48b1-a7e0-b68c6d6a73da	2026-05-16 19:29:10.21072+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
5914032e-eaa2-4728-9302-c0387f02fa1c	2026-05-16 19:29:11.342007+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
716b2428-388a-4d10-b174-6c03b6cf0bc8	2026-05-16 19:30:54.729334+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
25ff9cfd-627a-42fb-a780-090586539fa8	2026-05-16 19:30:55.789026+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
2d59e7b9-c60b-4371-b3f9-d7a6bae1699e	2026-05-16 19:31:22.922956+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
bfd098e9-9476-4437-b538-5f1edfda4e4d	2026-05-16 19:10:54.80311+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
d3879da6-98f6-458d-8091-15f6f79b2013	2026-05-16 19:10:54.800362+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
adc95284-bc44-430d-aead-7f8105e48eff	2026-05-16 19:10:55.217329+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b52ea3e5-64ab-4237-bb25-49b961adadb9	2026-05-16 19:10:55.287631+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
0deca7ea-ef6c-4459-a459-d1219eeb7b62	2026-05-16 19:10:56.200827+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
1870e51e-713a-46a4-b6c7-65bd87b0ed5f	2026-05-16 19:13:16.578123+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
9eccafad-7a14-4c29-848b-e14c6b6baba1	2026-05-16 19:13:17.210315+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
3774c56a-a001-430c-b40e-07d7522b2973	2026-05-16 19:13:17.278248+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
a1537763-be5c-43b2-8d9d-b9693de5f9bf	2026-05-16 19:13:17.808462+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (14ms)	\N	172.18.0.6	200	\N
065d5e5f-a8e8-4bc3-94ea-6b01f5dbeca8	2026-05-16 19:13:18.423305+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (13ms)	\N	172.18.0.6	200	\N
160799d3-508c-427d-83e4-8133497e2e00	2026-05-16 19:26:49.323156+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
b9469e21-0570-43ac-9d04-ebd0bcb40ae0	2026-05-16 19:27:08.479111+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b3cb7aa0-e8cd-45f3-a770-3985d64e1632	2026-05-16 19:27:08.479693+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
7411591f-d506-4e61-9024-6ff710635f2f	2026-05-16 19:27:09.446316+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
efa8887a-ebf5-477c-b5bd-84aa41e7b2e7	2026-05-16 19:29:10.211283+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
5471f2d8-d7a0-4e72-8e55-6e427f0f15b0	2026-05-16 19:29:14.437712+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
bab7eb0d-40f8-4d23-b342-810d7b0f3394	2026-05-16 19:29:14.44102+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
efd077e8-1543-473c-bbae-3ed136b4e6f2	2026-05-16 19:29:15.492562+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
69dd193a-d60f-4e2a-85d8-f8491cf44d1a	2026-05-16 19:29:44.638394+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
c59641ad-1ccf-4a8a-83d4-1fbbbc731a9a	2026-05-16 19:29:44.639361+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c9dffa6c-238e-4bc7-8556-78bfb6dbfc47	2026-05-16 19:29:48.208697+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
5faf9aa5-047f-4513-86c7-8e47c10d81f5	2026-05-16 19:29:48.212006+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1914183a-fcfe-41cb-a758-0bb38edd6047	2026-05-16 19:29:49.472949+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
12e44d34-3061-4e1a-b423-51c052e52be5	2026-05-16 19:30:54.728952+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
d3449a71-af9c-41fe-8d06-0c52d6cff9ce	2026-05-16 19:31:21.870342+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
982ef29a-b45b-4fea-953e-2b30dba0cbd5	2026-05-16 19:31:21.869599+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
dfe7ae35-d0d1-4e7f-8a78-96e70b1814a1	2026-05-16 19:31:31.760865+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f5321671-6c91-4d78-b2d2-de3feb6d77e7	2026-05-16 19:31:31.76362+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
37e6f054-b090-4ed8-920b-47a8981554d2	2026-05-16 19:31:32.951956+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
f15d0c36-7a82-419e-843c-2faa7e4ce063	2026-05-16 19:32:52.362372+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
6620ee9b-1efb-4aa4-aec8-e9159d8c3f9b	2026-05-16 19:32:52.362861+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
3da6130e-80c4-4b19-a0fa-c4fd14299133	2026-05-16 19:32:53.366607+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
2c247e9c-0add-451e-9dbb-b414820c9118	2026-05-16 19:42:57.538508+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
71b1fc71-0650-47f0-99e5-097c34af85fc	2026-05-16 19:42:57.538039+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
429ff187-c6cb-4e4b-af18-3dcb7e53ef78	2026-05-16 19:42:58.536065+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
8a0b208c-c10d-44e0-be04-04b97797f43b	2026-05-16 19:43:02.843749+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1f3bb7e3-428b-4865-affe-07234e5da075	2026-05-16 19:43:02.840207+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
e5434893-d750-47b5-9d63-37943e4bf8e9	2026-05-16 19:43:04.029644+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
5bbe1ba5-9964-43d5-87df-efda00085b1a	2026-05-16 19:44:21.552087+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a16b6983-78fe-4678-ac7a-db5688333ef8	2026-05-16 19:44:21.552905+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
165cddbf-880a-4c7c-8484-30ee8764164e	2026-05-16 19:44:22.552228+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
bcf6f440-e79a-4abd-85f9-1390e6ac2cad	2026-05-16 19:44:26.305397+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
1359cf9c-e696-4b2a-accf-b9dffb3f8a37	2026-05-16 19:44:26.308061+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a67d32ce-67e7-465a-ad64-56618b3192d6	2026-05-16 19:44:27.463455+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
2f586dc0-a6d2-4026-9d7a-926430ebfb0c	2026-05-16 19:44:49.926364+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
f6088b92-ed87-462f-95fb-797ca84464cd	2026-05-16 19:44:49.926869+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
8d9bb64e-36df-4bde-abab-956754e4a0da	2026-05-16 19:44:50.943176+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
86fa4866-5104-4267-bd61-d88eaa11e20c	2026-05-16 19:44:57.395439+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
fad3f282-0911-4673-9cd2-e9b47c30a22f	2026-05-16 19:44:57.395669+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
da8c66c8-136a-4c53-8a67-b84a92a3c5fc	2026-05-16 19:44:58.597142+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
ac60d27c-094c-4624-bbd8-6be05751e69c	2026-05-16 20:07:02.040374+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
32f8e2df-2272-4114-824b-0d6b60aac0aa	2026-05-16 20:07:02.06354+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
1b489e91-42f6-47bb-8e9f-011260be3cb0	2026-05-16 20:07:03.02194+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b251f927-c7d8-4094-b6c9-779b7d77155e	2026-05-16 20:07:06.621806+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
5025d6ce-a8e2-40b7-9730-0d3975ad600a	2026-05-16 20:07:06.622112+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
b605266a-5cf9-4b83-8321-6c71a17d6209	2026-05-16 20:07:08.583017+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
2759915d-d349-48fe-bd23-9372f47060d4	2026-05-16 20:12:35.668865+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
93ca8a29-c9c3-41c3-81ec-38dc5aefae0b	2026-05-16 20:12:35.667484+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
c2c93d06-0457-48bc-8daf-e9ce4e7dfac3	2026-05-16 20:12:36.679684+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
f704981b-8e24-47ce-9e11-7a8591183a44	2026-05-16 20:13:32.397696+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
a73e61ac-a994-4c50-aea5-313f1d0a26af	2026-05-16 20:13:32.398549+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
7949fcde-56d9-48f2-afcb-414dc0547be2	2026-05-16 20:13:33.397953+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
5af62f75-8791-44e0-af22-9c34e2be6d25	2026-05-16 20:13:37.43732+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
405fa2eb-7627-41c0-8696-77e8794283d6	2026-05-16 20:13:37.441778+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
26aaacdf-7879-4e9b-bdb8-1efaaf18b691	2026-05-16 20:13:38.614779+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b2bcdded-980f-4bf4-b0d5-3c14eb1baf1a	2026-05-16 20:19:04.769678+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
974b7c0d-acd7-484f-872d-a578be00bc6a	2026-05-16 20:19:04.770372+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
80286a6f-7d61-468d-9884-55e2e08b9e9a	2026-05-16 20:19:05.853064+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
806cacf7-49c3-4d8f-b26b-6eff20a2995a	2026-05-16 20:19:09.79834+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
109825cf-865f-48c1-8d6f-59ddcf642789	2026-05-16 20:19:09.801078+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f91b7de9-237e-4881-b6e1-aff5f364bb3b	2026-05-16 20:19:10.99339+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
f1f43c85-1d0f-4074-885e-1e9e71d21e40	2026-05-16 20:19:15.214168+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
f9045781-8a18-4fab-a1bc-1a8dfb2b615d	2026-05-16 20:19:15.216461+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
13784653-538d-4a76-ae1d-2daee708b775	2026-05-16 20:19:16.411131+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
da64408e-b995-4994-803a-89c49d80e07d	2026-05-16 20:19:21.844204+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
faf30367-15bf-49f9-b67a-a7488ce8ba8e	2026-05-16 20:19:21.851044+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
e8b3f368-c46b-45fa-83e9-8bf147371780	2026-05-16 20:19:23.020159+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
896f2dae-2d6c-48a2-9cc3-711aab9c4ec1	2026-05-16 20:21:31.134569+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
84ccda2a-5c48-4399-b334-e54b681229ce	2026-05-16 20:21:31.135204+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
c5ed9a07-78c7-4fd3-b01d-f26bfed62c51	2026-05-16 20:21:32.148937+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
3602a9ad-4e5b-4856-a81c-58c61728db56	2026-05-16 20:22:25.293452+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
04c23c5f-27a1-47de-a5aa-2602f1aa3b5b	2026-05-16 20:22:25.293211+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
709561d1-fd2e-4930-8b6b-3b11d47ca39a	2026-05-16 20:22:26.301008+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
7e7d9363-720a-4217-b3c8-b467240588d5	2026-05-16 20:22:30.790633+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a4557d8d-7306-4aa1-8cb6-cfb8ca019204	2026-05-16 20:22:30.789648+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
a38076cf-2bc6-4b82-af3b-86261f065019	2026-05-16 20:22:31.972951+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
692afab7-197b-476f-bc92-87e86a1a75d3	2026-05-16 20:22:50.470205+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
0ee17bb3-65cb-4cd9-93d3-45428e130669	2026-05-16 20:22:50.470762+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
af76fcd6-4fdb-4c67-98fc-d50ea872ff49	2026-05-16 20:22:51.561013+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
06c09727-0a4f-4978-88a5-3308b9295672	2026-05-16 20:22:56.872874+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
6086216e-679c-4db5-a678-437a5e22ffaa	2026-05-16 20:22:56.873963+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
83eb145b-c5f7-4e37-93ae-ece8cd15d996	2026-05-16 20:22:58.067223+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b97192a0-e8ce-479e-8784-86d0f616b628	2026-05-16 20:24:12.322488+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
ef9945b9-3c29-4df4-acec-bbe5834e2edd	2026-05-16 20:24:12.321401+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (66ms)	\N	172.18.0.6	404	\N
8c89d1a4-66c2-4aca-8b38-f934bc4cd5e0	2026-05-16 20:24:13.374372+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
ec4c125b-aad4-424e-ab63-b40dd24b6b3c	2026-05-16 20:24:17.775628+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
97355f2e-31ef-4509-9d22-8d928c9b9443	2026-05-16 20:24:17.77877+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
4d43c0fb-7435-447f-b0d4-149265607a88	2026-05-16 20:24:18.969455+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b5432e0e-3530-4d6c-878a-93f156ef205d	2026-05-16 20:25:40.014427+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
49478a03-b0cf-47c1-b8d2-0a493f2acfc2	2026-05-16 20:25:40.013665+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
601c93cf-bac8-4936-9ffb-cf5fbabb1fbb	2026-05-16 20:25:41.014398+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
ca52a157-05a4-47b6-9530-afccdaf4b0cf	2026-05-16 20:25:45.983672+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
cabce917-c5d6-4c0b-beb5-b51213add9a7	2026-05-16 20:25:45.986995+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
51791860-2afc-4767-8e04-7802c4bd75a2	2026-05-16 20:25:47.185463+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
552e463d-6e64-4511-94d1-c9d1bd69897c	2026-05-16 20:26:30.799215+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
b8a9f231-3f84-4b20-9c9f-96d4b09ec5c3	2026-05-16 20:26:30.798013+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
cf2e203f-d6ba-49ba-a6e1-76ea770d0e5c	2026-05-16 20:26:31.860882+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
65b10061-afae-4526-b171-861d5445d25e	2026-05-16 20:26:37.734091+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
dffe629c-6405-43c8-845d-c3fea8641302	2026-05-16 20:26:37.731132+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b92b0026-8070-4c25-a695-9a08e8c88bb9	2026-05-16 20:26:38.928912+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
38902e37-5663-4db2-8ee0-5f645ab5d477	2026-05-16 20:27:28.132637+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e43b0c25-3fe7-41d1-8e41-1ef9d2714fac	2026-05-16 20:27:28.132216+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
92cbecde-978d-43dd-a10e-16054b96fc83	2026-05-16 20:27:29.139664+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
efeb0bfc-4a9c-48b8-a574-09175b2a7456	2026-05-16 20:27:34.951567+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
08e2fd38-7d25-479d-9d8f-822955db9477	2026-05-16 20:27:35.171789+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
635d995e-3aba-492d-a378-abdfbcf50344	2026-05-16 20:27:36.812165+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (20ms)	\N	172.18.0.6	200	\N
a5042c86-5a3c-469b-8eea-9d184d179726	2026-05-16 20:27:37.781402+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
80c8ca57-7006-4bd4-981a-916458495457	2026-05-16 20:27:37.812396+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
57882a72-1136-450f-8dbf-7c9b53bd65c3	2026-05-16 20:27:38.701415+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (12ms)	\N	172.18.0.6	200	\N
3c8d2e9c-cbab-4a04-b34f-5542063dc112	2026-05-16 20:31:29.497505+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
71589a5e-71cc-49c2-8581-ca0ec166cba2	2026-05-16 20:31:29.496974+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
7bad7831-6db1-48b4-9b86-036fd412c3f7	2026-05-16 20:31:30.495697+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b2074b41-86a5-4e81-9c02-cd6e6a1de07d	2026-05-16 20:31:34.99815+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
6fefbad2-4992-453f-b699-eb73c1f078b7	2026-05-16 20:31:35.001573+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
b8802439-de23-4a57-ab96-b064217c1860	2026-05-16 20:31:36.169518+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
cea8a983-910e-4d5c-8838-10757604f79f	2026-05-16 20:31:42.82752+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
95133f55-8a29-45f5-a1e7-2436ea64a92d	2026-05-16 20:31:42.828379+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a58dccb8-704d-4938-a77f-2386ba2cef88	2026-05-16 20:31:44.038834+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (12ms)	\N	172.18.0.6	200	\N
8f4dc5b7-acb4-499a-a7d4-e546436cbbed	2026-05-16 20:32:04.562814+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
8feb2ccc-9554-45f0-a6fb-6329074384db	2026-05-16 20:32:04.563278+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
df74799d-9663-40a0-b6e5-96ac0e04d423	2026-05-16 20:32:05.65531+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
8c42a7de-0c3f-4f5f-8951-f80d38e79093	2026-05-16 20:32:17.391732+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
7ef7d182-9edc-4083-aac7-e627c62d76c5	2026-05-16 20:32:17.392937+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
40a62b50-af49-4106-ab97-d51655fdff70	2026-05-16 20:32:18.551748+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
3cca9726-3e3b-401d-96ab-76e161dafc14	2026-05-16 20:34:22.915646+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
83c9520d-9512-4fbd-a716-60008af1cb9b	2026-05-16 20:34:22.916461+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
e3f89150-bf25-4839-aae0-424564ef52b8	2026-05-16 20:34:29.329989+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
bfa55e58-3400-413c-b9ab-a392d55a392e	2026-05-16 20:34:29.330584+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
59eb3356-1111-443f-b9a7-25307859490b	2026-05-16 20:34:34.086699+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
dbf21286-2013-48b4-aeed-7c58fe51c64e	2026-05-16 20:34:34.088482+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ba42f469-33b8-4e2e-965a-5599b1e1c1fc	2026-05-16 20:34:40.085038+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
690ed66f-7f5c-498f-8b56-549bf62a1229	2026-05-16 20:34:40.085786+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
3eb5e1c1-a2a4-41ce-8b08-d56665e4e9ea	2026-05-16 20:34:45.428939+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
28dc1a01-e16f-440f-987c-cda078c8f335	2026-05-16 20:34:45.428167+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
533531af-9272-40e9-848b-3ab680d4b59e	2026-05-16 20:34:46.331015+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
76c43fa5-1bbd-4b2b-bf2c-f6b672cf4aaf	2026-05-16 20:34:50.249343+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
53b6cdb1-2ef8-4bbf-bef7-e3935a073eeb	2026-05-16 20:34:50.250803+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
7c2d732b-9cab-4940-8e28-3c316b8d9ff8	2026-05-16 20:34:56.486711+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2d810347-6f7c-4d8f-92b9-a5ba24f7608d	2026-05-16 20:34:56.487175+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
1eeb1797-d6cf-4fb5-ab48-48582911fd2b	2026-05-16 20:35:01.635827+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
9518b418-da77-4e55-af7d-5051d0a7b65c	2026-05-16 20:35:01.637675+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
ed7ee167-42cd-47bd-ab3e-6df41585c4f5	2026-05-16 20:35:02.562426+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
aa2cad43-92f5-4bc6-8294-69e341b7505f	2026-05-16 20:38:17.897596+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
f4ce5bc4-208c-459e-99bf-bcf637e05325	2026-05-16 20:38:17.897153+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
7aacd3f5-e8be-48d4-933f-76f53034d172	2026-05-16 20:38:18.793654+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
b4a8c525-7f9d-4abc-94f8-15a76bf2006c	2026-05-16 20:38:28.050737+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ae3ebb11-44b3-46c3-a96f-8cfc22e259a7	2026-05-16 20:38:29.007095+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
0b515855-f209-4240-9bce-73ce9cd8dc6c	2026-05-16 20:38:34.434876+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ee48b869-96f9-4418-9f42-81a6d38049ce	2026-05-16 20:38:34.435356+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
537958d0-632e-4dfc-87e3-34d67a601811	2026-05-16 20:38:35.41856+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
0ca4c3e6-2c66-4ad3-af4d-6764114dfb24	2026-05-16 20:34:23.918987+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
1cdcde86-6b7e-4543-861d-e7f18d018311	2026-05-16 20:34:30.227437+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
9364ee85-7952-4bea-b647-c13d9a6e5e11	2026-05-16 20:34:35.049445+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
4f3c3ed0-f78c-4072-bfcc-a8eec764e81a	2026-05-16 20:34:40.984315+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
dc6b100c-9c05-475a-b881-8a7a58f8c1ae	2026-05-16 20:34:51.147749+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
70530e1b-33b2-45d5-b250-e2563615b825	2026-05-16 20:34:57.383658+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
51ce92c5-5e98-428e-8e5b-16e70f2577b2	2026-05-16 20:38:28.048581+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1cb22839-c368-42b8-979c-242bfaea76ca	2026-05-16 21:08:44.243136+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
8ebfeae2-5d87-44d6-afbe-5deedf3b6080	2026-05-16 21:08:44.24475+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
f105cb8f-d43e-4ef6-a52b-be1a63a82d3b	2026-05-16 21:08:45.162117+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
3655a0a9-8b92-4c14-8b48-1cbef18c7a3a	2026-05-16 21:10:19.337309+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b0b21c33-86c7-462a-9dcb-b2c30ba606cf	2026-05-16 21:10:19.338696+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ae816d60-58c6-4d4a-bcc2-1b102dbe2177	2026-05-16 21:10:20.329271+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
9349d46c-1754-40b1-b8d8-aa58e3ec77da	2026-05-16 21:11:00.877271+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
b38cd2b5-54f4-4d31-80fa-9b4ab0125d73	2026-05-16 21:11:00.876977+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
8651408d-ff5b-4d18-8738-e5ec64e9a692	2026-05-16 21:11:01.955838+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
c1d728f8-6d0f-44d4-95c2-049ad9671d4c	2026-05-16 21:12:32.892531+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
d3653ec6-a837-4b56-b729-cf6f7f3f64af	2026-05-16 21:12:32.891038+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
6cc2d618-263a-46d1-9a32-51b96acb1a13	2026-05-16 21:12:33.376541+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
d058ade0-3411-47dd-8d0d-bf0debd5379a	2026-05-16 21:12:35.005272+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (25ms)	\N	172.18.0.6	200	\N
bc24a952-a35a-4c7f-9bc3-b99d4b7be216	2026-05-16 21:12:35.401777+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
d3f780f9-bf3e-49f4-a855-a55b4a69062b	2026-05-16 21:12:50.345048+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (55ms)	\N	172.18.0.6	200	\N
382a4339-a23b-46fc-af8f-328b753d8f73	2026-05-16 21:12:50.698175+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
76d1b099-7401-424e-b868-f097a52d2e0e	2026-05-16 21:25:28.758951+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
979ac70a-4bd8-4ee2-a908-902dfac3e6bc	2026-05-16 21:25:28.757447+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
d571fcc5-6f3e-4464-9fab-a6ae5329ec6d	2026-05-16 21:25:29.274618+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
9e853e22-a6c0-417b-9d86-7dbe819c25df	2026-05-16 22:01:28.463838+00	WARNING	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Failed login attempt for user: admin@mtuci.ru	\N	172.18.0.6	\N	\N
2479a8bb-aa1c-4441-bace-7cc589addcb4	2026-05-16 22:01:28.465528+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (244ms)	\N	172.18.0.6	401	\N
6d8bc701-a625-4662-b8f2-7736a1bd6e57	2026-05-16 22:01:31.04528+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
0f47692b-baa5-4ea4-9dc4-cd41e57917a6	2026-05-16 22:01:31.108749+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (331ms)	\N	172.18.0.6	200	\N
6aa76ccd-1030-44e3-8a9f-2765e36329bb	2026-05-16 22:01:31.184397+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
c617e8a9-c0d6-49fb-8b5e-bb6252ed08d8	2026-05-16 22:01:31.396165+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
4bbf6cee-d273-462e-ad92-0ca01c641218	2026-05-16 22:05:59.42087+00	INFO	admin	\N	\N	\N	PATCH /admin/users/a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9 - 200 (98ms)	\N	172.18.0.6	200	\N
93c573d5-bab8-4159-ba6d-a9fcd83d2a45	2026-05-16 22:09:38.66867+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
f7b83d5b-a012-4ca4-b6b5-72f97a91e391	2026-05-16 22:09:38.88345+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
7ecae011-15a4-4bc1-beed-038212ef852f	2026-05-16 22:09:40.380679+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (139ms)	\N	172.18.0.6	200	\N
fd092801-5e01-4871-b42d-88b942c64291	2026-05-16 22:15:05.039829+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
dbd11c2b-3a5b-45b5-be12-bacc6d3f9135	2026-05-16 22:15:05.041012+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
2444bbf5-4363-43f0-a27e-0a11e0a1bef9	2026-05-16 22:15:06.388041+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (29ms)	\N	172.18.0.6	200	\N
07607a56-b6d2-4479-ae63-a09dc4a0841d	2026-05-16 22:23:49.511162+00	INFO	admin	\N	\N	\N	POST /admin/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/toggle-block - 200 (50ms)	\N	172.18.0.6	200	\N
ea0e4544-d3c9-4c66-9a3e-de39ccc4a294	2026-05-16 22:23:50.099878+00	INFO	admin	\N	\N	\N	POST /admin/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/toggle-block - 200 (34ms)	\N	172.18.0.6	200	\N
2bbfbd55-e1ef-4dfc-9c2b-24b528cdd44f	2026-05-16 22:23:50.609745+00	INFO	admin	\N	\N	\N	POST /admin/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/toggle-block - 200 (32ms)	\N	172.18.0.6	200	\N
fba6e50d-b3c6-4e53-b428-fda86ab176d6	2026-05-16 22:23:51.59984+00	INFO	admin	\N	\N	\N	POST /admin/repositories/efefd638-7f13-42c6-a75e-bafbcc312b07/toggle-block - 200 (30ms)	\N	172.18.0.6	200	\N
b938605b-6989-4151-9876-fc15f874f858	2026-05-20 23:57:56.425041+00	WARNING	admin	\N	\N	\N	GET /users/me/settings - 401 (104ms)	\N	172.18.0.6	401	\N
79950ba2-62a8-4d05-bc53-050bae8d3c3b	2026-05-20 23:57:56.427595+00	WARNING	admin	\N	\N	\N	GET /auth/me - 401 (3ms)	\N	172.18.0.6	401	\N
6bdd902b-34f5-4ab3-b72e-3f149b27fc41	2026-05-20 23:57:56.506869+00	WARNING	admin	\N	\N	\N	GET /users/me/settings - 401 (2ms)	\N	172.18.0.6	401	\N
7f5c2ea2-0b87-43ba-99f0-da137f0d1f71	2026-05-20 23:57:56.982915+00	WARNING	admin	\N	\N	\N	PATCH /users/me/settings - 401 (1ms)	\N	172.18.0.6	401	\N
e2216f95-a686-4781-95b3-dabc941846d8	2026-05-20 23:58:26.221353+00	WARNING	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Failed login attempt for user: admin@mtuci.ru	\N	172.18.0.6	\N	\N
41882f2f-c5d1-421e-8279-69410b1195d5	2026-05-20 23:58:26.222729+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (292ms)	\N	172.18.0.6	401	\N
31e63c3f-04ef-45b0-a2e2-7db416e608f1	2026-05-20 23:58:27.887343+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
4bd0fcca-939d-4362-97ab-869128e6faf6	2026-05-20 23:58:28.052526+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (424ms)	\N	172.18.0.6	200	\N
c7b35200-bf10-4382-ae9a-c9f68fe6a857	2026-05-20 23:58:28.130143+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
26f7eb82-f3bc-4079-b737-c13ef27ab281	2026-05-20 23:58:28.4282+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ceffaa7a-acf1-4a78-83c6-e1502ab95861	2026-05-20 23:59:57.706295+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (30ms)	\N	172.18.0.6	200	\N
548adb3d-aacf-44f4-84c5-223a29dae51a	2026-05-20 23:59:58.847823+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (49ms)	\N	172.18.0.6	200	\N
51634d81-7fb7-4230-af98-e52cfd8ec840	2026-05-21 00:05:23.467209+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (52ms)	\N	172.18.0.6	200	\N
90887c8d-3e3f-4974-bad3-e29dcd872093	2026-05-21 00:05:23.741689+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (32ms)	\N	172.18.0.6	200	\N
75860a72-0a1d-4728-84c9-b8e42c6bd06c	2026-05-21 00:05:24.149811+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (34ms)	\N	172.18.0.6	200	\N
3aa97eee-3ecd-4418-84bb-8a7f12b44b93	2026-05-21 00:05:24.174952+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (59ms)	\N	172.18.0.6	200	\N
ab8b1204-fc49-4d72-a2e7-68e1f57e7261	2026-05-21 00:05:27.091755+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (46ms)	\N	172.18.0.6	200	\N
75d83a3b-12d2-4bda-ae90-a14845467ba5	2026-05-21 00:05:27.11667+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (71ms)	\N	172.18.0.6	200	\N
ff728734-3f27-4cab-abe9-8de220ebd356	2026-05-21 00:07:27.604628+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (43ms)	\N	172.18.0.6	200	\N
93b93798-f980-45c1-aded-c31fb6343d8f	2026-05-21 00:07:28.220647+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (50ms)	\N	172.18.0.6	200	\N
821aa06e-30cd-41a7-93ae-dc7b9c4d14b2	2026-05-21 00:07:47.374393+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (76ms)	\N	172.18.0.6	404	\N
6aede3d1-549d-4cab-9953-adb72436cfb6	2026-05-21 00:07:57.461748+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (37ms)	\N	172.18.0.6	200	\N
9d7c0753-13f6-4e18-8003-71a9063609bf	2026-05-21 00:07:28.829805+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (48ms)	\N	172.18.0.6	200	\N
9396c6b0-4f1f-467e-8103-fdc9cfcf9e8d	2026-05-21 00:07:47.12129+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (434ms)	\N	172.18.0.6	200	\N
f9a357b2-65d8-4862-83f7-5151ed84c35d	2026-05-21 00:07:29.646159+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (75ms)	\N	172.18.0.6	200	\N
072e6d95-286f-4640-8056-4c8371b9ab0e	2026-05-21 00:09:39.029323+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (10ms)	\N	172.18.0.6	200	\N
93e496e6-6b83-458d-812e-404e472a9799	2026-05-21 00:09:49.735915+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
90deb2fc-a247-4d7c-8a82-e41940b2acb1	2026-05-21 00:11:15.926642+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (10ms)	\N	172.18.0.6	200	\N
f297de30-9b1c-46c8-98ca-f4d907cd98ec	2026-05-21 00:20:37.160133+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
112f3152-18a3-45a4-bb40-0752257a1845	2026-05-21 00:20:39.814254+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
20847224-6b4a-49a4-9209-6cf76c9da340	2026-05-21 00:22:04.134925+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (11ms)	\N	172.18.0.6	200	\N
9e714107-45c4-4b24-911b-4a4683cce786	2026-05-21 00:22:22.478254+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
4af0c53a-ce96-46e2-a2cf-854d3b49e2ed	2026-05-21 00:07:46.985451+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
e7f8ad1b-e1b7-402d-9064-eb73afc03381	2026-05-21 00:09:49.735485+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a13046a2-8274-405c-b10e-630b5470bd62	2026-05-21 00:11:16.16835+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (46ms)	\N	172.18.0.6	200	\N
17c2f246-e206-4627-9b6b-93638a58e324	2026-05-21 00:20:26.095774+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
b27f7fe7-5d0a-4d20-9d43-888f0813d701	2026-05-21 00:22:02.09212+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
820c0823-7e8c-4083-9b07-642b20d0cd9d	2026-05-21 00:22:24.180697+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
cd185414-e259-4495-aa7b-d0cdb59541ed	2026-05-21 00:07:47.372404+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (75ms)	\N	172.18.0.6	404	\N
5a06abcc-d59d-4abf-96d3-c9a16aa055be	2026-05-21 00:07:56.672357+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (8ms)	\N	172.18.0.6	404	\N
efa98a94-5e8e-4369-a66f-85109147b404	2026-05-21 00:07:56.669617+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (8ms)	\N	172.18.0.6	404	\N
1364f6dd-57a3-4523-9e35-7c427ece8a6b	2026-05-21 00:09:38.434298+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
49f1646d-8015-4d0c-ac98-3dc183804831	2026-05-21 00:09:38.437088+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
263106ca-87ee-4f57-9c77-7ab5834072cb	2026-05-21 00:09:50.286806+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (17ms)	\N	172.18.0.6	200	\N
1c85088c-4436-41e2-a4e9-8a01598df8f9	2026-05-21 00:11:15.493028+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (51ms)	\N	172.18.0.6	200	\N
bdab289d-9279-4452-999b-22c967d4bd12	2026-05-21 00:11:16.528454+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
802ed8f8-8d47-40e9-8fdc-5b9826d176c5	2026-05-21 00:20:25.074745+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1611101a-4a23-4b3c-bdcc-c8a6d5ddc4c0	2026-05-21 00:20:25.075816+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
9558bfd5-6141-4035-97b8-f9efac3cf718	2026-05-21 00:20:37.160449+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
c4bb2f03-2f3b-4c36-8576-95fb3739a481	2026-05-21 00:20:39.813855+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
2acea52e-2639-4cb7-b995-909676b7cc98	2026-05-21 00:22:02.093038+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
d5d7736c-2b45-4b70-952a-910424f14e58	2026-05-21 00:22:06.804893+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
2a90a7e7-c5f4-43ab-80e2-b0c7a90af429	2026-05-21 00:22:06.806035+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
a9b36890-9f4a-4933-aa8b-d26c9f75b58c	2026-05-21 00:22:08.103348+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
31d9c35a-fdf0-4d1f-bb8a-153207777a3b	2026-05-21 00:22:14.004429+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
9d8e5c3f-597c-4575-aa4e-1f7919089b1b	2026-05-21 00:22:14.006042+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
913f80ea-c78b-4327-bd1a-826eb1d114f9	2026-05-21 00:22:15.019647+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (17ms)	\N	172.18.0.6	200	\N
d44fa993-0341-4ec9-aa79-cc9169a83418	2026-05-21 00:22:17.846634+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2c5f2339-b5a3-4366-b370-95f66e08e97f	2026-05-21 00:22:17.849265+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
a6906a80-0468-44a1-a810-0a8fd558f5c5	2026-05-21 00:22:19.229805+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
d74c3756-f13f-4268-ade9-7366f49a7377	2026-05-21 00:22:21.326083+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
6c80cc2c-2a5e-4ae9-8c98-a1c671bfb39f	2026-05-21 00:22:21.32708+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
16fc6a6e-42e6-4645-9c1f-cfeee81782c0	2026-05-21 00:22:24.180351+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2e09ebec-8278-4f8e-b5a0-b8f2514c9178	2026-05-21 00:22:25.263677+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
af259ba6-1c11-4ff7-8732-80894da9e0f3	2026-05-21 00:23:50.151634+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (76ms)	\N	172.18.0.6	404	\N
6d28bb8b-de49-49dd-9c56-926dbdcc0ff9	2026-05-21 00:23:50.150884+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (77ms)	\N	172.18.0.6	404	\N
71f21ca9-147f-40ab-a7a2-75a6e9a3f372	2026-05-21 00:23:50.683397+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
791c1819-932d-477a-b11d-dae2433b0f49	2026-05-21 00:24:21.170206+00	INFO	admin	\N	\N	\N	PATCH /notifications/read-all - 204 (54ms)	\N	172.18.0.6	204	\N
2aa2d047-adfc-4c4b-82c7-b3e4f170a737	2026-05-21 00:24:25.900882+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (78ms)	\N	172.18.0.6	502	\N
cc651729-7fc5-41d0-a73a-27254174f4b4	2026-05-21 00:24:25.901385+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (76ms)	\N	172.18.0.6	502	\N
84cf541e-4e00-4e23-8bc1-001819f4617d	2026-05-21 00:24:46.422566+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (74ms)	\N	172.18.0.6	502	\N
227d178e-7994-4b7d-81f2-de8a4b39af14	2026-05-21 00:24:46.423597+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (73ms)	\N	172.18.0.6	502	\N
066a53a1-5e75-42e2-bdc3-f82925886883	2026-05-21 00:24:51.365474+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (78ms)	\N	172.18.0.6	502	\N
c23ecdb5-864a-4b26-afda-abf820ad1041	2026-05-21 00:24:51.373089+00	ERROR	admin	\N	\N	\N	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (87ms)	\N	172.18.0.6	502	\N
1894854f-f187-45fb-b2cc-959066c0f748	2026-05-21 00:30:38.965388+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
e9f5f340-489b-455f-8253-99c187e7fd3c	2026-05-21 00:30:38.964901+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ea644663-8f4e-427c-a357-812daeda9722	2026-05-21 00:32:24.19801+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
384cd6d0-4e78-47d0-ba1e-4911040eabb5	2026-05-21 00:32:24.198494+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
7d932c48-348c-4572-a364-02793a88a317	2026-05-21 00:32:25.579387+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
9ae1cc44-2cd4-46d6-84c9-02c7ff94e060	2026-05-21 00:32:29.639535+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
21c87d97-8c99-405b-afd3-136d4d9473ae	2026-05-21 00:32:29.640152+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
b7c2b2c6-698a-405f-86cf-d832b10dc428	2026-05-21 00:32:30.941275+00	INFO	admin	\N	\N	\N	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
dad8559a-eebb-4b37-9d8d-22137fd64fb9	2026-05-21 16:09:33.593887+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
1ed9c15a-8b02-4c0b-b18a-99ef3c7ccc1c	2026-05-21 16:09:34.2966+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (9ms)	\N	172.18.0.6	200	\N
89387096-ab52-40bf-b623-c3757ce5ad2c	2026-05-21 16:09:55.535909+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (73ms)	\N	172.18.0.6	502	\N
f851ef40-2c9e-4cd5-9c36-616b120dd078	2026-05-21 16:09:55.535509+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (74ms)	\N	172.18.0.6	502	\N
cc2c4177-5c64-405c-b3cd-46ff7ed0032e	2026-05-21 16:11:01.162438+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
92472d94-1d54-4d8a-b57d-289a0a3ed3ee	2026-05-21 16:42:49.264806+00	WARNING	admin	\N	\N	\N	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
557a17b6-1ecc-46a5-881f-efe920ab4e1c	2026-05-21 16:54:05.275284+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
50336da6-5f20-4df1-aa07-ffe4c83e2be3	2026-05-21 16:54:05.353506+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (383ms)	\N	172.18.0.6	200	\N
b4b7b7c2-37ef-4c21-8020-416c3d631c0f	2026-05-21 17:11:43.461684+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (46ms)	\N	172.18.0.6	200	\N
a3cb7797-5725-4e6d-8eb9-650a9dcb8868	2026-05-21 17:25:59.129542+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
6efc0cd8-b026-477e-b137-9453e4917644	2026-05-21 17:25:59.156643+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (298ms)	\N	172.18.0.6	200	\N
95989888-0741-4ae0-83c6-4b634d5f2f64	2026-05-21 17:30:39.580107+00	INFO	admin	\N	\N	\N	POST /auth/register - 201 (289ms)	\N	172.18.0.6	201	\N
999e5bd5-4c6b-4dee-b4c9-f0c197e0a46b	2026-05-21 17:30:45.431777+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (234ms)	\N	172.18.0.6	401	\N
ae14985c-dfe8-402b-99ec-6ab8625b42df	2026-05-21 17:30:49.054067+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (259ms)	\N	172.18.0.6	401	\N
7276396e-0c38-4d9e-b750-2a77bc3c7c6d	2026-05-21 17:30:50.611863+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (332ms)	\N	172.18.0.6	200	\N
7b15d9d8-ca0b-4164-96fc-29725c804267	2026-05-21 17:31:51.549313+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
b9b8c083-2615-4b30-b8e1-f3c4490b7cf9	2026-05-21 17:31:51.576382+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
2eb6b94a-c10a-4f32-af7c-d7449e2b2e2b	2026-05-21 17:31:51.592477+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (20583ms)	\N	172.18.0.6	200	\N
0c259352-768f-4b0f-8934-f340d2ef1f16	2026-05-21 17:31:51.615649+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (567ms)	\N	172.18.0.6	200	\N
1d1f2ba4-51da-43f3-a095-a72f9ed84360	2026-05-21 17:32:00.088724+00	WARNING	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Failed login attempt for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	\N	\N
bdd2761f-34ec-4142-9def-f388e8d2e5e1	2026-05-21 17:32:00.090185+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (228ms)	\N	172.18.0.6	401	\N
39b2c83c-437e-4edf-bba5-3fba9ca3615c	2026-05-21 17:32:02.460775+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
329ff222-7a1a-4419-bea8-8565b427ff93	2026-05-21 17:32:02.504411+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (356ms)	\N	172.18.0.6	200	\N
15c0bf2c-14d8-4efe-9c49-310b09e0ebcb	2026-05-21 17:11:43.495372+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (79ms)	\N	172.18.0.6	200	\N
2fecdf78-56e9-49b6-bb80-8abaa5c19615	2026-05-21 17:12:29.841721+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (16ms)	\N	172.18.0.6	200	\N
bee203c1-0a4f-4b21-b348-df3cb388cbf1	2026-05-21 18:13:17.237517+00	INFO	auth	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	Successful login for user: deylon.shevtsov@yandex.ru	\N	172.18.0.6	200	\N
0408c74c-86ea-4b58-a48f-3c3ec2aa7e16	2026-05-21 18:13:17.298928+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (346ms)	\N	172.18.0.6	200	\N
5ea7755b-773c-46d4-9755-d5e9add2c68e	2026-05-21 20:15:42.48341+00	INFO	admin	\N	\N	\N	POST /auth/register - 201 (274ms)	\N	172.18.0.6	201	\N
6f1dc84b-b747-4e9c-b78b-9851bc0ba356	2026-05-21 20:15:50.360582+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
4d38adfc-f363-4e15-8000-0c62e30d8c5f	2026-05-21 20:15:50.4216+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (401ms)	\N	172.18.0.6	200	\N
b46fb3ee-32db-4ec5-bbea-28b8e650b6ff	2026-05-21 20:16:09.018033+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Approved user: simonov@mtuci.ru	\N	172.18.0.6	200	\N
d7ebdc9e-e863-461c-a26a-8206af305fbf	2026-05-21 17:30:45.430306+00	WARNING	auth	\N	test@mail.ru	test	Failed login attempt for user: test@mail.ru	\N	172.18.0.6	\N	\N
bb06891e-118e-41b9-8667-eceb387b8085	2026-05-21 17:30:49.051451+00	WARNING	auth	\N	test@mail.ru	test	Failed login attempt for user: test@mail.ru	\N	172.18.0.6	\N	\N
0ed27757-f6bb-4d56-9bbd-8a44798c12fd	2026-05-21 17:30:50.562538+00	INFO	auth	\N	test@mail.ru	test	Successful login for user: test@mail.ru	\N	172.18.0.6	200	\N
898af8c6-fce4-48ce-a34f-4fd2f96a95f4	2026-05-21 20:16:25.674669+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Rejected pending user: test@mail.ru	\N	172.18.0.6	204	\N
a0e1978a-d09e-47c8-92cb-d8354cf69b10	2026-05-21 20:32:02.609486+00	INFO	auth	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	Successful login for user: simonov@mtuci.ru	\N	172.18.0.6	200	\N
8fec1de3-5b5a-45da-883c-ce5119f8468a	2026-05-21 20:32:02.644822+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (307ms)	\N	172.18.0.6	200	\N
52529a99-4fea-401f-ae87-9d32190f7c74	2026-05-24 09:39:21.423999+00	INFO	auth	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	Successful login for user: simonov@mtuci.ru	\N	172.18.0.6	200	\N
4f2b11c1-a220-4b0b-900b-0c276327da44	2026-05-24 09:39:21.773997+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (713ms)	\N	172.18.0.6	200	\N
0649e6c3-9fc6-44e8-b3ff-1fc35616e73d	2026-05-24 10:41:19.484984+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (38ms)	\N	172.18.0.6	200	\N
92a46236-2b1e-4b92-be67-34cbb6647fe2	2026-05-24 10:41:19.50918+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (61ms)	\N	172.18.0.6	200	\N
a371570a-80f9-41c1-a2e6-c938a8f3d344	2026-05-24 10:41:20.001002+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (31ms)	\N	172.18.0.6	200	\N
034ae0c4-1d5c-4663-9b56-056bd5875f04	2026-05-24 10:43:43.959981+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/profile-bundle - 403 (16ms)	\N	172.18.0.6	403	\N
be817e25-5452-4e6f-988f-417d81a08006	2026-05-24 11:14:19.338165+00	INFO	repositories	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	Created repository: lab1	\N	172.18.0.6	201	\N
6b2d9a17-714a-459e-944b-6c31abfb4c14	2026-05-24 11:26:42.321784+00	WARNING	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Failed login attempt for user: admin@mtuci.ru	\N	172.18.0.6	\N	\N
2caffdc5-2132-495e-805a-1b214c3e694c	2026-05-24 11:26:42.323475+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (236ms)	\N	172.18.0.6	401	\N
0758d12e-afab-466b-88c3-f3d3b54325d5	2026-05-24 11:26:43.638302+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
fe4350c6-c90f-48c1-99b2-807f7ddc0844	2026-05-24 11:26:43.6906+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (308ms)	\N	172.18.0.6	200	\N
f45a5b5e-998c-4d65-bf65-b1679828f85a	2026-05-24 12:06:18.907902+00	WARNING	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Repository created in DB but Gitea creation failed: my-lab-work	\N	172.18.0.6	\N	\N
04027a49-6073-4c5c-b522-e4187629e6d9	2026-05-24 12:06:18.907683+00	INFO	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Created repository: my-lab-work	\N	172.18.0.6	201	\N
52525d8e-d0f0-454f-afb7-52fe0c7808a8	2026-05-24 12:09:11.885569+00	WARNING	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Repository created in DB but Gitea creation failed: my-lab	\N	172.18.0.6	\N	\N
37dcc4aa-2af7-482a-96b5-380b12a91866	2026-05-24 12:06:18.932001+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 201 (208ms)	\N	172.18.0.6	201	\N
a3592cbb-8f8a-4819-98d6-2902e0fdbad2	2026-05-24 12:07:06.110045+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (41ms)	\N	172.18.0.6	200	\N
3e88d7b0-0a10-44f6-81ff-5c8d905c6ed7	2026-05-24 12:07:46.119999+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /notifications/read-all - 204 (100ms)	\N	172.18.0.6	204	\N
24b38f0e-0271-4ee8-8305-9fdd6ce72862	2026-05-24 12:09:11.885358+00	INFO	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Created repository: my-lab	\N	172.18.0.6	201	\N
004914ab-a7ea-4d1c-a38a-a6f27c5dd2e4	2026-05-24 12:27:52.655552+00	WARNING	admin	\N	\N	\N	POST /auth/login - 401 (253ms)	\N	172.18.0.6	401	\N
3eaffde8-53aa-45ad-b196-6e4e7f3004ed	2026-05-24 12:27:52.653088+00	WARNING	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Failed login attempt for user: admin@mtuci.ru	\N	172.18.0.6	\N	\N
5acfa076-7413-4bfc-bea8-0fa02c40b936	2026-05-24 12:27:53.82759+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
e71a7f33-2aa8-4ea3-8e1d-d28a66ed3d34	2026-05-24 12:27:53.882413+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (389ms)	\N	172.18.0.6	200	\N
abb03435-6e09-4de4-8096-1be0f812811d	2026-05-24 12:28:25.152306+00	WARNING	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Repository created in DB but Gitea creation failed: mylab	\N	172.18.0.6	\N	\N
f992abb7-c8b0-4534-a9d5-299609ebae3c	2026-05-24 12:28:25.152058+00	INFO	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Created repository: mylab	\N	172.18.0.6	201	\N
c4cf4206-4b4d-4b7d-a1e2-53351a327c71	2026-05-24 12:49:21.830413+00	INFO	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Created repository: mylab1111	\N	172.18.0.6	201	\N
1db9a742-1d59-43e6-ae3f-1892c91f7d0c	2026-05-24 12:59:04.005984+00	INFO	repositories	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Created repository: golinter	\N	172.18.0.6	201	\N
04fa3628-897a-4093-8a76-acc5c430f6db	2026-05-24 13:23:23.609186+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
56ee280d-a93f-4035-b903-4d5a948eaa28	2026-05-24 13:23:23.637317+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (350ms)	\N	172.18.0.6	200	\N
65317181-70ff-43be-a685-1b9274f17a6d	2026-05-24 13:31:24.086934+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
1f9b71c5-6579-473a-a744-0b439f49cb2e	2026-05-24 13:31:24.123008+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (323ms)	\N	172.18.0.6	200	\N
edb23ea1-2421-446e-aef6-6157ad44819a	2026-05-24 13:32:05.26693+00	INFO	auth	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	Successful login for user: admin@mtuci.ru	\N	172.18.0.6	200	\N
2de9e23e-9600-4680-a7c8-04e2e2597d56	2026-05-24 13:32:05.319405+00	INFO	admin	\N	\N	\N	POST /auth/login - 200 (328ms)	\N	172.18.0.6	200	\N
d0a644a2-4d20-44f6-86bb-97d07c9becc0	2026-05-21 00:35:58.908358+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
9bfadab4-7504-4993-9d10-ae207447300b	2026-05-21 00:35:58.909681+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2b7495b0-1257-4af2-9017-7738da03fd4e	2026-05-21 00:35:59.864007+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
98a9c71b-4ea8-4a0c-9788-0938f75a992e	2026-05-21 00:36:20.705149+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
35eb6ed9-533d-4411-aa62-8a1c7d20d9f0	2026-05-21 00:36:20.706783+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
0b433fac-3f09-4d3b-b501-f6965bac4800	2026-05-21 00:36:21.302359+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
ae30a538-9319-4536-9b1e-870472e3a996	2026-05-21 00:38:45.030296+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
3f79d5af-f50e-4e1c-a5ed-e336150f1b48	2026-05-21 00:38:45.030559+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
cc4b20c8-695d-4227-afb7-ff8c0441c80b	2026-05-21 00:38:54.648759+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2955bd40-9442-499e-83a1-62b5034e9d8f	2026-05-21 00:38:55.303289+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
af5690de-6595-488a-bce5-856ecfed75fa	2026-05-21 00:38:56.687722+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
41e5656f-b1b0-4fc3-8c44-dc80d22cc307	2026-05-21 00:42:46.537012+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
276b0d49-796f-4241-9ef8-1e31ea9b4e38	2026-05-21 00:42:46.55186+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (10ms)	\N	172.18.0.6	404	\N
90fec64d-965d-40c7-a8d2-87ce9a3ae222	2026-05-21 00:42:47.077955+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (17ms)	\N	172.18.0.6	200	\N
02c44b18-8594-433f-81f9-83afbccc6865	2026-05-21 16:09:33.59225+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
2e0183eb-31f3-4d11-aa2a-b606508ce536	2026-05-21 16:10:18.075587+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
6ef9911f-820b-4daa-bdb7-3537c2a4a5ac	2026-05-21 16:10:18.076287+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
e3342da0-aed5-4dfb-8e1d-f7818904adcc	2026-05-21 16:10:18.668017+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (26ms)	\N	172.18.0.6	200	\N
67ec9e6f-b96a-444f-b85c-165a7cc1c033	2026-05-21 16:11:01.156667+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (1ms)	\N	172.18.0.6	404	\N
57ee8b7b-1bf0-4180-9fb7-bd06a03806b3	2026-05-21 16:11:01.823021+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (25ms)	\N	172.18.0.6	200	\N
66ffc4df-be37-4eea-abd8-5f96f929f846	2026-05-21 16:15:51.873904+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (75ms)	\N	172.18.0.6	502	\N
30906cf7-aca5-4360-88e3-dcc38838415e	2026-05-21 16:15:51.872935+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (73ms)	\N	172.18.0.6	502	\N
0727e2f0-978f-4f18-ac13-764951ea4973	2026-05-21 16:17:27.523545+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (82ms)	\N	172.18.0.6	502	\N
027a0817-8c54-4f87-b096-e317b0579a4f	2026-05-21 16:17:27.525158+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (82ms)	\N	172.18.0.6	502	\N
a101f8a1-a1db-4eb6-b7e1-da53ab1bb59a	2026-05-21 16:22:40.394205+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
127323f3-2092-4c66-8f4c-16d29d6b097a	2026-05-21 16:22:40.393144+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
9ae4d4cf-d32a-433a-a322-97965d3c9d55	2026-05-21 16:30:38.730542+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
fc7db45e-c129-47cf-b837-c9b8ceaa11c6	2026-05-21 16:30:38.729252+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
ae0fc3c4-37e6-4603-b319-f283a1cf16db	2026-05-21 16:30:39.517232+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (52ms)	\N	172.18.0.6	200	\N
d7b7eeb8-f2e1-4cee-9eb1-0817b48add2b	2026-05-21 16:32:39.117787+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
55fdc567-81fd-415b-9c2c-0543292b93df	2026-05-21 16:32:39.122382+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
ea8f1357-4a2c-4b15-93c1-9da2ad760e4b	2026-05-21 16:32:39.768174+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (24ms)	\N	172.18.0.6	200	\N
7d35412c-770f-41d8-9b45-308b9d3aa3b8	2026-05-21 16:33:26.123754+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (6ms)	\N	172.18.0.6	404	\N
44bda518-d3b0-4993-8b1b-40599f274e10	2026-05-21 16:33:26.124301+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
beae1e10-3395-4240-8be0-0dda1272f2fa	2026-05-21 16:33:26.917696+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (27ms)	\N	172.18.0.6	200	\N
956e1ac1-2ad5-4c9f-b07e-367b5fe43120	2026-05-21 16:33:31.069783+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
76370166-498b-4f1d-89d6-f74c61189b99	2026-05-21 16:33:31.069354+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
7d395f29-1a32-463f-8961-0b5a22f1ad77	2026-05-21 16:33:31.981847+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (12ms)	\N	172.18.0.6	200	\N
1cbdaaa3-71a3-49a5-943c-2f952b59b1b5	2026-05-21 16:33:34.246669+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
ccf55122-1d9b-43aa-8707-77c44fe05980	2026-05-21 16:33:34.247292+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (5ms)	\N	172.18.0.6	404	\N
7cba8810-dc09-4204-9215-2f8dcfd6773d	2026-05-21 16:33:35.244071+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (25ms)	\N	172.18.0.6	200	\N
084e6e2d-648f-4fef-80a6-520bf7547069	2026-05-21 16:37:29.003236+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
07d697a4-37f0-4c04-b35c-06b5ee3370b2	2026-05-21 16:37:29.004131+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
e2b0fff2-7836-41c4-a81e-e5b4272bfcef	2026-05-24 11:31:46.369223+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (30ms)	\N	172.18.0.6	200	\N
d71a765b-aa39-4a8e-9ebe-9c18c8ec68b7	2026-05-21 16:37:29.656271+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (40ms)	\N	172.18.0.6	200	\N
79eaedf8-a829-4117-8898-25d967136e34	2026-05-21 16:41:49.56736+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
c5047dbb-62dd-4d56-aaf2-f292bc6c17c2	2026-05-21 16:41:49.566751+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
56c1f032-0343-404c-b1e4-6194d29e57c6	2026-05-21 16:41:50.442029+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (43ms)	\N	172.18.0.6	200	\N
69a66e41-ad99-45fd-8674-7e33ef60fcfe	2026-05-21 16:42:02.575847+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (4ms)	\N	172.18.0.6	404	\N
2e7bd7b5-d5fe-4dcf-87d0-f2ea48d72e00	2026-05-21 16:42:02.577579+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (2ms)	\N	172.18.0.6	404	\N
84bb5957-f073-4850-a6dd-2a83d529fe61	2026-05-21 16:42:03.584022+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
a5d7dc7f-eb03-494d-972b-5328ac3143ac	2026-05-21 16:42:06.84304+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
bf6241bb-84b5-46ac-8a18-ea3555f08b08	2026-05-21 16:42:06.843613+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /system/info - 404 (3ms)	\N	172.18.0.6	404	\N
c6f2fffc-d7d2-4dbd-adf5-d24ab24a0e15	2026-05-21 16:53:42.251113+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (11ms)	\N	172.18.0.6	200	\N
f04ec5b0-4b7c-46c0-9789-f1ffd9373efa	2026-05-21 17:07:18.090058+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
c19ed755-b5ed-43cd-9134-1ab706506e6c	2026-05-21 17:08:02.62101+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
2f5ada0b-16b5-4e89-9798-7cdc23cc8902	2026-05-21 17:08:15.323381+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (56ms)	\N	172.18.0.6	200	\N
3a3d16a6-5563-4559-829b-770acb71386b	2026-05-21 17:11:39.161928+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (41ms)	\N	172.18.0.6	200	\N
d1339173-4681-4638-9dfc-72af2fc7c59a	2026-05-21 17:11:39.55398+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (52ms)	\N	172.18.0.6	200	\N
8eccde13-b9ef-4442-b4c5-5ce89335cfd6	2026-05-21 17:11:39.587381+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (79ms)	\N	172.18.0.6	200	\N
56138fef-0b59-47d2-bfc4-e3ae4960fa48	2026-05-21 17:11:40.7623+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (38ms)	\N	172.18.0.6	200	\N
4885323c-4f74-43be-9aee-6e606c50a1a7	2026-05-21 17:11:40.794913+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (70ms)	\N	172.18.0.6	200	\N
bbd149e7-7c02-4646-8965-c191b13bc4f1	2026-05-21 17:11:42.146077+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (48ms)	\N	172.18.0.6	200	\N
0a162f09-8383-48b9-a823-584e83374daf	2026-05-21 17:11:42.179194+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (82ms)	\N	172.18.0.6	200	\N
0094cd22-363d-4b9e-a329-6e04e0d2763c	2026-05-21 17:11:42.63683+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (40ms)	\N	172.18.0.6	200	\N
66eb9f0e-cc29-421d-a39d-0b9c629ae3f9	2026-05-21 17:11:42.670639+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (73ms)	\N	172.18.0.6	200	\N
88136a71-0931-42f7-9d9f-8736260043cd	2026-05-21 17:11:43.162186+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (46ms)	\N	172.18.0.6	200	\N
0db05a5a-54e7-4cce-ac82-03b22a7fb61d	2026-05-21 17:11:43.211455+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (95ms)	\N	172.18.0.6	200	\N
93bac247-43ac-499a-9520-f60341bdbeec	2026-05-21 17:22:29.334942+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
82636569-6e55-4f40-ab5c-0a750eb3d762	2026-05-21 17:23:27.699965+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (88ms)	\N	172.18.0.6	200	\N
c0aa7ef3-f219-48e5-8627-318eb9112dad	2026-05-21 17:24:46.031015+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/commits - 502 (71ms)	\N	172.18.0.6	502	\N
5a09f4a5-6378-47ce-8653-fca3a897fcaf	2026-05-21 17:24:46.030432+00	ERROR	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /courses/323ba9d7-4ec2-4ba0-b5bb-ba16e0dec1e5/assignments/992c906f-c134-4a63-a702-a9cbd93a0181/files - 502 (69ms)	\N	172.18.0.6	502	\N
384a0b9f-ddd3-472a-918d-46583e35e94e	2026-05-21 17:25:38.752357+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
81c35077-433c-4c12-9490-5debdb5a3514	2026-05-21 17:32:32.324622+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
957bd493-57c6-488a-8492-ce6bb4f16a34	2026-05-21 17:34:19.553338+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
c04a74a4-21f6-4f38-8294-f559cf4f449a	2026-05-21 17:49:44.762238+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
508ec274-7b45-49ef-beec-25be90723fe3	2026-05-21 17:50:01.535594+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /students/me/dashboard-bundle - 404 (1ms)	\N	172.18.0.6	404	\N
99f587ab-0842-42ba-9839-b9c981b4e8e3	2026-05-21 17:50:16.215082+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /students/me/dashboard-bundle - 404 (5ms)	\N	172.18.0.6	404	\N
c45a5ecf-ac71-4f8f-8166-44493eecd7f5	2026-05-21 17:50:17.272537+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
49c3ce1a-443c-41f8-b1ee-0b18916fb4ae	2026-05-21 17:51:37.947752+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /students/me/dashboard-bundle - 404 (2ms)	\N	172.18.0.6	404	\N
42b6a6a6-f8ba-41dd-8416-f271fb1c1a87	2026-05-21 17:51:38.909151+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
a701b67a-5159-4181-aba7-b2ab2129888c	2026-05-24 12:38:19.426205+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (154ms)	\N	172.18.0.6	502	\N
e4301c0f-cf0d-4a6d-8981-ead4eb2b282e	2026-05-21 17:51:45.077659+00	WARNING	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	GET /students/me/dashboard-bundle - 404 (4ms)	\N	172.18.0.6	404	\N
fbf321ac-cca3-4c07-a150-b6d4f3fe3646	2026-05-21 17:51:46.079126+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
1706577c-3d93-40ba-ab33-56fd8d5ac012	2026-05-21 17:56:28.009964+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (14ms)	\N	172.18.0.6	200	\N
7272d4d1-8d2a-4df4-a56e-8f42c2a37939	2026-05-21 17:56:33.259765+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
605f6469-2571-43ba-918a-3b31ea3b1d9e	2026-05-21 17:56:39.58984+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
edd349b7-6eff-4ef1-afb5-9f1211b45d59	2026-05-21 17:57:01.921065+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
f629cda9-bc42-46d0-a5b6-15ea1a45da48	2026-05-21 17:58:27.04381+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
2b1c95cf-b336-443b-9d60-4cd4f2f9f956	2026-05-21 17:58:35.543506+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
fb41465e-57a5-4f57-b492-7ac9d16b911d	2026-05-21 17:58:49.065641+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
544eaa64-3c05-4276-a5ab-97abf86c913f	2026-05-21 17:59:40.248134+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (11ms)	\N	172.18.0.6	200	\N
2fb757be-eef7-400f-9f22-c97c7f226b4e	2026-05-21 18:00:12.095567+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
a1f41cce-bdb8-40b8-be63-41541a7ee311	2026-05-21 18:01:20.370389+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
f51d32b5-7880-401d-9ffa-66140969315b	2026-05-21 18:01:52.61105+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
6c8fa661-1b07-4c8a-a59b-b39606a7267b	2026-05-21 18:03:23.884192+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
151031e7-e349-485a-91fe-91281aba73a5	2026-05-21 18:03:29.592026+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
48175b87-df27-4568-98d8-0342f068bf4b	2026-05-21 18:05:16.33316+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
9057b2e3-3229-4c68-aa8e-64605446bf0d	2026-05-21 18:05:20.942197+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
7810e712-33b3-48ae-9280-c00d2f8c5852	2026-05-21 18:06:10.902742+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
82124a84-3fb6-45a9-aa9f-c52ca424d0ad	2026-05-21 18:06:20.94163+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
d72f31d6-830e-4382-a950-1e2e6bbb0636	2026-05-21 18:06:24.207739+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
daa72d96-36d2-4816-87a8-b0e7a688943a	2026-05-21 18:06:32.516057+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
e0de4b4b-4932-4c3a-a597-c767dd85c949	2026-05-21 18:08:03.520238+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
769ede98-8d91-41fb-8ece-426c9af0df7d	2026-05-21 18:12:49.082868+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
f0a7e7eb-0831-4aa9-afc4-eb402e45cfa8	2026-05-21 18:14:16.145321+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
388170ca-f04e-45f6-9f10-957eaa1ef188	2026-05-21 18:14:39.521813+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
5db77753-bcec-4733-9396-3b6bb1a65565	2026-05-21 18:14:56.461456+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
f31cd6a3-3082-4c88-8c83-fd0ad08f1093	2026-05-21 18:15:04.149654+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
d3b9b1b6-5d82-45ed-a6f0-48fe1a07be04	2026-05-21 18:15:10.593302+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
1cd53152-3e09-4548-bf71-698514655558	2026-05-21 18:16:33.766531+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (12ms)	\N	172.18.0.6	200	\N
efdc6c22-d1f7-4235-8942-8c23ce829d9e	2026-05-21 18:17:18.026401+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (9ms)	\N	172.18.0.6	200	\N
8fe6bf08-f424-4cbe-9aff-c4d85fc69453	2026-05-21 18:17:23.549776+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
9f038d63-7de5-4a64-9795-d63847e3d413	2026-05-21 18:17:37.247966+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
37b4c5ef-7290-4dcc-a884-bc89fcd6779d	2026-05-21 18:18:22.823992+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
f15a1d29-708e-459c-a9e5-6053fff2192c	2026-05-21 18:18:26.12742+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (7ms)	\N	172.18.0.6	200	\N
ef9f1b7d-82f2-4e89-a17b-97ad86077a13	2026-05-21 18:18:30.029853+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (9ms)	\N	172.18.0.6	200	\N
c7ce0afb-dd0e-46db-b49b-5c111ce9e381	2026-05-21 18:18:34.102572+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
964b322e-a3c2-460b-a913-d1b52681108e	2026-05-21 18:18:39.901061+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
2a155366-82a5-4834-bbac-ee90abf371e9	2026-05-21 18:18:42.911076+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
2db43810-6e95-4149-8108-27d85ad8d7fe	2026-05-21 18:18:46.820119+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
4b11d299-a67b-4ddc-8f79-e21e0fafc322	2026-05-21 18:22:47.599315+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (8ms)	\N	172.18.0.6	200	\N
9930965c-1450-46af-b760-9e10ff1ddbce	2026-05-21 18:23:06.134916+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (5ms)	\N	172.18.0.6	200	\N
bd4c7e8d-2390-4d68-8b25-688803230421	2026-05-21 18:26:28.333235+00	INFO	admin	a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	Лашков Юрий Евгеньевич	PATCH /users/me/settings - 200 (6ms)	\N	172.18.0.6	200	\N
a605217f-fd86-4f1c-8490-0f9a83e3aa5d	2026-05-21 20:16:09.020548+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8/approve - 200 (40ms)	\N	172.18.0.6	200	\N
2ea79725-fcf5-4f7e-8909-722a5b9eff95	2026-05-21 20:16:25.675879+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/users/1304d1b5-d0c7-4a6c-ad0d-4ecda116c349/reject - 204 (70ms)	\N	172.18.0.6	204	\N
64d726ae-5921-4207-86c6-7d2f0daa58aa	2026-05-21 20:16:37.058767+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (36ms)	\N	172.18.0.6	200	\N
4e228207-2da6-4070-a959-85aa694f9ab5	2026-05-21 20:32:02.685649+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
7689ae4f-781d-4194-8319-eb9ab1c68057	2026-05-21 20:32:13.419968+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/profile-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
4e09297e-7eef-45e6-896d-195b62a4ba7a	2026-05-21 20:52:31.433751+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /courses - 201 (63ms)	\N	172.18.0.6	201	\N
17cd12db-fde6-4249-9401-6caa9570d825	2026-05-21 20:53:40.95772+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/enroll-by-group - 201 (54ms)	\N	172.18.0.6	201	\N
80835e9f-5385-41f1-876b-25613c4df59e	2026-05-21 20:54:51.823314+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/assignments - 400 (7ms)	\N	172.18.0.6	400	\N
c02dea45-2410-4b9a-b759-37fb45b02cfc	2026-05-21 20:55:48.464151+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/assignments - 201 (21722ms)	\N	172.18.0.6	201	\N
cecfe2ee-eecf-4e1d-8c57-4ee995472179	2026-05-21 20:55:52.455612+00	ERROR	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/assignments/153d8c9f-9657-4b6e-8910-415741df819e/commits - 502 (83ms)	\N	172.18.0.6	502	\N
a847dd58-9c64-46df-90f0-0949ef90034d	2026-05-21 20:55:52.456555+00	ERROR	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be/assignments/153d8c9f-9657-4b6e-8910-415741df819e/files - 502 (86ms)	\N	172.18.0.6	502	\N
7cc930c8-98d6-41fe-ba7c-a2f5205c0ebf	2026-05-21 21:07:39.532573+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	DELETE /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be - 403 (3ms)	\N	172.18.0.6	403	\N
5140f5a1-6b5f-45dc-8ad9-6c2f01962f47	2026-05-21 21:08:00.345239+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /courses - 201 (80ms)	\N	172.18.0.6	201	\N
4c937418-104d-4b67-9b49-f8173d82b68a	2026-05-21 21:10:08.992458+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/profile-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
38fdc79d-ccab-401f-b425-3d6414956592	2026-05-21 21:10:11.48064+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (17ms)	\N	172.18.0.6	403	\N
2c4269c6-85f2-41e4-9ee9-99648b1b667c	2026-05-24 09:39:21.8972+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (6ms)	\N	172.18.0.6	403	\N
fe00ac4e-6281-4044-baec-7f47709e57f9	2026-05-24 10:40:47.903171+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (7ms)	\N	172.18.0.6	403	\N
1cb02139-059a-4edd-bcb7-c3ff9873b403	2026-05-24 10:41:18.711755+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (80ms)	\N	172.18.0.6	200	\N
20ed3845-729f-442d-b949-01b905f252d3	2026-05-24 10:41:19.058779+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (32ms)	\N	172.18.0.6	200	\N
89e43ee0-63a1-4f29-a662-879891605f52	2026-05-24 10:41:20.026212+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	PATCH /users/me/settings - 200 (56ms)	\N	172.18.0.6	200	\N
f47c697e-9811-449f-85f8-da53f72e94c4	2026-05-24 10:41:21.677526+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/profile-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
e87d42ef-7a60-41c5-a234-57a92807c4e4	2026-05-24 10:41:31.586414+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (6ms)	\N	172.18.0.6	403	\N
d14eb517-bf50-47ec-afcc-61e821232084	2026-05-24 10:42:15.812224+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	DELETE /courses/4d3aa91c-2c55-4378-8e3b-c9b114024344 - 403 (3ms)	\N	172.18.0.6	403	\N
729bdd38-c349-4760-a2ba-2504edd05619	2026-05-24 10:42:17.526416+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	DELETE /courses/930bee0d-1c21-4057-8cba-10fa9bbe63be - 403 (3ms)	\N	172.18.0.6	403	\N
040dc912-6e9a-45f6-9e6f-874818845c7a	2026-05-24 10:44:23.861005+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
54b15986-b5fb-4fef-8ddf-1edb8b195a2b	2026-05-24 10:54:17.979055+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
af19a025-3040-47a1-a918-cc69688438c3	2026-05-24 10:54:21.469803+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (9ms)	\N	172.18.0.6	403	\N
f7c08dad-3431-4ec1-8f98-622ae37e031b	2026-05-24 10:54:26.140663+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
949a587f-fe0c-43dd-883c-e9fcc33fd7d3	2026-05-24 10:54:36.636869+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
e03e2ab2-93bb-4587-9f5a-f12e1eb42beb	2026-05-24 10:54:56.104076+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
0b61cdb9-af56-4c24-8c2c-2b4eb4092e2a	2026-05-24 10:54:59.998946+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (5ms)	\N	172.18.0.6	403	\N
f93bfb99-7550-49b7-9cc2-4ca4cd6ca29f	2026-05-24 10:55:04.31877+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
07ca981d-d5a8-4ddd-a1a8-4962acd36e93	2026-05-24 10:55:11.164214+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
d7902238-cfdb-4faa-8d27-7bcd5995651f	2026-05-24 10:55:33.252276+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (4ms)	\N	172.18.0.6	403	\N
a26d5873-d120-4c0a-99ca-9f40f657eaf7	2026-05-24 10:55:41.118031+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (3ms)	\N	172.18.0.6	403	\N
cc04195e-8926-458c-bde6-65e221fbef0d	2026-05-24 10:59:38.070376+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (5ms)	\N	172.18.0.6	403	\N
3bf5fb13-02d0-4102-829f-a0f4d88ec5be	2026-05-24 11:12:52.829425+00	WARNING	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	GET /students/me/dashboard-bundle - 403 (7ms)	\N	172.18.0.6	403	\N
3044af68-6dc7-40bf-a3ba-8011b2fe33b3	2026-05-24 11:14:19.366185+00	INFO	admin	0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	simonov	POST /repositories/ - 201 (3029ms)	\N	172.18.0.6	201	\N
8a49cf8d-cc9c-4ce5-92ef-3498f27b8047	2026-05-24 11:31:45.185757+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (32ms)	\N	172.18.0.6	200	\N
fa0d9b09-b233-4bde-93e6-b67ec14309cd	2026-05-24 11:31:46.719327+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (34ms)	\N	172.18.0.6	200	\N
585ee894-94fb-43da-aa45-4b0f96d76e35	2026-05-24 11:31:46.744576+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (59ms)	\N	172.18.0.6	200	\N
e33935c2-8a17-4b28-97e0-5fa942caf5ca	2026-05-24 11:31:47.594712+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (32ms)	\N	172.18.0.6	200	\N
50463197-a625-48a9-8a8a-895344f77e4f	2026-05-24 11:31:47.619276+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (56ms)	\N	172.18.0.6	200	\N
e18b8a04-e00e-4f42-bef7-f70855d342d0	2026-05-24 11:50:04.703474+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (33ms)	\N	172.18.0.6	200	\N
a2a0c6a9-f340-4f09-aae8-15744046c44f	2026-05-24 11:50:05.802853+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (30ms)	\N	172.18.0.6	200	\N
cb5f086c-9570-490e-aaf0-cea78f482230	2026-05-24 11:50:06.202335+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (37ms)	\N	172.18.0.6	200	\N
9bf8007b-6b23-4251-b6eb-04ffd3f01cd5	2026-05-24 11:50:06.227502+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (60ms)	\N	172.18.0.6	200	\N
1afde8bd-34ce-479b-9a1a-2d84dd2cf5a2	2026-05-24 11:50:06.702433+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (33ms)	\N	172.18.0.6	200	\N
f8c96541-543c-4c3e-9425-1021d261705a	2026-05-24 11:50:06.727613+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (57ms)	\N	172.18.0.6	200	\N
a67ad5c9-1a31-4c2d-a869-ea148d3f7e09	2026-05-24 11:50:07.384935+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (29ms)	\N	172.18.0.6	200	\N
d4bb7739-23bb-4478-9a07-a0663442f127	2026-05-24 11:50:07.410787+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (55ms)	\N	172.18.0.6	200	\N
579fd222-1fe8-4ef5-8928-064aa13fd398	2026-05-24 11:50:07.793275+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (28ms)	\N	172.18.0.6	200	\N
995780d2-7ad7-43a3-8165-54d8a913a2f5	2026-05-24 11:50:07.819003+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (53ms)	\N	172.18.0.6	200	\N
d16428a4-385b-4ce9-b468-f2daa8375721	2026-05-24 11:50:08.385328+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (31ms)	\N	172.18.0.6	200	\N
4dc9294a-7c17-446f-a5b6-75d1b67f7cc8	2026-05-24 11:50:08.410512+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (55ms)	\N	172.18.0.6	200	\N
2cabaf55-dcda-49c8-8906-9194bd0bf1be	2026-05-24 11:50:09.028494+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (40ms)	\N	172.18.0.6	200	\N
418780ae-f5c0-4cc4-a455-138d4663bd19	2026-05-24 11:50:09.052266+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (65ms)	\N	172.18.0.6	200	\N
5cbf70c2-4d62-46a5-9024-c4c9417cb392	2026-05-24 11:50:09.619424+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (30ms)	\N	172.18.0.6	200	\N
8d08eb02-6265-4a0b-9bc0-4d3148800f8c	2026-05-24 11:50:09.655068+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (65ms)	\N	172.18.0.6	200	\N
dbcdc82f-b486-4f3a-887a-7e1c06fb189d	2026-05-24 11:50:10.227238+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (60ms)	\N	172.18.0.6	200	\N
365d148e-aea4-45f7-87ec-f24c3f42eb45	2026-05-24 11:50:10.285155+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /users/me/settings - 200 (117ms)	\N	172.18.0.6	200	\N
5b5dba1b-1501-46e8-95d5-791e0c2be3c7	2026-05-24 11:52:01.566071+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (101ms)	\N	172.18.0.6	200	\N
e0321693-65ad-4d4f-8ead-28962392894e	2026-05-24 11:52:02.326028+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (36ms)	\N	172.18.0.6	200	\N
7e965675-099d-45ca-bdcf-8c46eaeea328	2026-05-24 11:52:02.797696+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (36ms)	\N	172.18.0.6	200	\N
44481789-a436-4895-99c1-661060c9593d	2026-05-24 11:52:03.191963+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (30ms)	\N	172.18.0.6	200	\N
75e7b6b4-8f40-4967-b12e-f8e170ccdb85	2026-05-24 12:07:09.92786+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/5e9b0ae8-41d7-400a-b2ef-bda939783992/toggle-block - 200 (32ms)	\N	172.18.0.6	200	\N
40a6d481-ba82-44ba-9f68-90137e0dcdf1	2026-05-24 12:09:11.923756+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 201 (276ms)	\N	172.18.0.6	201	\N
4150d2b2-70e8-43f6-b170-b6d76f58b1a0	2026-05-24 12:28:12.160707+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/ebc9fea0-19f0-43ad-8b64-c5d92701a5dc/toggle-block - 200 (34ms)	\N	172.18.0.6	200	\N
f6763955-38c8-4101-b437-6495038559a5	2026-05-24 12:28:13.164149+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/ebc9fea0-19f0-43ad-8b64-c5d92701a5dc/toggle-block - 200 (99ms)	\N	172.18.0.6	200	\N
e69458b1-6b5e-4848-b62a-3ff7e74aa709	2026-05-24 12:28:25.176553+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 201 (215ms)	\N	172.18.0.6	201	\N
9dd2dcb1-89ea-4d61-9af3-e3e5607cfc12	2026-05-24 12:31:48.573267+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (69ms)	\N	172.18.0.6	200	\N
06ea7aaa-62b6-4683-b5b6-8bc158c45769	2026-05-24 12:31:49.598393+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (131ms)	\N	172.18.0.6	200	\N
c00a02b9-bf36-4670-a5a2-7045d73ae1fd	2026-05-24 12:31:54.923415+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (52ms)	\N	172.18.0.6	200	\N
1b6dfde7-7e64-4942-9f72-351a3feb338f	2026-05-24 12:31:55.407311+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (32ms)	\N	172.18.0.6	200	\N
b5fe5b9f-735b-426e-a01f-a804d55fee37	2026-05-24 12:31:56.014929+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (35ms)	\N	172.18.0.6	200	\N
c9adc74d-1e9c-4cde-8390-d8a4a3eac11b	2026-05-24 12:31:56.514826+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	PATCH /admin/users/0ea9c0f0-5ff7-4247-882f-3d91d917e4e8 - 200 (38ms)	\N	172.18.0.6	200	\N
cae96e57-3605-4f1e-9d4c-5aeb625582de	2026-05-24 12:37:53.506359+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (165ms)	\N	172.18.0.6	502	\N
aafe1cc8-5edb-473f-8332-6ac1e38d85cf	2026-05-24 12:37:54.731868+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (187ms)	\N	172.18.0.6	502	\N
9d619074-6905-4c07-8283-4bf21ad31ec2	2026-05-24 12:37:55.427699+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (182ms)	\N	172.18.0.6	502	\N
f5f1c580-5e95-47d9-a95b-a0b81ef8946b	2026-05-24 12:37:59.824064+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (139ms)	\N	172.18.0.6	502	\N
13a85ed1-f440-4a73-b6d1-996207ba268a	2026-05-24 12:38:09.320912+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (156ms)	\N	172.18.0.6	502	\N
fd75b55d-b02e-4278-9dad-bfcbd4cf9f5c	2026-05-24 12:38:09.896694+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (136ms)	\N	172.18.0.6	502	\N
9c5ca417-c68e-4ced-8fc2-e41c54427809	2026-05-24 12:38:15.330788+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (158ms)	\N	172.18.0.6	502	\N
c1246502-3056-4a06-93a6-3f5e77ce063c	2026-05-24 12:42:44.833132+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (362ms)	\N	172.18.0.6	502	\N
6951b361-9e6f-4589-9295-c0a13e1e54a5	2026-05-24 12:42:48.430196+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (138ms)	\N	172.18.0.6	502	\N
2fb6cee8-0859-4bdd-9808-37ab1638aed7	2026-05-24 12:42:53.591096+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (213ms)	\N	172.18.0.6	502	\N
b972fb9a-b7ac-4ea9-9df9-2bbd4d5dc413	2026-05-24 12:43:27.019696+00	ERROR	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 502 (176ms)	\N	172.18.0.6	502	\N
358d885d-045f-45cc-91d3-37635b15eed9	2026-05-24 12:49:21.977613+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 201 (1183ms)	\N	172.18.0.6	201	\N
9e1a53eb-e7cd-4114-a132-35ce076961da	2026-05-24 12:59:04.157142+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /repositories/ - 201 (1212ms)	\N	172.18.0.6	201	\N
9728ff25-6f93-45fb-b9ac-e560fb1c88cf	2026-05-24 13:05:34.15703+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	DELETE /admin/repositories/ebc9fea0-19f0-43ad-8b64-c5d92701a5dc - 204 (261ms)	\N	172.18.0.6	204	\N
cb483ea0-69ba-4119-af46-e547cb49454c	2026-05-24 13:05:36.684132+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/repositories/114fe60b-9680-4375-8027-428915ef77fc/toggle-block - 200 (192ms)	\N	172.18.0.6	200	\N
0bd4b884-4412-4b16-a1f8-3d0918807b3f	2026-05-24 13:05:38.455331+00	INFO	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	DELETE /admin/repositories/114fe60b-9680-4375-8027-428915ef77fc - 204 (240ms)	\N	172.18.0.6	204	\N
7edec272-a198-456b-b333-b37c55eb5f62	2026-05-24 13:43:30.447727+00	WARNING	admin	596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	Super Admin	POST /admin/restart - 403 (3ms)	\N	172.18.0.6	403	\N
\.


--
-- Data for Name: system_setting; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.system_setting (id, setting_key, setting_value, version, created, updated) FROM stdin;
1	revision		1	1778935339	1778935339
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.task (id, doer_id, owner_id, repo_id, type, status, start_time, end_time, payload_content, message, created) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.team (id, org_id, lower_name, name, description, authorize, num_repos, num_members, includes_all_repositories, can_create_org_repo) FROM stdin;
\.


--
-- Data for Name: team_invite; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.team_invite (id, token, inviter_id, org_id, team_id, email, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: team_repo; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.team_repo (id, org_id, team_id, repo_id) FROM stdin;
\.


--
-- Data for Name: team_unit; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.team_unit (id, org_id, team_id, type, access_mode) FROM stdin;
\.


--
-- Data for Name: team_user; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.team_user (id, org_id, team_id, uid) FROM stdin;
\.


--
-- Data for Name: topic; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.topic (id, name, repo_count, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: tracked_time; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.tracked_time (id, issue_id, user_id, created_unix, "time", deleted) FROM stdin;
\.


--
-- Data for Name: trusted_assistants; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.trusted_assistants (id, teacher_id, assistant_id, can_grade, created_at) FROM stdin;
\.


--
-- Data for Name: two_factor; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.two_factor (id, uid, secret, scratch_salt, scratch_hash, last_used_passcode, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: upload; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.upload (id, uuid, name) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public."user" (id, lower_name, name, full_name, email, keep_email_private, email_notifications_preference, passwd, passwd_hash_algo, must_change_password, login_type, login_source, login_name, type, location, website, rands, salt, language, description, created_unix, updated_unix, last_login_unix, last_repo_visibility, max_repo_creation, is_active, is_admin, is_restricted, allow_git_hook, allow_import_local, allow_create_organization, prohibit_login, avatar, avatar_email, use_custom_avatar, num_followers, num_following, num_stars, num_repos, num_teams, num_members, visibility, repo_admin_change_team_access, diff_view_style, theme, keep_activity_private) FROM stdin;
35	simonov	simonov		simonov@gitmtuci.lab	f	enabled	a0ce1818dc22dab5cdc65925b6d8fe707084e17b177b5d24bf7829e033333a937058d700e223eafac1a644c87fbdaf6dd2d7	pbkdf2$50000$50	f	1	0		0			006d58231f1df583e1b9f49249090bd5	a890bbd23ffb534e7cda093a6a8a9089			1779621256	1779621257	0	f	-1	t	f	f	f	f	t	f	9ac251d9cb70329238fd680554203086	simonov@gitmtuci.lab	f	0	0	0	1	0	0	0	f		gitea-auto	f
1	gitea_admin	gitea_admin		admin@gitea.local	f	enabled	49f892d38953a740d122112034d6956507696dd9ed648b84c03ddee783b9013efbc7144ab5bf2015c7a3f68707315ee23055	pbkdf2$50000$50	f	0	0		0			da43c7c2991777c5420b4f48492e0fa5	123b41d5fc4806894eb6f5a7203d322c			1778934808	1778935797	0	f	-1	t	t	f	f	f	f	f	9aba3897dceb59fd36f911063f6516e9	admin@gitea.local	f	0	0	0	0	0	0	0	f		gitea-auto	f
36	u596ca07fea2d	u596ca07fea2d		u596ca07fea2d@gitmtuci.lab	f	enabled	0521ffd12884d0648dce7b0efcc1a7ac7106f104d4d57ad25e163f74335df06335c313946573d7293e944d5d31815de3dcbe	pbkdf2$50000$50	f	1	0		0			5d99612edbc2b8e29b4c4f3f551678b8	0bc52db2ef8e7e24c343b9311f18cef9			1779626564	1779627543	0	f	-1	t	f	f	f	f	t	f	9f8f2350bce532aec9ae3f10d1e16c0b	u596ca07fea2d@gitmtuci.lab	f	0	0	0	2	0	0	0	f		gitea-auto	f
34	yu.e.lashkov	yu.e.lashkov		yu.e.lashkov@gitmtuci.lab	f	enabled	88840e3d81ab803579232b11fba91e8e50b515e5c49af0a7097cb8b8076e9faf1d71a8a698b35c2652f511889e3d85d4cdf2	pbkdf2$50000$50	f	1	0		0			e99f14fd1885c9234a5a2126d09b64ff	205c893cbb38108d2752862332fe55b0			1778935339	1779396926	0	t	-1	t	f	f	f	f	t	f	233af7b3a5286408bc5c04dba9a50072	yu.e.lashkov@gitmtuci.lab	f	0	0	0	3	0	0	0	f		gitea-auto	f
\.


--
-- Data for Name: user_badge; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.user_badge (id, badge_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_blocking; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.user_blocking (id, blocker_id, blockee_id, note, created_unix) FROM stdin;
\.


--
-- Data for Name: user_open_id; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.user_open_id (id, uid, uri, show) FROM stdin;
\.


--
-- Data for Name: user_redirect; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.user_redirect (id, lower_name, redirect_user_id) FROM stdin;
\.


--
-- Data for Name: user_setting; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.user_setting (id, user_id, setting_key, setting_value) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.users (id, email, password_hash, full_name, role, created_at, is_blocked, group_name, student_id, avatar_url, avatar_display_mode, mtuci_login, mtuci_password, is_pending, last_login, allow_assistant_grading, preferences) FROM stdin;
a7b17a5b-b8ff-4a7d-83a2-0991706e0ed9	deylon.shevtsov@yandex.ru	$2b$12$j9MIptwYN6rOiQbG7mKjdeh3Bs4TyCCTN1cpXLv6wm9SZQvWQmRNi	Лашков Юрий Евгеньевич	student	2026-05-16 11:08:48.561947+00	f	БВТ2403	1	\N	cover	yu.e.lashkov@edu.mtuci.ru	p2gaq781lmq9	f	2026-05-21 18:13:17.206963+00	f	{"theme": "dark", "language": "ru", "notifications": {"email": true, "push": true, "assignments": true, "grades": true, "teacher_pr_submitted": true, "teacher_pr_stale": true, "teacher_deadline_missed": true, "teacher_daily_digest": false}}
0ea9c0f0-5ff7-4247-882f-3d91d917e4e8	simonov@mtuci.ru	$2b$12$nKH/G0GuIBu3z/pMIduZhOF/Cxgtlj7UVJE9JxVDuN.fk9UhGKNDy	simonov	teacher	2026-05-21 20:15:42.442729+00	f	\N	\N	\N	cover	\N	\N	f	2026-05-24 09:39:21.385609+00	f	{"theme": "dark", "language": "ru", "notifications": {"email": true, "push": true, "assignments": true, "grades": true, "teacher_pr_submitted": true, "teacher_pr_stale": true, "teacher_deadline_missed": true, "teacher_daily_digest": false}}
596ca07f-ea2d-400b-9b99-f150fff23016	admin@mtuci.ru	$2b$12$UHvgIv99KIfaZy8zposE6ON3cyJMcw9DO78L0rgKzLTHtjMBxBCGC	Super Admin	admin	2026-05-16 10:56:29.452557+00	f	\N	\N	\N	cover	\N	\N	f	2026-05-24 13:32:05.220849+00	f	{"theme": "dark", "language": "ru", "notifications": {"email": true, "push": true, "assignments": true, "grades": true, "teacher_pr_submitted": true, "teacher_pr_stale": true, "teacher_deadline_missed": true, "teacher_daily_digest": false}}
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.version (id, version) FROM stdin;
1	299
\.


--
-- Data for Name: watch; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.watch (id, user_id, repo_id, mode, created_unix, updated_unix) FROM stdin;
9	1	12	1	1778936079	1778936079
10	1	14	1	1779322423	1779322423
11	1	15	1	1779396927	1779396927
12	1	16	1	1779621257	1779621257
17	1	21	1	1779626960	1779626960
18	1	22	1	1779627543	1779627543
\.


--
-- Data for Name: webauthn_credential; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.webauthn_credential (id, name, lower_name, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, clone_warning, created_unix, updated_unix) FROM stdin;
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: mtuci
--

COPY public.webhook (id, repo_id, owner_id, is_system_webhook, url, http_method, content_type, secret, events, is_active, type, meta, last_status, header_authorization_encrypted, created_unix, updated_unix) FROM stdin;
1	14	0	f	http://api:8000/webhooks/gitea/push	POST	1	mtuci-webhook-secret-2024	{"push_only":false,"send_everything":false,"choose_events":true,"branch_filter":"","events":{"create":false,"delete":false,"fork":false,"issues":false,"issue_assign":false,"issue_label":false,"issue_milestone":false,"issue_comment":false,"push":true,"pull_request":false,"pull_request_assign":false,"pull_request_label":false,"pull_request_milestone":false,"pull_request_comment":false,"pull_request_review":false,"pull_request_sync":false,"pull_request_review_request":false,"wiki":false,"repository":false,"release":false,"package":false}}	t	gitea		0		1779322424	1779322424
2	15	0	f	http://api:8000/webhooks/gitea/push	POST	1	mtuci-webhook-secret-2024	{"push_only":false,"send_everything":false,"choose_events":true,"branch_filter":"","events":{"create":false,"delete":false,"fork":false,"issues":false,"issue_assign":false,"issue_label":false,"issue_milestone":false,"issue_comment":false,"push":true,"pull_request":false,"pull_request_assign":false,"pull_request_label":false,"pull_request_milestone":false,"pull_request_comment":false,"pull_request_review":false,"pull_request_sync":false,"pull_request_review_request":false,"wiki":false,"repository":false,"release":false,"package":false}}	t	gitea		0		1779396928	1779396928
3	16	0	f	http://api:8000/webhooks/gitea/push	POST	1	mtuci-webhook-secret-2024	{"push_only":false,"send_everything":false,"choose_events":true,"branch_filter":"","events":{"create":false,"delete":false,"fork":false,"issues":false,"issue_assign":false,"issue_label":false,"issue_milestone":false,"issue_comment":false,"push":true,"pull_request":false,"pull_request_assign":false,"pull_request_label":false,"pull_request_milestone":false,"pull_request_comment":false,"pull_request_review":false,"pull_request_sync":false,"pull_request_review_request":false,"wiki":false,"repository":false,"release":false,"package":false}}	t	gitea		0		1779621259	1779621259
4	21	0	f	http://api:8000/webhooks/gitea/push	POST	1	mtuci-webhook-secret-2024	{"push_only":false,"send_everything":false,"choose_events":true,"branch_filter":"","events":{"create":false,"delete":false,"fork":false,"issues":false,"issue_assign":false,"issue_label":false,"issue_milestone":false,"issue_comment":false,"push":true,"pull_request":false,"pull_request_assign":false,"pull_request_label":false,"pull_request_milestone":false,"pull_request_comment":false,"pull_request_review":false,"pull_request_sync":false,"pull_request_review_request":false,"wiki":false,"repository":false,"release":false,"package":false}}	t	gitea		0		1779626961	1779626961
5	22	0	f	http://api:8000/webhooks/gitea/push	POST	1	mtuci-webhook-secret-2024	{"push_only":false,"send_everything":false,"choose_events":true,"branch_filter":"","events":{"create":false,"delete":false,"fork":false,"issues":false,"issue_assign":false,"issue_label":false,"issue_milestone":false,"issue_comment":false,"push":true,"pull_request":false,"pull_request_assign":false,"pull_request_label":false,"pull_request_milestone":false,"pull_request_comment":false,"pull_request_review":false,"pull_request_sync":false,"pull_request_review_request":false,"wiki":false,"repository":false,"release":false,"package":false}}	t	gitea		0		1779627543	1779627543
\.


--
-- Name: access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.access_id_seq', 1, false);


--
-- Name: access_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.access_token_id_seq', 2, true);


--
-- Name: action_artifact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_artifact_id_seq', 1, false);


--
-- Name: action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_id_seq', 18, true);


--
-- Name: action_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_run_id_seq', 1, false);


--
-- Name: action_run_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_run_job_id_seq', 1, false);


--
-- Name: action_runner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_runner_id_seq', 1, false);


--
-- Name: action_runner_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_runner_token_id_seq', 1, false);


--
-- Name: action_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_schedule_id_seq', 1, false);


--
-- Name: action_schedule_spec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_schedule_spec_id_seq', 1, false);


--
-- Name: action_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_task_id_seq', 1, false);


--
-- Name: action_task_output_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_task_output_id_seq', 1, false);


--
-- Name: action_task_step_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_task_step_id_seq', 1, false);


--
-- Name: action_tasks_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_tasks_version_id_seq', 1, false);


--
-- Name: action_variable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.action_variable_id_seq', 1, false);


--
-- Name: attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.attachment_id_seq', 1, false);


--
-- Name: badge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.badge_id_seq', 1, false);


--
-- Name: branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.branch_id_seq', 9, true);


--
-- Name: collaboration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.collaboration_id_seq', 1, false);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.comment_id_seq', 1, false);


--
-- Name: commit_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.commit_status_id_seq', 1, false);


--
-- Name: commit_status_index_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.commit_status_index_id_seq', 1, false);


--
-- Name: commit_status_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.commit_status_summary_id_seq', 1, false);


--
-- Name: dbfs_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.dbfs_data_id_seq', 1, false);


--
-- Name: dbfs_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.dbfs_meta_id_seq', 1, false);


--
-- Name: deploy_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.deploy_key_id_seq', 1, false);


--
-- Name: email_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.email_address_id_seq', 36, true);


--
-- Name: follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.follow_id_seq', 1, false);


--
-- Name: gpg_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.gpg_key_id_seq', 1, false);


--
-- Name: hook_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.hook_task_id_seq', 1, false);


--
-- Name: issue_assignees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_assignees_id_seq', 1, false);


--
-- Name: issue_content_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_content_history_id_seq', 1, false);


--
-- Name: issue_dependency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_dependency_id_seq', 1, false);


--
-- Name: issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_id_seq', 1, false);


--
-- Name: issue_label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_label_id_seq', 1, false);


--
-- Name: issue_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_user_id_seq', 1, false);


--
-- Name: issue_watch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.issue_watch_id_seq', 1, false);


--
-- Name: label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.label_id_seq', 1, false);


--
-- Name: language_stat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.language_stat_id_seq', 1, true);


--
-- Name: lfs_lock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.lfs_lock_id_seq', 1, false);


--
-- Name: lfs_meta_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.lfs_meta_object_id_seq', 1, false);


--
-- Name: login_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.login_source_id_seq', 1, false);


--
-- Name: milestone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.milestone_id_seq', 1, false);


--
-- Name: mirror_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.mirror_id_seq', 1, false);


--
-- Name: notice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.notice_id_seq', 1, false);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, false);


--
-- Name: oauth2_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.oauth2_application_id_seq', 3, true);


--
-- Name: oauth2_authorization_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.oauth2_authorization_code_id_seq', 1, false);


--
-- Name: oauth2_grant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.oauth2_grant_id_seq', 1, false);


--
-- Name: org_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.org_user_id_seq', 1, false);


--
-- Name: package_blob_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_blob_id_seq', 1, false);


--
-- Name: package_cleanup_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_cleanup_rule_id_seq', 1, false);


--
-- Name: package_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_file_id_seq', 1, false);


--
-- Name: package_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_id_seq', 1, false);


--
-- Name: package_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_property_id_seq', 1, false);


--
-- Name: package_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.package_version_id_seq', 1, false);


--
-- Name: project_board_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.project_board_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.project_id_seq', 1, false);


--
-- Name: project_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.project_issue_id_seq', 1, false);


--
-- Name: protected_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.protected_branch_id_seq', 1, false);


--
-- Name: protected_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.protected_tag_id_seq', 1, false);


--
-- Name: public_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.public_key_id_seq', 1, false);


--
-- Name: pull_auto_merge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.pull_auto_merge_id_seq', 1, false);


--
-- Name: pull_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.pull_request_id_seq', 1, false);


--
-- Name: push_mirror_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.push_mirror_id_seq', 1, false);


--
-- Name: reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.reaction_id_seq', 1, false);


--
-- Name: release_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.release_id_seq', 1, false);


--
-- Name: renamed_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.renamed_branch_id_seq', 1, false);


--
-- Name: repo_archiver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repo_archiver_id_seq', 1, false);


--
-- Name: repo_indexer_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repo_indexer_status_id_seq', 9, true);


--
-- Name: repo_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repo_redirect_id_seq', 1, false);


--
-- Name: repo_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repo_transfer_id_seq', 1, false);


--
-- Name: repo_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repo_unit_id_seq', 144, true);


--
-- Name: repository_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.repository_id_seq', 22, true);


--
-- Name: review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.review_id_seq', 1, false);


--
-- Name: review_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.review_state_id_seq', 1, false);


--
-- Name: secret_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.secret_id_seq', 1, false);


--
-- Name: star_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.star_id_seq', 1, false);


--
-- Name: stopwatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.stopwatch_id_seq', 1, false);


--
-- Name: system_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.system_setting_id_seq', 1, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.task_id_seq', 1, false);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.team_id_seq', 1, false);


--
-- Name: team_invite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.team_invite_id_seq', 1, false);


--
-- Name: team_repo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.team_repo_id_seq', 1, false);


--
-- Name: team_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.team_unit_id_seq', 1, false);


--
-- Name: team_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.team_user_id_seq', 1, false);


--
-- Name: topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.topic_id_seq', 1, false);


--
-- Name: tracked_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.tracked_time_id_seq', 1, false);


--
-- Name: two_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.two_factor_id_seq', 1, false);


--
-- Name: upload_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.upload_id_seq', 1, false);


--
-- Name: user_badge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_badge_id_seq', 1, false);


--
-- Name: user_blocking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_blocking_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_id_seq', 36, true);


--
-- Name: user_open_id_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_open_id_id_seq', 1, false);


--
-- Name: user_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_redirect_id_seq', 1, false);


--
-- Name: user_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.user_setting_id_seq', 1, false);


--
-- Name: version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.version_id_seq', 1, true);


--
-- Name: watch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.watch_id_seq', 18, true);


--
-- Name: webauthn_credential_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.webauthn_credential_id_seq', 1, false);


--
-- Name: webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mtuci
--

SELECT pg_catalog.setval('public.webhook_id_seq', 5, true);


--
-- Name: access access_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (id);


--
-- Name: access_token access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT access_token_pkey PRIMARY KEY (id);


--
-- Name: action_artifact action_artifact_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_artifact
    ADD CONSTRAINT action_artifact_pkey PRIMARY KEY (id);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: action_run_index action_run_index_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_run_index
    ADD CONSTRAINT action_run_index_pkey PRIMARY KEY (group_id);


--
-- Name: action_run_job action_run_job_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_run_job
    ADD CONSTRAINT action_run_job_pkey PRIMARY KEY (id);


--
-- Name: action_run action_run_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_run
    ADD CONSTRAINT action_run_pkey PRIMARY KEY (id);


--
-- Name: action_runner action_runner_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_runner
    ADD CONSTRAINT action_runner_pkey PRIMARY KEY (id);


--
-- Name: action_runner_token action_runner_token_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_runner_token
    ADD CONSTRAINT action_runner_token_pkey PRIMARY KEY (id);


--
-- Name: action_schedule action_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_schedule
    ADD CONSTRAINT action_schedule_pkey PRIMARY KEY (id);


--
-- Name: action_schedule_spec action_schedule_spec_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_schedule_spec
    ADD CONSTRAINT action_schedule_spec_pkey PRIMARY KEY (id);


--
-- Name: action_task_output action_task_output_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task_output
    ADD CONSTRAINT action_task_output_pkey PRIMARY KEY (id);


--
-- Name: action_task action_task_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task
    ADD CONSTRAINT action_task_pkey PRIMARY KEY (id);


--
-- Name: action_task_step action_task_step_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_task_step
    ADD CONSTRAINT action_task_step_pkey PRIMARY KEY (id);


--
-- Name: action_tasks_version action_tasks_version_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_tasks_version
    ADD CONSTRAINT action_tasks_version_pkey PRIMARY KEY (id);


--
-- Name: action_variable action_variable_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.action_variable
    ADD CONSTRAINT action_variable_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: app_state app_state_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.app_state
    ADD CONSTRAINT app_state_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: auth_token auth_token_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.auth_token
    ADD CONSTRAINT auth_token_pkey PRIMARY KEY (id);


--
-- Name: badge badge_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.badge
    ADD CONSTRAINT badge_pkey PRIMARY KEY (id);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (id);


--
-- Name: collaboration collaboration_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.collaboration
    ADD CONSTRAINT collaboration_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: commit_status_index commit_status_index_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status_index
    ADD CONSTRAINT commit_status_index_pkey PRIMARY KEY (id);


--
-- Name: commit_status commit_status_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status
    ADD CONSTRAINT commit_status_pkey PRIMARY KEY (id);


--
-- Name: commit_status_summary commit_status_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.commit_status_summary
    ADD CONSTRAINT commit_status_summary_pkey PRIMARY KEY (id);


--
-- Name: dbfs_data dbfs_data_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.dbfs_data
    ADD CONSTRAINT dbfs_data_pkey PRIMARY KEY (id);


--
-- Name: dbfs_meta dbfs_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.dbfs_meta
    ADD CONSTRAINT dbfs_meta_pkey PRIMARY KEY (id);


--
-- Name: deploy_key deploy_key_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.deploy_key
    ADD CONSTRAINT deploy_key_pkey PRIMARY KEY (id);


--
-- Name: email_address email_address_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.email_address
    ADD CONSTRAINT email_address_pkey PRIMARY KEY (id);


--
-- Name: email_hash email_hash_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.email_hash
    ADD CONSTRAINT email_hash_pkey PRIMARY KEY (hash);


--
-- Name: external_login_user external_login_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.external_login_user
    ADD CONSTRAINT external_login_user_pkey PRIMARY KEY (external_id, login_source_id);


--
-- Name: follow follow_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.follow
    ADD CONSTRAINT follow_pkey PRIMARY KEY (id);


--
-- Name: gpg_key_import gpg_key_import_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.gpg_key_import
    ADD CONSTRAINT gpg_key_import_pkey PRIMARY KEY (key_id);


--
-- Name: gpg_key gpg_key_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.gpg_key
    ADD CONSTRAINT gpg_key_pkey PRIMARY KEY (id);


--
-- Name: hook_task hook_task_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.hook_task
    ADD CONSTRAINT hook_task_pkey PRIMARY KEY (id);


--
-- Name: issue_assignees issue_assignees_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_assignees
    ADD CONSTRAINT issue_assignees_pkey PRIMARY KEY (id);


--
-- Name: issue_content_history issue_content_history_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_content_history
    ADD CONSTRAINT issue_content_history_pkey PRIMARY KEY (id);


--
-- Name: issue_dependency issue_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_dependency
    ADD CONSTRAINT issue_dependency_pkey PRIMARY KEY (id);


--
-- Name: issue_index issue_index_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_index
    ADD CONSTRAINT issue_index_pkey PRIMARY KEY (group_id);


--
-- Name: issue_label issue_label_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_label
    ADD CONSTRAINT issue_label_pkey PRIMARY KEY (id);


--
-- Name: issue issue_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue
    ADD CONSTRAINT issue_pkey PRIMARY KEY (id);


--
-- Name: issue_user issue_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_user
    ADD CONSTRAINT issue_user_pkey PRIMARY KEY (id);


--
-- Name: issue_watch issue_watch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.issue_watch
    ADD CONSTRAINT issue_watch_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: language_stat language_stat_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.language_stat
    ADD CONSTRAINT language_stat_pkey PRIMARY KEY (id);


--
-- Name: lfs_lock lfs_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.lfs_lock
    ADD CONSTRAINT lfs_lock_pkey PRIMARY KEY (id);


--
-- Name: lfs_meta_object lfs_meta_object_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.lfs_meta_object
    ADD CONSTRAINT lfs_meta_object_pkey PRIMARY KEY (id);


--
-- Name: login_source login_source_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.login_source
    ADD CONSTRAINT login_source_pkey PRIMARY KEY (id);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (id);


--
-- Name: mirror mirror_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.mirror
    ADD CONSTRAINT mirror_pkey PRIMARY KEY (id);


--
-- Name: notice notice_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notice
    ADD CONSTRAINT notice_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: oauth2_application oauth2_application_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_application
    ADD CONSTRAINT oauth2_application_pkey PRIMARY KEY (id);


--
-- Name: oauth2_authorization_code oauth2_authorization_code_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_authorization_code
    ADD CONSTRAINT oauth2_authorization_code_pkey PRIMARY KEY (id);


--
-- Name: oauth2_grant oauth2_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.oauth2_grant
    ADD CONSTRAINT oauth2_grant_pkey PRIMARY KEY (id);


--
-- Name: org_user org_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.org_user
    ADD CONSTRAINT org_user_pkey PRIMARY KEY (id);


--
-- Name: package_blob package_blob_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_blob
    ADD CONSTRAINT package_blob_pkey PRIMARY KEY (id);


--
-- Name: package_blob_upload package_blob_upload_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_blob_upload
    ADD CONSTRAINT package_blob_upload_pkey PRIMARY KEY (id);


--
-- Name: package_cleanup_rule package_cleanup_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_cleanup_rule
    ADD CONSTRAINT package_cleanup_rule_pkey PRIMARY KEY (id);


--
-- Name: package_file package_file_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_file
    ADD CONSTRAINT package_file_pkey PRIMARY KEY (id);


--
-- Name: package package_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_pkey PRIMARY KEY (id);


--
-- Name: package_property package_property_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_property
    ADD CONSTRAINT package_property_pkey PRIMARY KEY (id);


--
-- Name: package_version package_version_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.package_version
    ADD CONSTRAINT package_version_pkey PRIMARY KEY (id);


--
-- Name: activity_log pk_activity_log; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT pk_activity_log PRIMARY KEY (id);


--
-- Name: assignment_files pk_assignment_files; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.assignment_files
    ADD CONSTRAINT pk_assignment_files PRIMARY KEY (id);


--
-- Name: assignments pk_assignments; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT pk_assignments PRIMARY KEY (id);


--
-- Name: course_enrollments pk_course_enrollments; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT pk_course_enrollments PRIMARY KEY (id);


--
-- Name: courses pk_courses; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT pk_courses PRIMARY KEY (id);


--
-- Name: notifications pk_notifications; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT pk_notifications PRIMARY KEY (id);


--
-- Name: password_reset_tokens pk_password_reset_tokens; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT pk_password_reset_tokens PRIMARY KEY (id);


--
-- Name: permission_audit pk_permission_audit; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.permission_audit
    ADD CONSTRAINT pk_permission_audit PRIMARY KEY (id);


--
-- Name: repositories pk_repositories; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT pk_repositories PRIMARY KEY (id);


--
-- Name: role_permissions pk_role_permissions; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT pk_role_permissions PRIMARY KEY (id);


--
-- Name: student_repositories pk_student_repositories; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.student_repositories
    ADD CONSTRAINT pk_student_repositories PRIMARY KEY (id);


--
-- Name: submissions pk_submissions; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT pk_submissions PRIMARY KEY (id);


--
-- Name: system_logs pk_system_logs; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT pk_system_logs PRIMARY KEY (id);


--
-- Name: trusted_assistants pk_trusted_assistants; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.trusted_assistants
    ADD CONSTRAINT pk_trusted_assistants PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: project_board project_board_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project_board
    ADD CONSTRAINT project_board_pkey PRIMARY KEY (id);


--
-- Name: project_issue project_issue_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project_issue
    ADD CONSTRAINT project_issue_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: protected_branch protected_branch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.protected_branch
    ADD CONSTRAINT protected_branch_pkey PRIMARY KEY (id);


--
-- Name: protected_tag protected_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.protected_tag
    ADD CONSTRAINT protected_tag_pkey PRIMARY KEY (id);


--
-- Name: public_key public_key_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.public_key
    ADD CONSTRAINT public_key_pkey PRIMARY KEY (id);


--
-- Name: pull_auto_merge pull_auto_merge_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.pull_auto_merge
    ADD CONSTRAINT pull_auto_merge_pkey PRIMARY KEY (id);


--
-- Name: pull_request pull_request_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.pull_request
    ADD CONSTRAINT pull_request_pkey PRIMARY KEY (id);


--
-- Name: push_mirror push_mirror_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.push_mirror
    ADD CONSTRAINT push_mirror_pkey PRIMARY KEY (id);


--
-- Name: reaction reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.reaction
    ADD CONSTRAINT reaction_pkey PRIMARY KEY (id);


--
-- Name: release release_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (id);


--
-- Name: renamed_branch renamed_branch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.renamed_branch
    ADD CONSTRAINT renamed_branch_pkey PRIMARY KEY (id);


--
-- Name: repo_archiver repo_archiver_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_archiver
    ADD CONSTRAINT repo_archiver_pkey PRIMARY KEY (id);


--
-- Name: repo_indexer_status repo_indexer_status_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_indexer_status
    ADD CONSTRAINT repo_indexer_status_pkey PRIMARY KEY (id);


--
-- Name: repo_redirect repo_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_redirect
    ADD CONSTRAINT repo_redirect_pkey PRIMARY KEY (id);


--
-- Name: repo_topic repo_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_topic
    ADD CONSTRAINT repo_topic_pkey PRIMARY KEY (repo_id, topic_id);


--
-- Name: repo_transfer repo_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_transfer
    ADD CONSTRAINT repo_transfer_pkey PRIMARY KEY (id);


--
-- Name: repo_unit repo_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repo_unit
    ADD CONSTRAINT repo_unit_pkey PRIMARY KEY (id);


--
-- Name: repository repository_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: review_state review_state_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.review_state
    ADD CONSTRAINT review_state_pkey PRIMARY KEY (id);


--
-- Name: secret secret_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.secret
    ADD CONSTRAINT secret_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (key);


--
-- Name: star star_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.star
    ADD CONSTRAINT star_pkey PRIMARY KEY (id);


--
-- Name: stopwatch stopwatch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.stopwatch
    ADD CONSTRAINT stopwatch_pkey PRIMARY KEY (id);


--
-- Name: system_setting system_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.system_setting
    ADD CONSTRAINT system_setting_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: team_invite team_invite_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_invite
    ADD CONSTRAINT team_invite_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: team_repo team_repo_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_repo
    ADD CONSTRAINT team_repo_pkey PRIMARY KEY (id);


--
-- Name: team_unit team_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_unit
    ADD CONSTRAINT team_unit_pkey PRIMARY KEY (id);


--
-- Name: team_user team_user_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.team_user
    ADD CONSTRAINT team_user_pkey PRIMARY KEY (id);


--
-- Name: topic topic_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.topic
    ADD CONSTRAINT topic_pkey PRIMARY KEY (id);


--
-- Name: tracked_time tracked_time_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.tracked_time
    ADD CONSTRAINT tracked_time_pkey PRIMARY KEY (id);


--
-- Name: two_factor two_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.two_factor
    ADD CONSTRAINT two_factor_pkey PRIMARY KEY (id);


--
-- Name: upload upload_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.upload
    ADD CONSTRAINT upload_pkey PRIMARY KEY (id);


--
-- Name: course_enrollments uq_course_enrollments_course_id_student_id; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT uq_course_enrollments_course_id_student_id UNIQUE (course_id, student_id);


--
-- Name: notifications uq_notifications_user_dedupe; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT uq_notifications_user_dedupe UNIQUE (user_id, dedupe_key);


--
-- Name: role_permissions uq_role_permission; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT uq_role_permission UNIQUE (role, permission_id);


--
-- Name: student_repositories uq_student_repositories_assignment_id_student_id; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.student_repositories
    ADD CONSTRAINT uq_student_repositories_assignment_id_student_id UNIQUE (assignment_id, student_id);


--
-- Name: student_repositories uq_student_repositories_repo_name; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.student_repositories
    ADD CONSTRAINT uq_student_repositories_repo_name UNIQUE (repo_name);


--
-- Name: submissions uq_submissions_assignment_id_student_id; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT uq_submissions_assignment_id_student_id UNIQUE (assignment_id, student_id);


--
-- Name: trusted_assistants uq_teacher_assistant; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.trusted_assistants
    ADD CONSTRAINT uq_teacher_assistant UNIQUE (teacher_id, assistant_id);


--
-- Name: users uq_users_email; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email UNIQUE (email);


--
-- Name: user_badge user_badge_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_badge
    ADD CONSTRAINT user_badge_pkey PRIMARY KEY (id);


--
-- Name: user_blocking user_blocking_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_blocking
    ADD CONSTRAINT user_blocking_pkey PRIMARY KEY (id);


--
-- Name: user_open_id user_open_id_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_open_id
    ADD CONSTRAINT user_open_id_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_redirect user_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_redirect
    ADD CONSTRAINT user_redirect_pkey PRIMARY KEY (id);


--
-- Name: user_setting user_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.user_setting
    ADD CONSTRAINT user_setting_pkey PRIMARY KEY (id);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: watch watch_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.watch
    ADD CONSTRAINT watch_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credential webauthn_credential_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.webauthn_credential
    ADD CONSTRAINT webauthn_credential_pkey PRIMARY KEY (id);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: IDX_access_token_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_access_token_created_unix" ON public.access_token USING btree (created_unix);


--
-- Name: IDX_access_token_token_last_eight; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_access_token_token_last_eight" ON public.access_token USING btree (token_last_eight);


--
-- Name: IDX_access_token_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_access_token_uid" ON public.access_token USING btree (uid);


--
-- Name: IDX_access_token_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_access_token_updated_unix" ON public.access_token USING btree (updated_unix);


--
-- Name: IDX_action_artifact_artifact_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_artifact_name" ON public.action_artifact USING btree (artifact_name);


--
-- Name: IDX_action_artifact_artifact_path; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_artifact_path" ON public.action_artifact USING btree (artifact_path);


--
-- Name: IDX_action_artifact_expired_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_expired_unix" ON public.action_artifact USING btree (expired_unix);


--
-- Name: IDX_action_artifact_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_repo_id" ON public.action_artifact USING btree (repo_id);


--
-- Name: IDX_action_artifact_run_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_run_id" ON public.action_artifact USING btree (run_id);


--
-- Name: IDX_action_artifact_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_status" ON public.action_artifact USING btree (status);


--
-- Name: IDX_action_artifact_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_artifact_updated_unix" ON public.action_artifact USING btree (updated_unix);


--
-- Name: IDX_action_au_r_c_u_d; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_au_r_c_u_d" ON public.action USING btree (act_user_id, repo_id, created_unix, user_id, is_deleted);


--
-- Name: IDX_action_c_u_d; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_c_u_d" ON public.action USING btree (created_unix, user_id, is_deleted);


--
-- Name: IDX_action_comment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_comment_id" ON public.action USING btree (comment_id);


--
-- Name: IDX_action_r_u_d; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_r_u_d" ON public.action USING btree (repo_id, user_id, is_deleted);


--
-- Name: IDX_action_run_approved_by; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_approved_by" ON public.action_run USING btree (approved_by);


--
-- Name: IDX_action_run_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_index" ON public.action_run USING btree (index);


--
-- Name: IDX_action_run_index_max_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_index_max_index" ON public.action_run_index USING btree (max_index);


--
-- Name: IDX_action_run_job_commit_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_commit_sha" ON public.action_run_job USING btree (commit_sha);


--
-- Name: IDX_action_run_job_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_owner_id" ON public.action_run_job USING btree (owner_id);


--
-- Name: IDX_action_run_job_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_repo_id" ON public.action_run_job USING btree (repo_id);


--
-- Name: IDX_action_run_job_run_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_run_id" ON public.action_run_job USING btree (run_id);


--
-- Name: IDX_action_run_job_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_status" ON public.action_run_job USING btree (status);


--
-- Name: IDX_action_run_job_updated; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_job_updated" ON public.action_run_job USING btree (updated);


--
-- Name: IDX_action_run_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_owner_id" ON public.action_run USING btree (owner_id);


--
-- Name: IDX_action_run_ref; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_ref" ON public.action_run USING btree (ref);


--
-- Name: IDX_action_run_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_repo_id" ON public.action_run USING btree (repo_id);


--
-- Name: IDX_action_run_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_status" ON public.action_run USING btree (status);


--
-- Name: IDX_action_run_trigger_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_trigger_user_id" ON public.action_run USING btree (trigger_user_id);


--
-- Name: IDX_action_run_workflow_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_run_workflow_id" ON public.action_run USING btree (workflow_id);


--
-- Name: IDX_action_runner_last_active; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_last_active" ON public.action_runner USING btree (last_active);


--
-- Name: IDX_action_runner_last_online; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_last_online" ON public.action_runner USING btree (last_online);


--
-- Name: IDX_action_runner_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_owner_id" ON public.action_runner USING btree (owner_id);


--
-- Name: IDX_action_runner_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_repo_id" ON public.action_runner USING btree (repo_id);


--
-- Name: IDX_action_runner_token_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_token_owner_id" ON public.action_runner_token USING btree (owner_id);


--
-- Name: IDX_action_runner_token_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_runner_token_repo_id" ON public.action_runner_token USING btree (repo_id);


--
-- Name: IDX_action_schedule_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_schedule_owner_id" ON public.action_schedule USING btree (owner_id);


--
-- Name: IDX_action_schedule_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_schedule_repo_id" ON public.action_schedule USING btree (repo_id);


--
-- Name: IDX_action_schedule_spec_next; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_schedule_spec_next" ON public.action_schedule_spec USING btree (next);


--
-- Name: IDX_action_schedule_spec_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_schedule_spec_repo_id" ON public.action_schedule_spec USING btree (repo_id);


--
-- Name: IDX_action_schedule_spec_schedule_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_schedule_spec_schedule_id" ON public.action_schedule_spec USING btree (schedule_id);


--
-- Name: IDX_action_task_commit_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_commit_sha" ON public.action_task USING btree (commit_sha);


--
-- Name: IDX_action_task_output_task_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_output_task_id" ON public.action_task_output USING btree (task_id);


--
-- Name: IDX_action_task_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_owner_id" ON public.action_task USING btree (owner_id);


--
-- Name: IDX_action_task_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_repo_id" ON public.action_task USING btree (repo_id);


--
-- Name: IDX_action_task_runner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_runner_id" ON public.action_task USING btree (runner_id);


--
-- Name: IDX_action_task_started; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_started" ON public.action_task USING btree (started);


--
-- Name: IDX_action_task_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_status" ON public.action_task USING btree (status);


--
-- Name: IDX_action_task_step_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_step_index" ON public.action_task_step USING btree (index);


--
-- Name: IDX_action_task_step_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_step_repo_id" ON public.action_task_step USING btree (repo_id);


--
-- Name: IDX_action_task_step_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_step_status" ON public.action_task_step USING btree (status);


--
-- Name: IDX_action_task_step_task_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_step_task_id" ON public.action_task_step USING btree (task_id);


--
-- Name: IDX_action_task_token_last_eight; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_token_last_eight" ON public.action_task USING btree (token_last_eight);


--
-- Name: IDX_action_task_updated; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_task_updated" ON public.action_task USING btree (updated);


--
-- Name: IDX_action_tasks_version_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_tasks_version_repo_id" ON public.action_tasks_version USING btree (repo_id);


--
-- Name: IDX_action_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_user_id" ON public.action USING btree (user_id);


--
-- Name: IDX_action_variable_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_action_variable_repo_id" ON public.action_variable USING btree (repo_id);


--
-- Name: IDX_attachment_comment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_attachment_comment_id" ON public.attachment USING btree (comment_id);


--
-- Name: IDX_attachment_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_attachment_issue_id" ON public.attachment USING btree (issue_id);


--
-- Name: IDX_attachment_release_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_attachment_release_id" ON public.attachment USING btree (release_id);


--
-- Name: IDX_attachment_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_attachment_repo_id" ON public.attachment USING btree (repo_id);


--
-- Name: IDX_attachment_uploader_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_attachment_uploader_id" ON public.attachment USING btree (uploader_id);


--
-- Name: IDX_auth_token_expires_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_auth_token_expires_unix" ON public.auth_token USING btree (expires_unix);


--
-- Name: IDX_auth_token_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_auth_token_user_id" ON public.auth_token USING btree (user_id);


--
-- Name: IDX_branch_deleted_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_branch_deleted_unix" ON public.branch USING btree (deleted_unix);


--
-- Name: IDX_branch_is_deleted; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_branch_is_deleted" ON public.branch USING btree (is_deleted);


--
-- Name: IDX_collaboration_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_collaboration_created_unix" ON public.collaboration USING btree (created_unix);


--
-- Name: IDX_collaboration_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_collaboration_repo_id" ON public.collaboration USING btree (repo_id);


--
-- Name: IDX_collaboration_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_collaboration_updated_unix" ON public.collaboration USING btree (updated_unix);


--
-- Name: IDX_collaboration_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_collaboration_user_id" ON public.collaboration USING btree (user_id);


--
-- Name: IDX_comment_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_created_unix" ON public.comment USING btree (created_unix);


--
-- Name: IDX_comment_dependent_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_dependent_issue_id" ON public.comment USING btree (dependent_issue_id);


--
-- Name: IDX_comment_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_issue_id" ON public.comment USING btree (issue_id);


--
-- Name: IDX_comment_poster_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_poster_id" ON public.comment USING btree (poster_id);


--
-- Name: IDX_comment_ref_comment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_ref_comment_id" ON public.comment USING btree (ref_comment_id);


--
-- Name: IDX_comment_ref_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_ref_issue_id" ON public.comment USING btree (ref_issue_id);


--
-- Name: IDX_comment_ref_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_ref_repo_id" ON public.comment USING btree (ref_repo_id);


--
-- Name: IDX_comment_review_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_review_id" ON public.comment USING btree (review_id);


--
-- Name: IDX_comment_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_type" ON public.comment USING btree (type);


--
-- Name: IDX_comment_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_comment_updated_unix" ON public.comment USING btree (updated_unix);


--
-- Name: IDX_commit_status_context_hash; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_context_hash" ON public.commit_status USING btree (context_hash);


--
-- Name: IDX_commit_status_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_created_unix" ON public.commit_status USING btree (created_unix);


--
-- Name: IDX_commit_status_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_index" ON public.commit_status USING btree (index);


--
-- Name: IDX_commit_status_index_max_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_index_max_index" ON public.commit_status_index USING btree (max_index);


--
-- Name: IDX_commit_status_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_repo_id" ON public.commit_status USING btree (repo_id);


--
-- Name: IDX_commit_status_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_sha" ON public.commit_status USING btree (sha);


--
-- Name: IDX_commit_status_summary_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_summary_repo_id" ON public.commit_status_summary USING btree (repo_id);


--
-- Name: IDX_commit_status_summary_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_summary_sha" ON public.commit_status_summary USING btree (sha);


--
-- Name: IDX_commit_status_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_commit_status_updated_unix" ON public.commit_status USING btree (updated_unix);


--
-- Name: IDX_dbfs_data_meta_offset; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_dbfs_data_meta_offset" ON public.dbfs_data USING btree (meta_id, blob_offset);


--
-- Name: IDX_deploy_key_key_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_deploy_key_key_id" ON public.deploy_key USING btree (key_id);


--
-- Name: IDX_deploy_key_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_deploy_key_repo_id" ON public.deploy_key USING btree (repo_id);


--
-- Name: IDX_email_address_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_email_address_uid" ON public.email_address USING btree (uid);


--
-- Name: IDX_external_login_user_provider; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_external_login_user_provider" ON public.external_login_user USING btree (provider);


--
-- Name: IDX_external_login_user_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_external_login_user_user_id" ON public.external_login_user USING btree (user_id);


--
-- Name: IDX_follow_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_follow_created_unix" ON public.follow USING btree (created_unix);


--
-- Name: IDX_gpg_key_key_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_gpg_key_key_id" ON public.gpg_key USING btree (key_id);


--
-- Name: IDX_gpg_key_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_gpg_key_owner_id" ON public.gpg_key USING btree (owner_id);


--
-- Name: IDX_hook_task_hook_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_hook_task_hook_id" ON public.hook_task USING btree (hook_id);


--
-- Name: IDX_issue_assignees_assignee_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_assignees_assignee_id" ON public.issue_assignees USING btree (assignee_id);


--
-- Name: IDX_issue_assignees_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_assignees_issue_id" ON public.issue_assignees USING btree (issue_id);


--
-- Name: IDX_issue_closed_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_closed_unix" ON public.issue USING btree (closed_unix);


--
-- Name: IDX_issue_content_history_comment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_content_history_comment_id" ON public.issue_content_history USING btree (comment_id);


--
-- Name: IDX_issue_content_history_edited_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_content_history_edited_unix" ON public.issue_content_history USING btree (edited_unix);


--
-- Name: IDX_issue_content_history_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_content_history_issue_id" ON public.issue_content_history USING btree (issue_id);


--
-- Name: IDX_issue_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_created_unix" ON public.issue USING btree (created_unix);


--
-- Name: IDX_issue_deadline_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_deadline_unix" ON public.issue USING btree (deadline_unix);


--
-- Name: IDX_issue_index_max_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_index_max_index" ON public.issue_index USING btree (max_index);


--
-- Name: IDX_issue_is_closed; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_is_closed" ON public.issue USING btree (is_closed);


--
-- Name: IDX_issue_is_pull; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_is_pull" ON public.issue USING btree (is_pull);


--
-- Name: IDX_issue_milestone_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_milestone_id" ON public.issue USING btree (milestone_id);


--
-- Name: IDX_issue_original_author_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_original_author_id" ON public.issue USING btree (original_author_id);


--
-- Name: IDX_issue_poster_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_poster_id" ON public.issue USING btree (poster_id);


--
-- Name: IDX_issue_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_repo_id" ON public.issue USING btree (repo_id);


--
-- Name: IDX_issue_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_updated_unix" ON public.issue USING btree (updated_unix);


--
-- Name: IDX_issue_user_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_user_issue_id" ON public.issue_user USING btree (issue_id);


--
-- Name: IDX_issue_user_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_issue_user_uid" ON public.issue_user USING btree (uid);


--
-- Name: IDX_label_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_label_created_unix" ON public.label USING btree (created_unix);


--
-- Name: IDX_label_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_label_org_id" ON public.label USING btree (org_id);


--
-- Name: IDX_label_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_label_repo_id" ON public.label USING btree (repo_id);


--
-- Name: IDX_label_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_label_updated_unix" ON public.label USING btree (updated_unix);


--
-- Name: IDX_language_stat_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_language_stat_created_unix" ON public.language_stat USING btree (created_unix);


--
-- Name: IDX_language_stat_language; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_language_stat_language" ON public.language_stat USING btree (language);


--
-- Name: IDX_language_stat_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_language_stat_repo_id" ON public.language_stat USING btree (repo_id);


--
-- Name: IDX_lfs_lock_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_lfs_lock_owner_id" ON public.lfs_lock USING btree (owner_id);


--
-- Name: IDX_lfs_lock_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_lfs_lock_repo_id" ON public.lfs_lock USING btree (repo_id);


--
-- Name: IDX_lfs_meta_object_oid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_lfs_meta_object_oid" ON public.lfs_meta_object USING btree (oid);


--
-- Name: IDX_lfs_meta_object_repository_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_lfs_meta_object_repository_id" ON public.lfs_meta_object USING btree (repository_id);


--
-- Name: IDX_lfs_meta_object_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_lfs_meta_object_updated_unix" ON public.lfs_meta_object USING btree (updated_unix);


--
-- Name: IDX_login_source_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_login_source_created_unix" ON public.login_source USING btree (created_unix);


--
-- Name: IDX_login_source_is_active; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_login_source_is_active" ON public.login_source USING btree (is_active);


--
-- Name: IDX_login_source_is_sync_enabled; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_login_source_is_sync_enabled" ON public.login_source USING btree (is_sync_enabled);


--
-- Name: IDX_login_source_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_login_source_updated_unix" ON public.login_source USING btree (updated_unix);


--
-- Name: IDX_milestone_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_milestone_created_unix" ON public.milestone USING btree (created_unix);


--
-- Name: IDX_milestone_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_milestone_repo_id" ON public.milestone USING btree (repo_id);


--
-- Name: IDX_milestone_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_milestone_updated_unix" ON public.milestone USING btree (updated_unix);


--
-- Name: IDX_mirror_next_update_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_mirror_next_update_unix" ON public.mirror USING btree (next_update_unix);


--
-- Name: IDX_mirror_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_mirror_repo_id" ON public.mirror USING btree (repo_id);


--
-- Name: IDX_mirror_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_mirror_updated_unix" ON public.mirror USING btree (updated_unix);


--
-- Name: IDX_notice_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notice_created_unix" ON public.notice USING btree (created_unix);


--
-- Name: IDX_notification_commit_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_commit_id" ON public.notification USING btree (commit_id);


--
-- Name: IDX_notification_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_created_unix" ON public.notification USING btree (created_unix);


--
-- Name: IDX_notification_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_issue_id" ON public.notification USING btree (issue_id);


--
-- Name: IDX_notification_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_repo_id" ON public.notification USING btree (repo_id);


--
-- Name: IDX_notification_source; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_source" ON public.notification USING btree (source);


--
-- Name: IDX_notification_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_status" ON public.notification USING btree (status);


--
-- Name: IDX_notification_updated_by; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_updated_by" ON public.notification USING btree (updated_by);


--
-- Name: IDX_notification_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_updated_unix" ON public.notification USING btree (updated_unix);


--
-- Name: IDX_notification_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_notification_user_id" ON public.notification USING btree (user_id);


--
-- Name: IDX_oauth2_application_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_application_created_unix" ON public.oauth2_application USING btree (created_unix);


--
-- Name: IDX_oauth2_application_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_application_uid" ON public.oauth2_application USING btree (uid);


--
-- Name: IDX_oauth2_application_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_application_updated_unix" ON public.oauth2_application USING btree (updated_unix);


--
-- Name: IDX_oauth2_authorization_code_valid_until; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_authorization_code_valid_until" ON public.oauth2_authorization_code USING btree (valid_until);


--
-- Name: IDX_oauth2_grant_application_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_grant_application_id" ON public.oauth2_grant USING btree (application_id);


--
-- Name: IDX_oauth2_grant_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_oauth2_grant_user_id" ON public.oauth2_grant USING btree (user_id);


--
-- Name: IDX_org_user_is_public; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_org_user_is_public" ON public.org_user USING btree (is_public);


--
-- Name: IDX_org_user_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_org_user_org_id" ON public.org_user USING btree (org_id);


--
-- Name: IDX_org_user_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_org_user_uid" ON public.org_user USING btree (uid);


--
-- Name: IDX_package_blob_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_created_unix" ON public.package_blob USING btree (created_unix);


--
-- Name: IDX_package_blob_hash_md5; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_hash_md5" ON public.package_blob USING btree (hash_md5);


--
-- Name: IDX_package_blob_hash_sha1; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_hash_sha1" ON public.package_blob USING btree (hash_sha1);


--
-- Name: IDX_package_blob_hash_sha256; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_hash_sha256" ON public.package_blob USING btree (hash_sha256);


--
-- Name: IDX_package_blob_hash_sha512; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_hash_sha512" ON public.package_blob USING btree (hash_sha512);


--
-- Name: IDX_package_blob_upload_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_blob_upload_updated_unix" ON public.package_blob_upload USING btree (updated_unix);


--
-- Name: IDX_package_cleanup_rule_enabled; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_cleanup_rule_enabled" ON public.package_cleanup_rule USING btree (enabled);


--
-- Name: IDX_package_cleanup_rule_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_cleanup_rule_owner_id" ON public.package_cleanup_rule USING btree (owner_id);


--
-- Name: IDX_package_cleanup_rule_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_cleanup_rule_type" ON public.package_cleanup_rule USING btree (type);


--
-- Name: IDX_package_file_blob_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_file_blob_id" ON public.package_file USING btree (blob_id);


--
-- Name: IDX_package_file_composite_key; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_file_composite_key" ON public.package_file USING btree (composite_key);


--
-- Name: IDX_package_file_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_file_created_unix" ON public.package_file USING btree (created_unix);


--
-- Name: IDX_package_file_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_file_lower_name" ON public.package_file USING btree (lower_name);


--
-- Name: IDX_package_file_version_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_file_version_id" ON public.package_file USING btree (version_id);


--
-- Name: IDX_package_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_lower_name" ON public.package USING btree (lower_name);


--
-- Name: IDX_package_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_owner_id" ON public.package USING btree (owner_id);


--
-- Name: IDX_package_property_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_property_name" ON public.package_property USING btree (name);


--
-- Name: IDX_package_property_ref_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_property_ref_id" ON public.package_property USING btree (ref_id);


--
-- Name: IDX_package_property_ref_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_property_ref_type" ON public.package_property USING btree (ref_type);


--
-- Name: IDX_package_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_repo_id" ON public.package USING btree (repo_id);


--
-- Name: IDX_package_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_type" ON public.package USING btree (type);


--
-- Name: IDX_package_version_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_version_created_unix" ON public.package_version USING btree (created_unix);


--
-- Name: IDX_package_version_is_internal; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_version_is_internal" ON public.package_version USING btree (is_internal);


--
-- Name: IDX_package_version_lower_version; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_version_lower_version" ON public.package_version USING btree (lower_version);


--
-- Name: IDX_package_version_package_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_package_version_package_id" ON public.package_version USING btree (package_id);


--
-- Name: IDX_project_board_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_board_created_unix" ON public.project_board USING btree (created_unix);


--
-- Name: IDX_project_board_project_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_board_project_id" ON public.project_board USING btree (project_id);


--
-- Name: IDX_project_board_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_board_updated_unix" ON public.project_board USING btree (updated_unix);


--
-- Name: IDX_project_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_created_unix" ON public.project USING btree (created_unix);


--
-- Name: IDX_project_is_closed; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_is_closed" ON public.project USING btree (is_closed);


--
-- Name: IDX_project_issue_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_issue_issue_id" ON public.project_issue USING btree (issue_id);


--
-- Name: IDX_project_issue_project_board_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_issue_project_board_id" ON public.project_issue USING btree (project_board_id);


--
-- Name: IDX_project_issue_project_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_issue_project_id" ON public.project_issue USING btree (project_id);


--
-- Name: IDX_project_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_owner_id" ON public.project USING btree (owner_id);


--
-- Name: IDX_project_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_repo_id" ON public.project USING btree (repo_id);


--
-- Name: IDX_project_title; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_title" ON public.project USING btree (title);


--
-- Name: IDX_project_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_project_updated_unix" ON public.project USING btree (updated_unix);


--
-- Name: IDX_public_key_fingerprint; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_public_key_fingerprint" ON public.public_key USING btree (fingerprint);


--
-- Name: IDX_public_key_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_public_key_owner_id" ON public.public_key USING btree (owner_id);


--
-- Name: IDX_pull_auto_merge_doer_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_auto_merge_doer_id" ON public.pull_auto_merge USING btree (doer_id);


--
-- Name: IDX_pull_request_base_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_base_repo_id" ON public.pull_request USING btree (base_repo_id);


--
-- Name: IDX_pull_request_has_merged; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_has_merged" ON public.pull_request USING btree (has_merged);


--
-- Name: IDX_pull_request_head_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_head_repo_id" ON public.pull_request USING btree (head_repo_id);


--
-- Name: IDX_pull_request_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_issue_id" ON public.pull_request USING btree (issue_id);


--
-- Name: IDX_pull_request_merged_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_merged_unix" ON public.pull_request USING btree (merged_unix);


--
-- Name: IDX_pull_request_merger_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_pull_request_merger_id" ON public.pull_request USING btree (merger_id);


--
-- Name: IDX_push_mirror_last_update; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_push_mirror_last_update" ON public.push_mirror USING btree (last_update);


--
-- Name: IDX_push_mirror_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_push_mirror_repo_id" ON public.push_mirror USING btree (repo_id);


--
-- Name: IDX_reaction_comment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_comment_id" ON public.reaction USING btree (comment_id);


--
-- Name: IDX_reaction_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_created_unix" ON public.reaction USING btree (created_unix);


--
-- Name: IDX_reaction_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_issue_id" ON public.reaction USING btree (issue_id);


--
-- Name: IDX_reaction_original_author; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_original_author" ON public.reaction USING btree (original_author);


--
-- Name: IDX_reaction_original_author_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_original_author_id" ON public.reaction USING btree (original_author_id);


--
-- Name: IDX_reaction_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_type" ON public.reaction USING btree (type);


--
-- Name: IDX_reaction_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_reaction_user_id" ON public.reaction USING btree (user_id);


--
-- Name: IDX_release_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_release_created_unix" ON public.release USING btree (created_unix);


--
-- Name: IDX_release_original_author_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_release_original_author_id" ON public.release USING btree (original_author_id);


--
-- Name: IDX_release_publisher_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_release_publisher_id" ON public.release USING btree (publisher_id);


--
-- Name: IDX_release_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_release_repo_id" ON public.release USING btree (repo_id);


--
-- Name: IDX_release_tag_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_release_tag_name" ON public.release USING btree (tag_name);


--
-- Name: IDX_renamed_branch_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_renamed_branch_repo_id" ON public.renamed_branch USING btree (repo_id);


--
-- Name: IDX_repo_archiver_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_archiver_created_unix" ON public.repo_archiver USING btree (created_unix);


--
-- Name: IDX_repo_archiver_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_archiver_repo_id" ON public.repo_archiver USING btree (repo_id);


--
-- Name: IDX_repo_indexer_status_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_indexer_status_s" ON public.repo_indexer_status USING btree (repo_id, indexer_type);


--
-- Name: IDX_repo_redirect_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_redirect_lower_name" ON public.repo_redirect USING btree (lower_name);


--
-- Name: IDX_repo_transfer_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_transfer_created_unix" ON public.repo_transfer USING btree (created_unix);


--
-- Name: IDX_repo_transfer_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_transfer_updated_unix" ON public.repo_transfer USING btree (updated_unix);


--
-- Name: IDX_repo_unit_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_unit_created_unix" ON public.repo_unit USING btree (created_unix);


--
-- Name: IDX_repo_unit_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repo_unit_s" ON public.repo_unit USING btree (repo_id, type);


--
-- Name: IDX_repository_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_created_unix" ON public.repository USING btree (created_unix);


--
-- Name: IDX_repository_fork_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_fork_id" ON public.repository USING btree (fork_id);


--
-- Name: IDX_repository_is_archived; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_archived" ON public.repository USING btree (is_archived);


--
-- Name: IDX_repository_is_empty; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_empty" ON public.repository USING btree (is_empty);


--
-- Name: IDX_repository_is_fork; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_fork" ON public.repository USING btree (is_fork);


--
-- Name: IDX_repository_is_mirror; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_mirror" ON public.repository USING btree (is_mirror);


--
-- Name: IDX_repository_is_private; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_private" ON public.repository USING btree (is_private);


--
-- Name: IDX_repository_is_template; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_is_template" ON public.repository USING btree (is_template);


--
-- Name: IDX_repository_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_lower_name" ON public.repository USING btree (lower_name);


--
-- Name: IDX_repository_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_name" ON public.repository USING btree (name);


--
-- Name: IDX_repository_original_service_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_original_service_type" ON public.repository USING btree (original_service_type);


--
-- Name: IDX_repository_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_owner_id" ON public.repository USING btree (owner_id);


--
-- Name: IDX_repository_template_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_template_id" ON public.repository USING btree (template_id);


--
-- Name: IDX_repository_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_repository_updated_unix" ON public.repository USING btree (updated_unix);


--
-- Name: IDX_review_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_review_created_unix" ON public.review USING btree (created_unix);


--
-- Name: IDX_review_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_review_issue_id" ON public.review USING btree (issue_id);


--
-- Name: IDX_review_reviewer_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_review_reviewer_id" ON public.review USING btree (reviewer_id);


--
-- Name: IDX_review_state_pull_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_review_state_pull_id" ON public.review_state USING btree (pull_id);


--
-- Name: IDX_review_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_review_updated_unix" ON public.review USING btree (updated_unix);


--
-- Name: IDX_secret_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_secret_owner_id" ON public.secret USING btree (owner_id);


--
-- Name: IDX_secret_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_secret_repo_id" ON public.secret USING btree (repo_id);


--
-- Name: IDX_star_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_star_created_unix" ON public.star USING btree (created_unix);


--
-- Name: IDX_stopwatch_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_stopwatch_issue_id" ON public.stopwatch USING btree (issue_id);


--
-- Name: IDX_stopwatch_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_stopwatch_user_id" ON public.stopwatch USING btree (user_id);


--
-- Name: IDX_task_doer_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_task_doer_id" ON public.task USING btree (doer_id);


--
-- Name: IDX_task_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_task_owner_id" ON public.task USING btree (owner_id);


--
-- Name: IDX_task_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_task_repo_id" ON public.task USING btree (repo_id);


--
-- Name: IDX_task_status; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_task_status" ON public.task USING btree (status);


--
-- Name: IDX_team_invite_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_invite_created_unix" ON public.team_invite USING btree (created_unix);


--
-- Name: IDX_team_invite_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_invite_org_id" ON public.team_invite USING btree (org_id);


--
-- Name: IDX_team_invite_team_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_invite_team_id" ON public.team_invite USING btree (team_id);


--
-- Name: IDX_team_invite_token; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_invite_token" ON public.team_invite USING btree (token);


--
-- Name: IDX_team_invite_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_invite_updated_unix" ON public.team_invite USING btree (updated_unix);


--
-- Name: IDX_team_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_org_id" ON public.team USING btree (org_id);


--
-- Name: IDX_team_repo_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_repo_org_id" ON public.team_repo USING btree (org_id);


--
-- Name: IDX_team_unit_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_unit_org_id" ON public.team_unit USING btree (org_id);


--
-- Name: IDX_team_user_org_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_team_user_org_id" ON public.team_user USING btree (org_id);


--
-- Name: IDX_topic_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_topic_created_unix" ON public.topic USING btree (created_unix);


--
-- Name: IDX_topic_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_topic_updated_unix" ON public.topic USING btree (updated_unix);


--
-- Name: IDX_tracked_time_issue_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_tracked_time_issue_id" ON public.tracked_time USING btree (issue_id);


--
-- Name: IDX_tracked_time_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_tracked_time_user_id" ON public.tracked_time USING btree (user_id);


--
-- Name: IDX_two_factor_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_two_factor_created_unix" ON public.two_factor USING btree (created_unix);


--
-- Name: IDX_two_factor_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_two_factor_updated_unix" ON public.two_factor USING btree (updated_unix);


--
-- Name: IDX_user_badge_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_badge_user_id" ON public.user_badge USING btree (user_id);


--
-- Name: IDX_user_blocking_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_blocking_created_unix" ON public.user_blocking USING btree (created_unix);


--
-- Name: IDX_user_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_created_unix" ON public."user" USING btree (created_unix);


--
-- Name: IDX_user_is_active; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_is_active" ON public."user" USING btree (is_active);


--
-- Name: IDX_user_last_login_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_last_login_unix" ON public."user" USING btree (last_login_unix);


--
-- Name: IDX_user_open_id_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_open_id_uid" ON public.user_open_id USING btree (uid);


--
-- Name: IDX_user_redirect_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_redirect_lower_name" ON public.user_redirect USING btree (lower_name);


--
-- Name: IDX_user_setting_setting_key; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_setting_setting_key" ON public.user_setting USING btree (setting_key);


--
-- Name: IDX_user_setting_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_setting_user_id" ON public.user_setting USING btree (user_id);


--
-- Name: IDX_user_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_user_updated_unix" ON public."user" USING btree (updated_unix);


--
-- Name: IDX_watch_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_watch_created_unix" ON public.watch USING btree (created_unix);


--
-- Name: IDX_watch_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_watch_updated_unix" ON public.watch USING btree (updated_unix);


--
-- Name: IDX_webauthn_credential_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webauthn_credential_created_unix" ON public.webauthn_credential USING btree (created_unix);


--
-- Name: IDX_webauthn_credential_credential_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webauthn_credential_credential_id" ON public.webauthn_credential USING btree (credential_id);


--
-- Name: IDX_webauthn_credential_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webauthn_credential_updated_unix" ON public.webauthn_credential USING btree (updated_unix);


--
-- Name: IDX_webauthn_credential_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webauthn_credential_user_id" ON public.webauthn_credential USING btree (user_id);


--
-- Name: IDX_webhook_created_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webhook_created_unix" ON public.webhook USING btree (created_unix);


--
-- Name: IDX_webhook_is_active; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webhook_is_active" ON public.webhook USING btree (is_active);


--
-- Name: IDX_webhook_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webhook_owner_id" ON public.webhook USING btree (owner_id);


--
-- Name: IDX_webhook_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webhook_repo_id" ON public.webhook USING btree (repo_id);


--
-- Name: IDX_webhook_updated_unix; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX "IDX_webhook_updated_unix" ON public.webhook USING btree (updated_unix);


--
-- Name: UQE_access_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_access_s" ON public.access USING btree (user_id, repo_id);


--
-- Name: UQE_access_token_token_hash; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_access_token_token_hash" ON public.access_token USING btree (token_hash);


--
-- Name: UQE_action_artifact_runid_name_path; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_artifact_runid_name_path" ON public.action_artifact USING btree (run_id, artifact_path, artifact_name);


--
-- Name: UQE_action_run_repo_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_run_repo_index" ON public.action_run USING btree (repo_id, index);


--
-- Name: UQE_action_runner_token_hash; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_runner_token_hash" ON public.action_runner USING btree (token_hash);


--
-- Name: UQE_action_runner_token_token; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_runner_token_token" ON public.action_runner_token USING btree (token);


--
-- Name: UQE_action_runner_uuid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_runner_uuid" ON public.action_runner USING btree (uuid);


--
-- Name: UQE_action_task_output_task_id_output_key; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_task_output_task_id_output_key" ON public.action_task_output USING btree (task_id, output_key);


--
-- Name: UQE_action_task_step_task_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_task_step_task_index" ON public.action_task_step USING btree (task_id, index);


--
-- Name: UQE_action_task_token_hash; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_task_token_hash" ON public.action_task USING btree (token_hash);


--
-- Name: UQE_action_tasks_version_owner_repo; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_tasks_version_owner_repo" ON public.action_tasks_version USING btree (owner_id, repo_id);


--
-- Name: UQE_action_variable_owner_repo_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_action_variable_owner_repo_name" ON public.action_variable USING btree (owner_id, repo_id, name);


--
-- Name: UQE_attachment_uuid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_attachment_uuid" ON public.attachment USING btree (uuid);


--
-- Name: UQE_badge_slug; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_badge_slug" ON public.badge USING btree (slug);


--
-- Name: UQE_branch_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_branch_s" ON public.branch USING btree (repo_id, name);


--
-- Name: UQE_collaboration_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_collaboration_s" ON public.collaboration USING btree (repo_id, user_id);


--
-- Name: UQE_commit_status_index_repo_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_commit_status_index_repo_sha" ON public.commit_status_index USING btree (repo_id, sha);


--
-- Name: UQE_commit_status_repo_sha_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_commit_status_repo_sha_index" ON public.commit_status USING btree (index, repo_id, sha);


--
-- Name: UQE_commit_status_summary_repo_id_sha; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_commit_status_summary_repo_id_sha" ON public.commit_status_summary USING btree (repo_id, sha);


--
-- Name: UQE_dbfs_meta_full_path; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_dbfs_meta_full_path" ON public.dbfs_meta USING btree (full_path);


--
-- Name: UQE_deploy_key_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_deploy_key_s" ON public.deploy_key USING btree (key_id, repo_id);


--
-- Name: UQE_email_address_email; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_email_address_email" ON public.email_address USING btree (email);


--
-- Name: UQE_email_address_lower_email; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_email_address_lower_email" ON public.email_address USING btree (lower_email);


--
-- Name: UQE_email_hash_email; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_email_hash_email" ON public.email_hash USING btree (email);


--
-- Name: UQE_follow_follow; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_follow_follow" ON public.follow USING btree (user_id, follow_id);


--
-- Name: UQE_hook_task_uuid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_hook_task_uuid" ON public.hook_task USING btree (uuid);


--
-- Name: UQE_issue_dependency_issue_dependency; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_issue_dependency_issue_dependency" ON public.issue_dependency USING btree (issue_id, dependency_id);


--
-- Name: UQE_issue_label_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_issue_label_s" ON public.issue_label USING btree (issue_id, label_id);


--
-- Name: UQE_issue_repo_index; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_issue_repo_index" ON public.issue USING btree (repo_id, index);


--
-- Name: UQE_issue_user_uid_to_issue; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_issue_user_uid_to_issue" ON public.issue_user USING btree (uid, issue_id);


--
-- Name: UQE_issue_watch_watch; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_issue_watch_watch" ON public.issue_watch USING btree (user_id, issue_id);


--
-- Name: UQE_language_stat_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_language_stat_s" ON public.language_stat USING btree (repo_id, language);


--
-- Name: UQE_lfs_meta_object_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_lfs_meta_object_s" ON public.lfs_meta_object USING btree (oid, repository_id);


--
-- Name: UQE_login_source_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_login_source_name" ON public.login_source USING btree (name);


--
-- Name: UQE_oauth2_application_client_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_oauth2_application_client_id" ON public.oauth2_application USING btree (client_id);


--
-- Name: UQE_oauth2_authorization_code_code; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_oauth2_authorization_code_code" ON public.oauth2_authorization_code USING btree (code);


--
-- Name: UQE_oauth2_grant_user_application; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_oauth2_grant_user_application" ON public.oauth2_grant USING btree (user_id, application_id);


--
-- Name: UQE_org_user_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_org_user_s" ON public.org_user USING btree (uid, org_id);


--
-- Name: UQE_package_blob_md5; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_blob_md5" ON public.package_blob USING btree (hash_md5);


--
-- Name: UQE_package_blob_sha1; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_blob_sha1" ON public.package_blob USING btree (hash_sha1);


--
-- Name: UQE_package_blob_sha256; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_blob_sha256" ON public.package_blob USING btree (hash_sha256);


--
-- Name: UQE_package_blob_sha512; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_blob_sha512" ON public.package_blob USING btree (hash_sha512);


--
-- Name: UQE_package_cleanup_rule_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_cleanup_rule_s" ON public.package_cleanup_rule USING btree (owner_id, type);


--
-- Name: UQE_package_file_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_file_s" ON public.package_file USING btree (version_id, lower_name, composite_key);


--
-- Name: UQE_package_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_s" ON public.package USING btree (owner_id, type, lower_name);


--
-- Name: UQE_package_version_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_package_version_s" ON public.package_version USING btree (package_id, lower_version);


--
-- Name: UQE_protected_branch_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_protected_branch_s" ON public.protected_branch USING btree (repo_id, branch_name);


--
-- Name: UQE_pull_auto_merge_pull_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_pull_auto_merge_pull_id" ON public.pull_auto_merge USING btree (pull_id);


--
-- Name: UQE_reaction_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_reaction_s" ON public.reaction USING btree (type, issue_id, comment_id, user_id, original_author_id, original_author);


--
-- Name: UQE_release_n; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_release_n" ON public.release USING btree (repo_id, tag_name);


--
-- Name: UQE_repo_archiver_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_repo_archiver_s" ON public.repo_archiver USING btree (repo_id, type, commit_id);


--
-- Name: UQE_repo_redirect_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_repo_redirect_s" ON public.repo_redirect USING btree (owner_id, lower_name);


--
-- Name: UQE_repository_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_repository_s" ON public.repository USING btree (owner_id, lower_name);


--
-- Name: UQE_review_state_pull_commit_user; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_review_state_pull_commit_user" ON public.review_state USING btree (user_id, pull_id, commit_sha);


--
-- Name: UQE_secret_owner_repo_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_secret_owner_repo_name" ON public.secret USING btree (owner_id, repo_id, name);


--
-- Name: UQE_star_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_star_s" ON public.star USING btree (uid, repo_id);


--
-- Name: UQE_system_setting_setting_key; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_system_setting_setting_key" ON public.system_setting USING btree (setting_key);


--
-- Name: UQE_team_invite_team_mail; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_team_invite_team_mail" ON public.team_invite USING btree (team_id, email);


--
-- Name: UQE_team_repo_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_team_repo_s" ON public.team_repo USING btree (team_id, repo_id);


--
-- Name: UQE_team_unit_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_team_unit_s" ON public.team_unit USING btree (team_id, type);


--
-- Name: UQE_team_user_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_team_user_s" ON public.team_user USING btree (team_id, uid);


--
-- Name: UQE_topic_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_topic_name" ON public.topic USING btree (name);


--
-- Name: UQE_two_factor_uid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_two_factor_uid" ON public.two_factor USING btree (uid);


--
-- Name: UQE_upload_uuid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_upload_uuid" ON public.upload USING btree (uuid);


--
-- Name: UQE_user_blocking_block; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_blocking_block" ON public.user_blocking USING btree (blocker_id, blockee_id);


--
-- Name: UQE_user_lower_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_lower_name" ON public."user" USING btree (lower_name);


--
-- Name: UQE_user_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_name" ON public."user" USING btree (name);


--
-- Name: UQE_user_open_id_uri; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_open_id_uri" ON public.user_open_id USING btree (uri);


--
-- Name: UQE_user_redirect_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_redirect_s" ON public.user_redirect USING btree (lower_name);


--
-- Name: UQE_user_setting_key_userid; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_user_setting_key_userid" ON public.user_setting USING btree (user_id, setting_key);


--
-- Name: UQE_watch_watch; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_watch_watch" ON public.watch USING btree (user_id, repo_id);


--
-- Name: UQE_webauthn_credential_s; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX "UQE_webauthn_credential_s" ON public.webauthn_credential USING btree (lower_name, user_id);


--
-- Name: ix_activity_log_activity_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_activity_log_activity_type ON public.activity_log USING btree (activity_type);


--
-- Name: ix_activity_log_created_at; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_activity_log_created_at ON public.activity_log USING btree (created_at);


--
-- Name: ix_activity_log_repo_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_activity_log_repo_name ON public.activity_log USING btree (repo_name);


--
-- Name: ix_activity_log_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_activity_log_user_id ON public.activity_log USING btree (user_id);


--
-- Name: ix_assignment_files_assignment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_assignment_files_assignment_id ON public.assignment_files USING btree (assignment_id);


--
-- Name: ix_assignments_course_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_assignments_course_id ON public.assignments USING btree (course_id);


--
-- Name: ix_assignments_deadline; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_assignments_deadline ON public.assignments USING btree (deadline);


--
-- Name: ix_course_enrollments_course_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_course_enrollments_course_id ON public.course_enrollments USING btree (course_id);


--
-- Name: ix_course_enrollments_student_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_course_enrollments_student_id ON public.course_enrollments USING btree (student_id);


--
-- Name: ix_courses_teacher_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_courses_teacher_id ON public.courses USING btree (teacher_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_notifications_user_read; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_notifications_user_read ON public.notifications USING btree (user_id, read);


--
-- Name: ix_password_reset_tokens_token_hash; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX ix_password_reset_tokens_token_hash ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: ix_password_reset_tokens_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_password_reset_tokens_user_id ON public.password_reset_tokens USING btree (user_id);


--
-- Name: ix_permission_audit_actor_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_permission_audit_actor_id ON public.permission_audit USING btree (actor_id);


--
-- Name: ix_permission_audit_created_at; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_permission_audit_created_at ON public.permission_audit USING btree (created_at);


--
-- Name: ix_permission_audit_target_role; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_permission_audit_target_role ON public.permission_audit USING btree (target_role);


--
-- Name: ix_repositories_gitea_repo_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_repositories_gitea_repo_id ON public.repositories USING btree (gitea_repo_id);


--
-- Name: ix_repositories_is_blocked; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_repositories_is_blocked ON public.repositories USING btree (is_blocked);


--
-- Name: ix_repositories_language; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_repositories_language ON public.repositories USING btree (language);


--
-- Name: ix_repositories_owner_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_repositories_owner_id ON public.repositories USING btree (owner_id);


--
-- Name: ix_repositories_repo_type; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_repositories_repo_type ON public.repositories USING btree (repo_type);


--
-- Name: ix_role_permissions_role; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_role_permissions_role ON public.role_permissions USING btree (role);


--
-- Name: ix_student_repositories_assignment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_student_repositories_assignment_id ON public.student_repositories USING btree (assignment_id);


--
-- Name: ix_student_repositories_student_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_student_repositories_student_id ON public.student_repositories USING btree (student_id);


--
-- Name: ix_submissions_assignment_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_submissions_assignment_id ON public.submissions USING btree (assignment_id);


--
-- Name: ix_submissions_student_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_submissions_student_id ON public.submissions USING btree (student_id);


--
-- Name: ix_system_logs_created_at; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_system_logs_created_at ON public.system_logs USING btree (created_at);


--
-- Name: ix_system_logs_created_at_level_source; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_system_logs_created_at_level_source ON public.system_logs USING btree (created_at, level, source);


--
-- Name: ix_system_logs_level; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_system_logs_level ON public.system_logs USING btree (level);


--
-- Name: ix_system_logs_source; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_system_logs_source ON public.system_logs USING btree (source);


--
-- Name: ix_system_logs_user_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_system_logs_user_id ON public.system_logs USING btree (user_id);


--
-- Name: ix_trusted_assistants_assistant_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_trusted_assistants_assistant_id ON public.trusted_assistants USING btree (assistant_id);


--
-- Name: ix_trusted_assistants_teacher_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_trusted_assistants_teacher_id ON public.trusted_assistants USING btree (teacher_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_group_name; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_users_group_name ON public.users USING btree (group_name);


--
-- Name: ix_users_last_login; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_users_last_login ON public.users USING btree (last_login);


--
-- Name: ix_users_mtuci_login; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE INDEX ix_users_mtuci_login ON public.users USING btree (mtuci_login);


--
-- Name: ix_users_student_id; Type: INDEX; Schema: public; Owner: mtuci
--

CREATE UNIQUE INDEX ix_users_student_id ON public.users USING btree (student_id);


--
-- Name: activity_log fk_activity_log_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT fk_activity_log_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: assignment_files fk_assignment_files_assignment_id_assignments; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.assignment_files
    ADD CONSTRAINT fk_assignment_files_assignment_id_assignments FOREIGN KEY (assignment_id) REFERENCES public.assignments(id) ON DELETE CASCADE;


--
-- Name: assignments fk_assignments_course_id_courses; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT fk_assignments_course_id_courses FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_enrollments fk_course_enrollments_course_id_courses; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT fk_course_enrollments_course_id_courses FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_enrollments fk_course_enrollments_student_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT fk_course_enrollments_student_id_users FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: courses fk_courses_teacher_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT fk_courses_teacher_id_users FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications fk_notifications_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens fk_password_reset_tokens_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fk_password_reset_tokens_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: permission_audit fk_permission_audit_actor_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.permission_audit
    ADD CONSTRAINT fk_permission_audit_actor_id_users FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: repositories fk_repositories_owner_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT fk_repositories_owner_id_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_repositories fk_student_repositories_assignment_id_assignments; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.student_repositories
    ADD CONSTRAINT fk_student_repositories_assignment_id_assignments FOREIGN KEY (assignment_id) REFERENCES public.assignments(id) ON DELETE CASCADE;


--
-- Name: student_repositories fk_student_repositories_student_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.student_repositories
    ADD CONSTRAINT fk_student_repositories_student_id_users FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: submissions fk_submissions_assignment_id_assignments; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk_submissions_assignment_id_assignments FOREIGN KEY (assignment_id) REFERENCES public.assignments(id) ON DELETE CASCADE;


--
-- Name: submissions fk_submissions_student_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT fk_submissions_student_id_users FOREIGN KEY (student_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_logs fk_system_logs_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT fk_system_logs_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: trusted_assistants fk_trusted_assistants_assistant_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.trusted_assistants
    ADD CONSTRAINT fk_trusted_assistants_assistant_id_users FOREIGN KEY (assistant_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: trusted_assistants fk_trusted_assistants_teacher_id_users; Type: FK CONSTRAINT; Schema: public; Owner: mtuci
--

ALTER TABLE ONLY public.trusted_assistants
    ADD CONSTRAINT fk_trusted_assistants_teacher_id_users FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict SKfPw4k22acDXix6mBmWZ4YjQdDPTRgWcF1id13ocQ8dUlxDGBp14mBHX2fGsmD

